﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using System.Collections.Generic;
using System.Linq;
using BotLearning1.Intents;

namespace BotLearning1.Dialogs
{
    
    [LuisModel("eb939310-b8a6-40b0-b115-60b8960dfc05", "fda54b363dd14036adf0b298b02c241f",LuisApiVersion.V2, "westus.api.cognitive.microsoft.com",Log =true,SpellCheck =true),Serializable]

    public class RootDialog : LuisDialog<object>
    {
        public static List<string> PromptOptions()
        {
            List<string> promptOptions = new List<string>();
            promptOptions.Add("Mobile");
            promptOptions.Add("Clothing");

            promptOptions.Add("None");
            return promptOptions;
        }

        [LuisIntent("Greetings")]
        public async Task Greeting(IDialogContext context,IAwaitable<object> activity,LuisResult result)
        {
            //HeroCard Card
            /*
            var makeMessage = context.MakeMessage();
            
            HeroCard title = new HeroCard { Title = "Hi Im Bot ...How can i help you" };
            makeMessage.Attachments.Add(title.ToAttachment());
            await context.PostAsync(makeMessage);*/

            //Makemessage

            /* var makeMessage = context.MakeMessage();
             string message = "It was nice talking to you. Have a nice day !!";
             makeMessage.Speak = message;
             makeMessage.Text = message;
             await context.PostAsync(makeMessage);*/
            //PromptDialog.Choice(context, AfterFirstDialog, PromptOptions(), "choose one of the below option", "Please enter valid input", 2);
            PromptDialog.Text(context, AfterFirstDialog, "how may i help you");
        }
        [LuisIntent("Weather")]
        public async Task GetWeather(IDialogContext context, IAwaitable<IMessageActivity> activity,LuisResult result)
        {
            try
            {
                DoAlgorithm(context,activity,result);
            }
            catch
            {
                await context.PostAsync("Encountered error");
            }
        }
       
        public interface IPostData
        {
              Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity);
        }
        public Dictionary<int, string> _options = new Dictionary<int, string>();

        public static Dictionary<string, IPostData> _levelConversationStrategies = new Dictionary<string, IPostData>();
        public static Dictionary<int, string> conversationlMessages = new Dictionary<int, string>();
        
        
        public static string Intent { get; set; }
        public void DoAlgorithm(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)

        {
            var luisIntent = result.Intents[0].Intent;
            List<string> lstIntents = new List<string>();

            var distinctEntities = GetDistinctEntities(result);
            int iCount = 1;
            foreach (var entity in distinctEntities)
            {
                var intentName = GetIntentName(luisIntent, entity.ToLower(), iCount, _options);
                if ((!lstIntents.Contains(intentName)) && (!string.IsNullOrEmpty(intentName)))
                {
                    lstIntents.Add(intentName);

                    iCount = iCount + 1;
                }
                _options.Clear();
                _levelConversationStrategies.Clear();
                switch (lstIntents.Count)
                {
                    case 0:
                        DoCallClass(context, activity, result);
                        break;
                    case 1:
                        var intent = GetFileIntent(distinctEntities, luisIntent, true, _options);
                        Intent = intent[1].ToString();
                        DoCallClass(context, activity, result);
                        break;
                }
            }

        }
        public static Dictionary<int, string> GetFileIntent(List<string> entities, string luisIntent, bool isSingleEntity, Dictionary<int, string> options)
        {
            string message = "";
            int iCount = 1;
            foreach (var entity in entities)
            {
                var intentName = GetIntentName(luisIntent, entity.ToLower(), iCount, options);
                // LstIntents.Add(intentName);

                if ((!string.IsNullOrEmpty(intentName)))
                {
                    if (isSingleEntity)
                    {
                        if (entities.Count == iCount)
                        {
                            //return intentName;
                            //  listPromptMessage.Add(intentName);
                            conversationlMessages.Add(iCount, intentName);
                            return conversationlMessages;
                        }
                        else
                        {
                            message = intentName;
                        }
                    }
                    else if (!isSingleEntity)
                    {
                        message = GetMessage("", intentName, 0);
                    }
                    // listPromptMessage.Add(message);
                    conversationlMessages.Add(iCount, message);
                    iCount = iCount + 1;
                }




            }
            return conversationlMessages;
        }
        public static string GetMessage(string message, string intentName, int counter)
        {
            switch (intentName)
            {
                case "hyderabad":
                    message = message + "Sludge in heavy Oil. \n\n\n\n";
                    break;

            }
            return message;
        }
        private void DoCallClass(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            try
            {
                if (_levelConversationStrategies.Count == 0)
                {
                    _levelConversationStrategies.Add("Hyderabad", new Hyderabad());
                    _levelConversationStrategies.Add("Bangalore", new Bangalore());
                }
                _levelConversationStrategies[Intent].MainAsync(context, activity);
            }
            catch
            {

            }
        }
        public static List<string> GetDistinctEntities(LuisResult result)
        {
            var entities = result.Entities;
            var entityRecommendations = entities.Select(entity => entity.Resolution).ToList();

            var normalizedValues = new List<string>();
            var keyValuePair = new List<KeyValuePair<string, object>>();

            foreach (var item in entityRecommendations)
            {
                if (item != null)
                    keyValuePair.AddRange(item);
            }
            foreach (var item in keyValuePair)
            {
                var values = ((List<object>)item.Value);
                foreach (var value in values)
                {
                    normalizedValues.Add(value.ToString());
                }
            }
            var distinctEntities = normalizedValues.Distinct().ToList();
            return distinctEntities;

        }
        public static string GetIntentName(string luisIntent, string entity, int counter, Dictionary<int, string> _options)
        {
            var intent = string.Empty;
            switch (luisIntent)
            {
                case "Weather":
                    switch (entity)
                    {
                        case "hyderabad":
                        case "Hyderabad":
                            intent = "Hyderabad";
                            break;
                        case "banagalore":
                            intent = "Bangalore";
                            break;
                        default:break;
                    }
                    break;
            }
            if (!string.IsNullOrEmpty(intent))
                _options.Add(counter, intent);

            return intent;
        }
        private async Task AfterFirstDialog(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            string prompt;
            switch (message.ToString())
            {
                case "1":
                case "Mobiles":
                    prompt = "Please select brand you are looking for \n\n 1.Apple\n2.Samsung\n3.Nokia";
                    PromptDialog.Text(context, Level1Mobiles, prompt);
                    break;
                case "2":
                case "Appliances":
                    prompt = "Please select company you are looking for \n\n 1.Whirpool\n2.Samsung\n3.Sony";
                    await context.PostAsync(prompt);
                    break;
                case "3":
                case "Clothing":
                    prompt = "Please choose one of the below option \n\n 1.Men\n2.Women\n3.Kids";
                    await context.PostAsync(prompt);
                    break;
               default:
                    prompt = "Please select valid option";
                    PromptDialog.Text(context,AfterFirstDialog,prompt);
                    break;
            }

            return;
        }

        private async Task Level1Mobiles(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            string promptMobile;

            switch (message.ToString())
            {
                case "1":
                case "Apple":
                    promptMobile = "Available Series \n\n 1.Apple 8Plus\n 2.Apple X\n3.Apple XMax\n\n Please select the series which you want to order";
                    PromptDialog.Text(context,LevelApple,promptMobile);
                    break;

            }
        }

        private async Task LevelApple(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            string promptApple;

            switch (message.ToString())
            {
                case "1":
                case "Apple 8Plus":
                promptApple= "Enter yes if you want to buy APPLE 8Plus";
                PromptDialog.Text(context, LevelSeries, promptApple);
                    break;
            }
        }

        private async Task LevelSeries(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            string promptSeries;

            switch (message.ToString())
            {
                case "1":
                case "yes":
                    promptSeries = "Thank you ! Order placed successfully";
                    await context.PostAsync(promptSeries);
                    break;
            }
        }

        /* public Task StartAsync(IDialogContext context)
         {
             context.Wait(MessageReceivedAsync);

             return Task.CompletedTask;
         }

         private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
         {
             var activity = await result as Activity;

             // Calculate something for us to return
             int length = (activity.Text ?? string.Empty).Length;

             // Return our reply to the user
             await context.PostAsync($"You sent {activity.Text} which was {length} characters");

             context.Wait(MessageReceivedAsync);
         }*/
    }
}