﻿
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

using System.Configuration;
using static BotLearning1.Dialogs.RootDialog;

namespace BotLearning1.Intents
{
    [Serializable]
    public class Hyderabad:IDialog<object>, IPostData
    {

        
        public Hyderabad()
        {
            
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity)
        {
            var messageActivity = await activity;

           
            string replyMsg = string.Empty;


            await context.PostAsync("Weather is so cool");
        }
      

        Task IDialog<object>.StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }

    }
}