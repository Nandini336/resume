﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;

/// <summary>
/// Common class for all intents Yes or No function and follow up question
/// </summary>

namespace ChatBot.Common
{
    [Serializable]
    public class EndOfConversation
    {
        public string Intent { get; set; }
        public EndOfConversation(MailContent MailContent, List<CreateDbData> ListCreateDbData)
        {
        }
        public EndOfConversation()
        {
        }
        public async Task EndLevelConversation(IDialogContext context)
        {
            context.EndConversation("End");
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
            context.Done<object>(null);
        }
        }
    }
}