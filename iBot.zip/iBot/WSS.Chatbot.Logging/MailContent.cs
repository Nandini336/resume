﻿using Microsoft.Bot.Builder.Dialogs;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WSS.ChatBot.Common;

/// <summary>
/// Class to capture and send user and bot conversation to WSS support team
/// </summary>

namespace ChatBot.Common
{
    [Serializable]
    public class MailContent
    {
        readonly StringBuilder _strBuilder = new StringBuilder();

        public List<CreateDbData> ListCreateDbData { get; set; }
        public static string Intent { get; set; }

        public MailContent(List<CreateDbData> listcreateDbData)
        {
            this.ListCreateDbData = listcreateDbData;
        }


        public string ChatDataForUserandBot(IDialogContext context, string botReply)
        {
            var userName = context.Activity.From.Name;
            //string BotName = context.Activity.Recipient.Name;
            var BotName = WSS.ChatBot.Common.Common.Bot;
            if (string.IsNullOrEmpty(botReply))
            {
                var convMsg = _strBuilder.Append($"<p>" + userName + " : " + context.Activity.AsMessageActivity().Text).ToString();
                return convMsg;
            }
            else
            {
                var convMsg2 = _strBuilder.Append($"<p>" + userName + " : " + context.Activity.AsMessageActivity().Text + "<p>" + BotName + " : " + botReply + "<p>").ToString();
                return convMsg2;
            }


        }
        public string ChatDataForUserandBot(string userName, string botName, string userReply, string botReply)
        {
            if (string.IsNullOrEmpty(botReply))
            {
                var convMsg = _strBuilder.Append($"<p>" + userName + " : " + userReply).ToString();
                return convMsg;
            }
            else
            {
                var convMsg = _strBuilder.Append($"<p>" + userName + " : " + userReply + "<p>" + botName + " : " + botReply + "<p>").ToString();
                return convMsg;
            }

        }

        public string ChatDataForBot(IDialogContext context, string botReply)
        {
            if (!string.IsNullOrEmpty(botReply))
            {
                //string UserName = context.Activity.From.Name;
                const string BotName = WSS.ChatBot.Common.Common.Bot;
                return _strBuilder.Append($"<p>" + BotName + " : " + botReply + "<p>").ToString();
            }
            return "";
        }


        public async Task SendingEmail(string userchat, string username)
        {

            var intents = new List<string>();

            var filterIntent = ListCreateDbData.Where(e => ((e.Intent != ConstIntents.Greetings) 
                                && (e.Intent != ConstIntents.Blank) 
                                && (e.Intent != "") 
                                && (e.Intent != ConstIntents.UnknownIntent))).ToList();

            foreach (var intent in filterIntent)
            {
                intents.Add(intent.Intent);
            }

            var ccMailTos = new List<string>();
            foreach (var item in intents)
            {
                var ccMailid = GetMailUser(item).Trim();
                ccMailTos.Add(ccMailid);
            }

            var distinctccMailTo = (from w in ccMailTos
                                    select w).Distinct().ToList();

            //  ccMailTos.Distinct().ToList();
            
            var sendGridAppKey = ConfigurationManager.AppSettings["SendGridAppKey"];
            var fromEmailAddress = ConfigurationManager.AppSettings["FromEmailAddress"];
            var toEmailAddress = ConfigurationManager.AppSettings["ToEmailAddress"].Trim();

            var chatTitle = $"<b>The following conversation happened between WSS Chat bot and {username} on {DateTime.Now.ToUniversalTime().ToString()}</b>";
            var client = new SendGridClient(sendGridAppKey.ToString());
           
            var msg = new SendGridMessage()
            {

                From = new EmailAddress(fromEmailAddress.ToString(), ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString()+" "+"WSS Team"),
                Subject = "WSS User Chat Information",
            };
            msg.AddContent(MimeType.Html, chatTitle + "\n" + userchat.Replace("**", ""));


            foreach (var item in distinctccMailTo)
            {
                msg.AddTo(new EmailAddress(item, "WSS User"));
            }


            if (!(distinctccMailTo.Contains(toEmailAddress)))
            {
                msg.AddCc(new EmailAddress(toEmailAddress.ToString(), "WSS User"));
                await client.SendEmailAsync(msg);
            }
            else
            {
                await client.SendEmailAsync(msg);
            }

        }

        public async Task EmailFunction(IDialogContext context, IAwaitable<string> result)
        {
            string prompt;
            var response = await result;

            CreateDbData.Instance.User = context.Activity.From.Name;
            CreateDbData.Instance.UserReply = response.ToString();
            CreateDbData.Instance.UserRequestDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = string.Empty;
            CreateDbData.Instance.IsUserQueryResolved = "no";

            switch (response.ToLower().Trim().Replace("&#160;", "").Trim())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case "1":
                    prompt = "I have sent the details to WSS customer support . You will hear from us very soon!";

                    CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
                    CreateDbData.Instance.BotResponse = prompt;
                    CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
                    CreateDbData.Instance.BotResponse2 = string.Empty;
                    //  CreateDbData.Instance.IsUserQueryResolved = string.Empty;
                    ListCreateDbData.Add(CreateDbData.Instance);
                    context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

                    await context.PostAsync(prompt);
                    break;

                case "no":
                case "2":
                    prompt = "Thank you for contacting us. You will hear from us very soon!";

                    CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
                    CreateDbData.Instance.BotResponse = prompt;
                    CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
                    CreateDbData.Instance.BotResponse2 = string.Empty;
                    // CreateDbData.Instance.IsUserQueryResolved = string.Empty;
                    ListCreateDbData.Add(CreateDbData.Instance);
                    context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);
                    await context.PostAsync(prompt);
                    break;

                default:
                    prompt = @"Please enter **""Yes""** / **""No""** to know if I have to send the conversation to WSS customer support.";
                    ChatDataForUserandBot(context, prompt);

                    CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
                    CreateDbData.Instance.BotResponse = prompt;
                    CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
                    CreateDbData.Instance.BotResponse2 = string.Empty;
                    // CreateDbData.Instance.IsUserQueryResolved = string.Empty;
                    ListCreateDbData.Add(CreateDbData.Instance);
                    context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

                    PromptDialog.Text(context, this.EmailFunction, prompt);
                    return;
            }
           // var chatbody = ChatDataForUserandBot(context, prompt);

            var chatbody = "";
            foreach (var data in ListCreateDbData)
            {
                chatbody = ChatDataForUserandBot(data.User, data.Bot, data.UserReply, data.BotResponse);
                if (!string.IsNullOrEmpty(data.BotResponse2))
                {
                    chatbody = ChatDataForBot(context, data.BotResponse2);
                }
            }

            await SendingEmail(chatbody, context.Activity.From.Name);

            //   ListCreateDbData.Clear();//(Commented this line since it is not allowing to capture the previous query after saying yes or no)

            context.EndConversation("End");
            context.Done<object>(null);

        }

        private string ConvertIntentIntoProduct(string intent)
        {
            string product;

            switch (intent.Trim())
            {
                //fuel cases
                case ConstIntents.HeavySludge:
                case ConstIntents.HeavyImproperCombustion:
                case ConstIntents.HeavySoot:
                case ConstIntents.HeavySludgeVarious:
                case ConstIntents.HeavyWater:
                case ConstIntents.HeavyCorrosion:
                    product = Products.Fuel;
                    break;

                //vessel cases:
                case ConstIntents.Vessel_Oxytreat_25_Ltr:
                case ConstIntents.Vessel_Slip_Coat_Plus_25_Ltr:
                    product = Products.Fuel;
                    break;

                //rope cases
                case ConstIntents.RopesCertification:
                case ConstIntents.RopeAccessories:
                case ConstIntents.RopesConventionalMix:
                case ConstIntents.RopesConventionalPolyPropylene:
                case ConstIntents.RopesConventionalNylon:               
                case ConstIntents.Ropes_Sikka:
                case ConstIntents.Ropes_StretcherRecommendation:
                case ConstIntents.Ropes_SteelWire:
                case ConstIntents.Ropes_SBA:
                case ConstIntents.Ropes_Stretcher:
                case ConstIntents.Ropes_MixType:
                case ConstIntents.Ropes_Main:
                case ConstIntents.Ropes_Conventional:
                case ConstIntents.Ropes_DalrympleBay:
                case ConstIntents.Ropes_Lines:
                case ConstIntents.Ropes_HeavingLine:
                case ConstIntents.Ropes_PilotLadder:
                case ConstIntents.Ropes_FlagLine:
                case ConstIntents.Ropes_RatGuard:
                case ConstIntents.Ropes_ManilaRope:
                case ConstIntents.Ropes_TigerRope:
                case ConstIntents.Ropes_MessengerLine:
                case ConstIntents.Ropes_MinaAlAhmadi:
                case ConstIntents.Ropes_OCIMF4:
                case ConstIntents.Ropes_Spliced:
                case ConstIntents.Ropes_SmartRope:
                case ConstIntents.Ropes_StockPoints:
                case ConstIntents.INT_RS_PSD:
                case ConstIntents.Ropes_CowHitch:
                case ConstIntents.Ropes_Cutter:
                case ConstIntents.Ropes_RubberMooringSnubber:
                case ConstIntents.Ropes_StretcherRingtailSingleTail:
                case ConstIntents.Ropes_Atlas:
                case ConstIntents.Ropes_TimmWinchline:
                case ConstIntents.Ropes_TimmMaster8:
                case ConstIntents.Ropes_TypeApproval:
                case ConstIntents.Ropes_AceraScott:
                case ConstIntents.Ropes_Acera:
                case ConstIntents.Ropes_Acera_Products_EDP:
                case ConstIntents.Ropes_MeasuringDiameter:
                case ConstIntents.Ropes_PanamaCanal:
                case ConstIntents.Ropes_TCLL:
                case ConstIntents.Ropes_Eyes:
                case ConstIntents.Ropes_Conditions:


                    product = Products.Rope;
                    break;

                //oil cases
                case ConstIntents.OiltestFerrouswear:
                case ConstIntents.OiltestCompatability:
                case ConstIntents.OiltestTbn:
                case ConstIntents.OiltestInsolubles:
                case ConstIntents.OiltestSaltwater:
                case ConstIntents.OiltestCabinet:
                case ConstIntents.OiltestWater:
                case ConstIntents.OiltestViscosity:
                case ConstIntents.OilBiofuelsulphide:
                    product = Products.Oil;
                    break;

                //diesel case
                case ConstIntents.DieselLubricity:
                case ConstIntents.DieselWaxing:
                case ConstIntents.DieselDiscoloration:
                case ConstIntents.DieselBacteria:
                    product = Products.Diesel;
                    break;

                //refrigerant cases               
                
                case ConstIntents.R507_Availability:
                case ConstIntents.R22_Availability:
                case ConstIntents.R404A_Availability:
                case ConstIntents.R448A_Availability:
                case ConstIntents.R448A_R449A_Availability:
                case ConstIntents.R449A_Availability:
                case ConstIntents.R407F_Availability:
                case ConstIntents.R422D_Availability:

                case ConstIntents.R404A_R507_Refrigerants_Continue_R404A_and_R507:
                case ConstIntents.R404A_Refrigerants_Continue_R404A_and_R507:
                case ConstIntents.R507_R404A_Refrigerants_Continue_R404A_and_R507:
                case ConstIntents.R507_Refrigerants_Continue_R404A_and_R507:

                case ConstIntents.R404A_R507_Refrigerants_Move_Away_from_R404A_and_R507:
                case ConstIntents.R404A_Refrigerants_Move_Away_from_R404A_and_R507:
                case ConstIntents.R507_R404A_Refrigerants_Move_Away_from_R404A_and_R507:
                case ConstIntents.R507_Refrigerants_Move_Away_from_R404A_and_R507:

                case ConstIntents.R407F_GuideLines:
                case ConstIntents.R507_GuideLines:
                case ConstIntents.R407F_R404A_GuideLines:

                case ConstIntents.R404A_Price:
                case ConstIntents.R407F_Price:
                case ConstIntents.R507_Price:
                case ConstIntents.R134A_Price:

                case ConstIntents.R22_Replace:
                case ConstIntents.R404A_R407F_Replace:
                case ConstIntents.R404A_Replace:
                case ConstIntents.R407F_R404A_Replace:
                case ConstIntents.R407F_R507_Replace:               
                case ConstIntents.R507_R407F_Replace:
                case ConstIntents.R422D_Replace:

                case ConstIntents.R22_Retrofit:
                case ConstIntents.R404A_R407F_Retrofit:
                case ConstIntents.R407F_R404A_Retrofit:
                case ConstIntents.R407F_R507_Retrofit:
                case ConstIntents.R507_R407F_Retrofit:

                case ConstIntents.R404A_R407F_Topup:
                case ConstIntents.R407F_R404A_Topup:
                case ConstIntents.R407F_R507_Topup:
                case ConstIntents.R507_R407F_Topup:
                case ConstIntents.R22_Topup:

                case ConstIntents.Refrigerant_GWP_and_Filling_Weight:
                case ConstIntents.Refrigerant_Return_of_Full_Cylinder:

                // Refrigerant intents from main app:
                case ConstIntents.What_is_Montreal_Protocol:
                case ConstIntents.Refrigerants_Price_On_Request:
                case ConstIntents.Refrigerants_Price_Change:
                case ConstIntents.Refrigerants_HFC_Quota:
                case ConstIntents.Refrigerants_Anti_Dumping:
                case ConstIntents.Refrigerants_F_gas:            
                case ConstIntents.Refrigerants_in_WSS_standard_cylinders:             
                               
                case ConstIntents.Refrigerant_Recovery:
                case ConstIntents.Refrigerant_Leak_Detection:
                case ConstIntents.Refrigerant_Recovery_Cylinder:
                case ConstIntents.Refrigerant_UV_Tracer_Kit_12V:
                case ConstIntents.Refrigeration_UV_Tracer_Kit_220V:

                case ConstIntents.R407F_About:

                    product = Products.Refrigerants;
                    break;

                // G and A cases
                case ConstIntents.EasyClean_Window_And_Mirror:
                case ConstIntents.EasyClean_SoftSurface_And_Spot:
                case ConstIntents.EasyClean_Floor_And_Hard_Surface:
                case ConstIntents.EasyClean_Basin_And_ToiletBowl:
                case ConstIntents.Gamazyme_BTC:
                case ConstIntents.Gamazyme_TDS:
                case ConstIntents.Gamazyme_Digestor:
                case ConstIntents.Gamazyme_BOE:
                case ConstIntents.Easyclean_Cleaning_And_DisInfection_Sanite128F:
                case ConstIntents.Galley_Easyclean_Oven_And_Grill:
                case ConstIntents.Galley_Easyclean_Dishwashing_LiquidManual:
                case ConstIntents.Galley_Easyclean_Hand_Sanitizer:
                case ConstIntents.Galley_Gamazyme_Boe:
                case ConstIntents.Galley_Gamazyme_Digestor:
                case ConstIntents.Drains_Gamazyme700_FN:
                case ConstIntents.Easyclean_Laundry_Conditioner:
                case ConstIntents.Easyclean_Laundry_Powder_ForLaundry:
                case ConstIntents.Easyclean_Laundry_Powder_SkinRash:
                case ConstIntents.SkinCare_EasyClean_Liquid_Hand_Soap_D:
                case ConstIntents.SkinCare_EasyClean_Hand_Sanitizer:
                case ConstIntents.SkinCare_EasyClean_Hand_Barrier_Cream_Wet:
                case ConstIntents.SkinCare_EasyClean_Hand_Barrier_Cream_Dry:
                case ConstIntents.SkinCare_EasyClean_After_Work_Lotion:
                case ConstIntents.SkinCare_EasyClean_Natural_Hand_Cleaner:
                case ConstIntents.Cleaning_Shelf_life_Gamayzme_TDS:
                case ConstIntents.Cleaning_Shelf_life_Gamazyme_700FN:
                case ConstIntents.Cleaning_Shelf_life_Gamazyme_BTC:
                case ConstIntents.Cleaning_Shelf_life_Gamazyme_DPC:

                case ConstIntents.C_M_ACC_Plus:
                case ConstIntents.C_M_COMMISSIONING_CLEANER:
                case ConstIntents.C_M_COLDWASH_HD:
                case ConstIntents.C_M_CLEANBREAK:
                case ConstIntents.C_M_BILGEWATER_FLOCCULANT:
                case ConstIntents.C_M_CARBONCLEAN_LT:
                case ConstIntents.C_M_AQUATUFF:
                case ConstIntents.C_M_AQUABREAK_PX:
                case ConstIntents.C_M_Deck_Clean_NP:
                case ConstIntents.C_M_Defoamer_Concentrate:

                    product = Products.GandA;
                    break;

                //Welding
                case ConstIntents.Welding_Cutting_Torches:
                case ConstIntents.Welding_Cutting_Torches_1:
                case ConstIntents.Welding_Accessories:
                case ConstIntents.Welding_Electrode_Competitor:
                case ConstIntents.Welding_Electrode_Competitor_1:
                case ConstIntents.Welding_Electrode_Competitor_2:
                case ConstIntents.Welding_Electrode_Competitor_3:
                case ConstIntents.Welding_Electrode_Competitor_4:
                case ConstIntents.Welding_Electrode_Competitor_5:
                case ConstIntents.Welding_Electrode_Competitor_6:
                case ConstIntents.Welding_Flashback_Arrestor:
                case ConstIntents.Welding_Plasma_Machine:
                case ConstIntents.Welding_Plasma_Machine_1:
                case ConstIntents.Welding_Regulator_Oxygen_Acetylene:
                case ConstIntents.Welding_Oxygen_Acetylene_Gas_Hoses:
                case ConstIntents.Welding_Rod:
                case ConstIntents.Welding_Rod_1:
                case ConstIntents.Welding_Machine_1:
                case ConstIntents.Welding_Open_Circuit_Voltage:
                case ConstIntents.Welding_Stick_Electrode:
                case ConstIntents.Welding_Cylinder_Trolley:
                case ConstIntents.Welding_Wire:

                    product = Products.Welding;
                    break;

                //Air
                case ConstIntents.Air_Distributor:
                case ConstIntents.Air_Hose_Clamp:
                case ConstIntents.Air_tools_quick_coupling:
                case ConstIntents.Air_Die_Grinder:
                case ConstIntents.Air_Scaling_Hammer:
                case ConstIntents.Air_Gun:
                case ConstIntents.Air_Hose:
                case ConstIntents.Air_Deck_Scaler:
                case ConstIntents.Air_Angle_Grinder:
                case ConstIntents.Air_tools_impact_wrench:

                    product = Products.Air;
                    break;

                //Workshop
                case ConstIntents.Workshop_Equipment_Drill:
                case ConstIntents.Workshop_Equipment_Grinder:

                    product = Products.Workshop;
                    break;
                default:
                case ConstIntents.Blank:

                    return Products.Fuel;

            }

            return product.ToLower();
        }

        private string GetMailUser(string intent)
        {
            var product = ConvertIntentIntoProduct(intent);

            string emailAddress;
            switch (product)
            {
                case Products.Fuel:
                    emailAddress = ConfigurationManager.AppSettings[Email.Fuel];
                    break;
                case Products.Oil:
                    emailAddress = ConfigurationManager.AppSettings[Email.Oil];
                    break;
                case Products.Rope:
                    emailAddress = ConfigurationManager.AppSettings[Email.Rope];
                    break;
                case Products.Refrigerants:
                    emailAddress = ConfigurationManager.AppSettings[Email.Refrigerants];
                    break;
                case Products.Diesel:
                    emailAddress = ConfigurationManager.AppSettings[Email.Diesel];
                    break;
                case Products.GandA:
                    emailAddress = ConfigurationManager.AppSettings[Email.GandA];
                    break;
                case Products.Welding:
                    emailAddress = ConfigurationManager.AppSettings[Email.Welding];
                    break;
                case Products.Air:
                    emailAddress = ConfigurationManager.AppSettings[Email.Air];
                    break;
                case Products.Workshop:
                    emailAddress = ConfigurationManager.AppSettings[Email.Workshop];
                    break;

                default:
                    return ConfigurationManager.AppSettings[Email.Default];
            }

            return emailAddress;
        }
    }
}