﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WSS.ChatBot.Common;

namespace ChatBot.Common
{
    [Serializable]
    public class BotResponses
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public BotResponses(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            ListCreateDbData = listcreateDbData;
        }


        public static string Message1 { get; set; }
        public static string Message2 { get; set; }
        public static string Message3 { get; set; }
        public static string Message4 { get; set; }
        public static string Message5 { get; set; }
        public static string ElseMessage { get; set; }
        public static string FinalMessage { get; set; }

        public async Task AfterMenuSelection(IDialogContext context, IAwaitable<object> result)
        {
            var awaitableResult = await result;

            CosmosDbData.UserReplyWithoutIntent(context, awaitableResult.ToString());

            string message = "";

            if ((awaitableResult.ToString().Trim().Replace("&#160;", "").Trim() == "1") && (Message1 != ""))
            {
                message = Message1;
            }
            else if ((awaitableResult.ToString().Trim().Replace("&#160;", "").Trim() == "2") && (Message2 != ""))
            {
                message = Message2;
            }
            else if ((awaitableResult.ToString().Trim().Replace("&#160;", "").Trim() == "3") && (Message3 != ""))
            {
                message = Message3;
            }
            else if ((awaitableResult.ToString().Trim().Replace("&#160;", "").Trim() == "4") && (Message4 != ""))
            {
                message = Message4;
            }
            else if ((awaitableResult.ToString().Trim().Replace("&#160;", "").Trim() == "5") && (Message5 != ""))
            {
                message = Message5;
            }
            else
            {
                BlankMessage(context, out message);
                return;
            }

            MailContent.ChatDataForUserandBot(context, message);

            CosmosDbData.CosmosPromptMessage(message);

            await context.PostAsync(message);
            message = FinalMessage;//

            CosmosDbData.BotResponse2(message);

            CosmosDbData.CosmosSaveData(context: context, listCreateDbData: ListCreateDbData);

            MailContent.ChatDataForBot(context, message);

            await context.PostAsync(message);
        }

        private void BlankMessage(IDialogContext context, out string prompt)
        {
            prompt = ElseMessage;

            MailContent.ChatDataForUserandBot(context, prompt);

            CosmosDbData.CosmosBotResponse(prompt);

            CosmosDbData.CosmosSaveData(context: context, listCreateDbData: ListCreateDbData);

            PromptDialog.Text(context, AfterMenuSelection, prompt);
        }

        //public async Task YesOrNoOption(IDialogContext context, IAwaitable<string> result)
        //{
        //    var activity = await result;
        //    PromptDialog.Choice(context, this.YesOrNoButtonClick, new List<string> { ConstIntents.Yes, ConstIntents.No }, "Was I able to help resolve your query?", "Please select **Yes or No** to know if I have resolved your query!!", 3);
        //}
        //public async Task YesOrNoButtonClick(IDialogContext context, IAwaitable<object> result)
        //{
        //    var option = await result;
        //    string prompt = string.Empty;
        //    switch (option)
        //    {
        //        case ConstIntents.Yes:
        //            prompt = "Have a good day!";
        //            await context.PostAsync(prompt);
        //            context.Done<object>(null);
        //            break;

        //        case ConstIntents.No:
        //            await EmailYesOrNoOption(context);
        //            break;

        //        default:
        //            break;
        //    }
        //}


        //public async Task EmailYesOrNoOption(IDialogContext context)
        //{
        //    PromptDialog.Choice(context, this.EmailYesOrNoButtonClick, new List<string> { ConstIntents.EmailYes, ConstIntents.EmailNo }, "Should I send entire conversation to WSS support team?", "Please select **Yes or No** to know if I have to send entire conversation to WSS support team !!", 3);
        //}

        //public async Task EmailYesOrNoButtonClick(IDialogContext context, IAwaitable<object> result)
        //{
        //    var option = await result;
        //    string prompt = string.Empty;
        //    switch (option)
        //    {
        //        case ConstIntents.EmailYes:
        //            prompt = "I have sent the details to WSS customer support . You will hear from us very soon!";
        //            await context.PostAsync(prompt);
        //            context.Done<object>(null);
        //            break;

        //        case ConstIntents.EmailNo:
        //            prompt = "Thank you for contacting us. You will hear from us very soon!";
        //            await context.PostAsync(prompt);
        //            context.Done<object>(null);
        //            break;

        //        default:
        //            break;
        //    }
        //    context.Done<object>(null);
        //}

        //public async Task YesOrNoCard(IDialogContext context, IAwaitable<string> result)
        //{
        //    var option = await result;
        //}

        //    public async Task YesOrNoCard(IDialogContext context, IAwaitable<bool> result)
        //{
        //    try
        //    {
        //        var option = await result;
        //        string resultMessage = "No";
        //        if (option == true)
        //        {
        //            resultMessage = "Yes";
        //        }

        //        //var chatbody = MailContent.ChatDataForUserandBot(context, resultMessage);
        //        // MailContent.ChatDataForBot(context, resultMessage);

        //        CosmosDbData.UserReplyWithoutIntent(context, resultMessage);// .LogCreation(context, ReplyMsg, intent, messageActivity, ListCreateDbData);
        //        MailContent.ChatDataForUserandBot(context, resultMessage);

        //        //ListCreateDbData.Add(CreateDbData.Instance);
        //        //context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

        //        string prompt = string.Empty;
        //        switch (option)
        //        {
        //            case true:
        //                prompt = "Thank you for your time and have a nice day.";

        //                CosmosDbData.BotResponsewithQueryResolvedStatus(prompt, string.Empty, context, ListCreateDbData, "");
        //                MailContent.ChatDataForBot(context, prompt);

        //                context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);


        //                await context.PostAsync(prompt);
        //                context.Done<object>(null);
        //                break;

        //            case false:
        //                List<CardAction> cylinders = new List<CardAction>{
        //                new CardAction(ActionTypes.ImBack, title: ConstIntents.Yes, value: ConstIntents.Yes),
        //                new CardAction(ActionTypes.ImBack, ConstIntents.No, value: ConstIntents.No) };
        //                HeroCard card = new HeroCard { Text = "Should I send entire conversation to WSS support team?", Buttons = cylinders };
        //                var message = context.MakeMessage();
        //                message.Attachments.Add(card.ToAttachment());


        //                CosmosDbData.BotResponsewithQueryResolvedStatus(card.Text, string.Empty, context, ListCreateDbData, "no");
        //                MailContent.ChatDataForBot(context, card.Text);

        //                context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);


        //                await context.PostAsync(message);
        //                context.Done<object>(null);
        //                break;
        //            default:
        //                break;
        //        }
        //    }
        //    catch (Exception exp)
        //    {

        //        //throw;
        //    }


        //}

        public async Task EmailFunctionForIBot(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            string prompt = "";
            var response = await result;
            ChatBot.Common.MailContent mailContent = new MailContent(ListCreateDbData);

            CreateDbData.Instance.User = context.Activity.From.Name;
            CreateDbData.Instance.UserReply = response.Text.ToString();
            CreateDbData.Instance.UserRequestDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = string.Empty;
            CreateDbData.Instance.IsUserQueryResolved = "no";

            switch (response.Text.ToLower().Trim().Replace("&#160;", "").Trim())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case "1":
                    prompt = "I have sent the details to WSS customer support . You will hear from us very soon!";

                    CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
                    CreateDbData.Instance.BotResponse = prompt;
                    CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
                    CreateDbData.Instance.BotResponse2 = string.Empty;
                    //  CreateDbData.Instance.IsUserQueryResolved = string.Empty;
                    ListCreateDbData.Add(CreateDbData.Instance);
                    context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

                    await context.PostAsync(prompt);
                    break;

                case "no":
                case "2":
                    prompt = "Thank you for contacting us. You will hear from us very soon!";

                    CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
                    CreateDbData.Instance.BotResponse = prompt;
                    CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
                    CreateDbData.Instance.BotResponse2 = string.Empty;
                    // CreateDbData.Instance.IsUserQueryResolved = string.Empty;
                    ListCreateDbData.Add(CreateDbData.Instance);
                    context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);
                    await context.PostAsync(prompt);
                    break;

                default:

                    List<CardAction> yesno = new List<CardAction>{
                        new CardAction(ActionTypes.ImBack, title: ConstIntents.Yes, value: ConstIntents.Yes),
                        new CardAction(ActionTypes.ImBack, ConstIntents.No, value: ConstIntents.No) };
                    HeroCard card = new HeroCard { Text = $"Please select **Yes / No** to know if I have to send the conversation to WSS customer support.", Buttons = yesno };
                    var message = context.MakeMessage();
                    message.Attachments.Add(card.ToAttachment());
                    await context.PostAsync(message);


                    // prompt = @"Please enter **""Yes""** / **""No""** to know if I have to send the conversation to WSS customer support.";
                    mailContent.ChatDataForUserandBot(context, card.Text);

                    CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
                    CreateDbData.Instance.BotResponse = card.Text;
                    CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
                    CreateDbData.Instance.BotResponse2 = string.Empty;
                    // CreateDbData.Instance.IsUserQueryResolved = string.Empty;
                    ListCreateDbData.Add(CreateDbData.Instance);
                    context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);
                    // await context.PostAsync(prompt);
                    context.Wait(this.EmailFunctionForIBot);
                    // PromptDialog.Text(context, this.EmailFunctionForIBot, prompt);
                    return;
            }

            // var chatbody = mailContent.ChatDataForUserandBot(context, prompt);

            var chatbody = "";
            foreach (var data in ListCreateDbData)
            {
                chatbody = MailContent.ChatDataForUserandBot(data.User, data.Bot, data.UserReply, data.BotResponse);
                if (!string.IsNullOrEmpty(data.BotResponse2))
                {
                    chatbody = MailContent.ChatDataForBot(context, data.BotResponse2);
                }
            }

            await mailContent.SendingEmail(chatbody, context.Activity.From.Name);

            //ListCreateDbData.Clear(); //(Commented this line since it is not allowing to capture the previous query after saying yes or no)

            //context.EndConversation("End");
            context.Done<object>(null);

        }

        //First Time: Was I able to help resolve your query? Yes/No
        public async Task YesNoCard(IDialogContext context, string botResponse2Message)
        {
            List<CardAction> cardButtons = new List<CardAction>();
            List<CardAction> yesno = new List<CardAction> { new CardAction(ActionTypes.ImBack, title: ConstIntents.Yes, value: ConstIntents.Yes), new CardAction(ActionTypes.ImBack, ConstIntents.No, value: ConstIntents.No) };
            HeroCard card = new HeroCard { Text = botResponse2Message, Buttons = yesno };
            var makeMessage = context.MakeMessage();
            makeMessage.Attachments.Add(card.ToAttachment());
            await context.PostAsync(makeMessage);

        }      

            public static Attachment getGreeting(string uname, string title, string subtitle)
            {
                string text = "Hello " + uname;
                string html = "<b><p>" + text + " </p></b>";

                List<CardImage> cardImages = new List<CardImage>();
                cardImages.Add(new CardImage(url: "data:image/png; base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAN1wAADdcBQiibeAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAI9SURBVGiB7ZhNS9xQFIYfZRRsdeHW1qkWF9VNoaUzCGJLf9iIXVqVuigUdVfopuhK6U8oXersHIXSahcVi9jN + O3injBjzOe9NybRPBAynMx573tyP3ITKCjIHWVgBdiXYxUYSdWRBmXgH3DpOg6Axyn6is0KyvgaMAw8BdYl9jVFX7E5QpkebIs9kdhhEg12JiEKNOV80RZzfh8n1GYifKE1tAaAR7SG1ucUfcVmCNjj5mTfRQ2xXFEGlmkVscT1OZM7nEISJanJfuvc20JGgVmgDvxFLanuCe0 + HML + dyGam9LGqE5BYXQBC8BZBEO2jlPgA1CyVUQJ + CbiJ8AiUAH6gQ5bjYhWP1BFrXAn0uY6loqZE8E94KUNwYi8Av5I2zOmYmOoLm4Cz03FNHiB6plT4JmJ0Dzqjny0YEqXT + LhvYlIXUTGbTjSZEI8bJiI / BeRXhuONOkTD0cmImHbiwfAFNBAvRFuATWgx3KO8TYnSOAh8APvZ8B3MWwjJ8xHJIIE3sm1bWAS9Qx4DexIvGYpJ8xHJIIEnMbfuOJvJd6wlBPmw / fPQfuldo7xXgicydm8kaGXE8mbye73l5wrrnhVzj8t5cTG6 + 4H9ci0XPuNGu / dqPG + i / 9418mJ7S1uIWmvWtYKgevPhHPiP0ei5iReyG0R6u3evupmlqKQrOH1LpyFye2HrzfTl3rbRWt / zGgvxEska73jW6itb0buBi4149rcmcleFJI1ikKyRti6nZvl9870SEFBQlwBjAsRgpoX4JgAAAAASUVORK5CYII="));

                var greetingCard = new ThumbnailCard
                {
                    Title = title,
                    Subtitle = subtitle,
                    Images = cardImages
                };

                return greetingCard.ToAttachment();
            }

        }
    }
