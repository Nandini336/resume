﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ChatBot.Common
{
    [Serializable]
    public class Messages
    {

        public IDialogContext context { get; set; }
        public string displayTextMessage { get; set; }
        public string speakMessage { get; set; }
        public bool IsSpeak { get; set; }
        

        public IMessageActivity BotMessage(Messages messages)
        {
            var makeMessage = messages.context.MakeMessage();
            makeMessage.Speak = messages.speakMessage;
            makeMessage.Text = messages.displayTextMessage;
            makeMessage.InputHint = InputHints.AcceptingInput;
            return makeMessage;
        }
    }
}