﻿using AdaptiveCards;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;

/// <summary>
/// Common class for all intents in root dialog to capture cosmos db and mail conversation
/// </summary>

namespace ChatBot.Common
{
    public class QandA
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public string speakMessage { get; set; }
        public bool IsSpeak { get; set; }
        public QandA(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        public async Task MainWithIntent(IDialogContext context, IAwaitable<IMessageActivity> activity, string ReplyMsg, string intent)
        {

            var messageActivity = await activity;

            CosmosDbData.LogCreation(context, ReplyMsg, intent, messageActivity, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                Messages makeMessage = new Messages();
                makeMessage.context = context;
                makeMessage.displayTextMessage = ReplyMsg;
                makeMessage.IsSpeak = this.IsSpeak;
                makeMessage.speakMessage = this.speakMessage;

                messageActivity = makeMessage.BotMessage(makeMessage);

                await this.QandA_Response(context, activity, ReplyMsg, intent, messageActivity);
                //await context.PostAsync(messageActivity);

            }
            else
            {
                await this.QandA_Response(context, activity, ReplyMsg, intent);
            }

        }

        public async Task QandA_Response(IDialogContext context, IAwaitable<IMessageActivity> activity, string ReplyMsg, string intent)
        {
            var selection = new EndOfConversation(MailContent, ListCreateDbData);
            await activity;
           
            if (intent != ConstIntents.Blank.ToString())
            {
                string replyMessage = ReplyMsg +
             " \n\n\u200C<br/> \n\n\u200C<br/>"
             + WSS.ChatBot.Common.Common.YesOrNoSelection;

                await context.PostAsync(replyMessage);

                CosmosDbData.BotResponse(replyMessage, context, intent, ListCreateDbData);

                //  var chatbody = MailContent.ChatDataForUserandBot(context, ReplyMsg);
                //  MailContent.ChatDataForBot(context, WSS.ChatBot.Common.Common.YesOrNoSelection);

                // selection.Intent = intent;

                //  await context.PostAsync(WSS.ChatBot.Common.Common.YesOrNoSelection);
                //   MailContent.Intent = selection.Intent;

                //ListCreateDbData.Add(CreateDbData.Instance);
                //context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);
            }
            else
            {
                await context.PostAsync(ReplyMsg);

            }
            await selection.EndLevelConversation(context);
        }

        public async Task QandA_Response(IDialogContext context, IAwaitable<IMessageActivity> activity, string ReplyMsg, string intent, IMessageActivity messageActivity)
        {
            var makeMessage = context.MakeMessage();
            var selection = new EndOfConversation(MailContent, ListCreateDbData);
            await activity;

            var message = messageActivity.Text +
              " \n\n"
             + WSS.ChatBot.Common.Common.HeaderMessage;

            var speakMessage = messageActivity.Speak +
             WSS.ChatBot.Common.Common.HeaderMessage;

            if (intent != ConstIntents.Blank.ToString())
            {
                Attachment attachment = AdaptiveCardMessage(message, speakMessage);

                makeMessage.Attachments = new List<Attachment> { attachment };

                await context.PostAsync(makeMessage);
                context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);
            }
            else
            {
                await context.PostAsync(messageActivity);

            }
        }

        private Attachment AdaptiveCardMessage(string promptMessage, string speakMessage)
        {
            AdaptiveCard adaptiveCard = new AdaptiveCard()
            {
                Body = new List<AdaptiveElement>()
                {
                    new AdaptiveTextBlock()
                    {
                        
                       Text = promptMessage,
                       Wrap = true,
                    } 
                },
                Actions = new List<AdaptiveAction>()
                {
                    new AdaptiveSubmitAction()
                    {
                        Title = "Yes",
                        Data = "Yes"
                    },
                     new AdaptiveSubmitAction()
                    {
                        Title = "No",
                        Data = "No"
                    }
                }
            };

           // string speak = messageActivity.Speak + "." + WSS.ChatBot.Common.Common.HeaderMessage;
            adaptiveCard.Speak = speakMessage;


            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = adaptiveCard
            };
            return attachment;
        }
              
    }
}