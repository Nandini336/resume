﻿using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.Bot.Connector;

namespace ChatBot.Controllers
{
    public interface IMessagesController
    {
        Task<HttpResponseMessage> Post([FromBody] Activity activity);
    }
}