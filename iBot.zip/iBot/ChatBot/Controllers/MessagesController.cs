﻿using System;
using System.Collections.Generic;
using System.Net;
//using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using ChatBot.Dialogs;
using JSONUtils;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using WSS.ChatBot.Common;
using System.Configuration;
using Dialogs.Luis;
using System.Net.Http;
//using WSS.ChatBot.Common.Common;

namespace ChatBot.Controllers
{
    [BotAuthentication]
    public class MessagesController : ApiController, IMessagesController
    {
        /// <summary>
        /// POST: api/Messages
        /// Receive a message from a user and reply to it
        /// </summary>
         private readonly List<CreateDbData> _listcreateDbData = new List<CreateDbData>();

        // CreateDbData createDbData = new CreateDbData();

        public async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {
            var connector = new ConnectorClient(new Uri(activity.ServiceUrl));
            var isTyping = activity.CreateReply();
            isTyping.Type = ActivityTypes.Typing;

            var createDbData = CreateDbData.Instance;
            if (activity.Type == ActivityTypes.Message)
            {
               
                using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
                {
                    //  Get key values from the web.config

                    string LUIS_Url = "https://southeastasia.api.cognitive.microsoft.com/luis/v2.0/apps/5b32a666-1208-4210-93b9-ebcdcb940035?subscription-key=0f14503ddf8448689cbe568edf1f89b3&spellCheck=true&bing-spell-check-subscription-key={YOUR_BING_KEY_HERE}&verbose=true&timezoneOffset=0&q=";
                    // string LUIS_Url = LuisUrlPath + "/" + LuisSubscriptionId + "?subscription-key=" + AzureSubscriptionId + LuisSearchParam;

                    string RequestURI = String.Format("{0}{1}", LUIS_Url, activity.Text);

                    HttpResponseMessage msg = await client.GetAsync(RequestURI);

                    if (msg.IsSuccessStatusCode)
                    {
                        var JsonDataResponse = await msg.Content.ReadAsStringAsync();

                        var LUISResult = JsonConvert.DeserializeObject<LUIS>(JsonDataResponse);
                    }
                }
             

                activity.Text = activity.Text.Trim().Replace("&#160;", "");

                try
                {
                    await connector.Conversations.SendToConversationAsync(isTyping);
                    
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await Conversation.SendAsync(activity, () => new LuisDialog(_listcreateDbData));
                    }
                    else
                    {
                        await Conversation.SendAsync(activity, () => new QRootDialog(_listcreateDbData));
                    }
                }
                catch (Exception E)
                {

                    throw;
                }

                //await Conversation.SendAsync(activity, () => new ExceptionHandlerDialog<object>(
                //    new RootDialog(listcreateDbData),
                //    displayException: false));
            }
            
            using (var response = Request.CreateResponse(HttpStatusCode.OK))

            {
                return response;
            }
        }
        private Activity HandleSystemMessage(Activity message)
        {
            if (message.Type == ActivityTypes.DeleteUserData)
            {
                // Implement user deletion here
                // If we handle user deletion, return a real message
            }
            else if (message.Type == ActivityTypes.ConversationUpdate)
            {
                // Handle conversation state changes, like members being added and removed
                // Use Activity.MembersAdded and Activity.MembersRemoved and Activity.Action for info
                // Not available in all channels
            }
            else if (message.Type == ActivityTypes.ContactRelationUpdate)
            {
                // Handle add/remove from contact lists
                // Activity.From + Activity.Action represent what happened
            }
            else if (message.Type == ActivityTypes.Typing)
            {
                // Handle knowing tha the user is typing
            }
            else if (message.Type == ActivityTypes.Ping)
            {
            }

            return null;
        }
    }
}