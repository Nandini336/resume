﻿using Autofac;
using Microsoft.Bot.Builder.Azure;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Internals;
using Microsoft.Bot.Connector;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Reflection;
using System.Web.Configuration;
using System.Web.Http;
using WSS.ChatBot.Infrastructure;

namespace ChatBot
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            try
            {
                var docDbServiceEndpoint = new Uri(WebConfigurationManager.AppSettings["CosmosDBUrl"].ToString());
                var docDbKey = WebConfigurationManager.AppSettings["CosmosDBKey"].ToString();

                // Creating a data store based on DocumentDB
                var store = new DocumentDbBotDataStore(docDbServiceEndpoint, docDbKey);

                // Adding Azure dependencies to your bot (documentDB data store and Azure module)
                var builder = new ContainerBuilder();

                builder.RegisterModule(new AzureModule(Assembly.GetExecutingAssembly()));
              //  builder.RegisterModule(new DefaultExceptionMessageOverrideModule());

                // Key_DataStore is the key for data store register with the container
                builder.Register(c => store)
                    .Keyed<IBotDataStore<BotData>>(AzureModule.Key_DataStore)
                    .AsSelf()
                    .SingleInstance();


                builder.Register(c => new CachingBotDataStore(store,
                        CachingBotDataStoreConsistencyPolicy
                        .ETagBasedConsistency))
                        .As<IBotDataStore<BotData>>()
                        .AsSelf()
                        .InstancePerLifetimeScope();

                // After adding new dependencies, update the container
                builder.Update(Conversation.Container);
            }
            catch (Exception exp)
            {
                // ExceptionMail(exp);
            }
            GlobalConfiguration.Configure(WebApiConfig.Register);
        }

        private static void ExceptionMail(Exception exp)
        {
            var sendGridAppKey = WebConfigurationManager.AppSettings["SendGridAppKey"];
            string ChatTitle = "Message : " + exp.Message + " \n \n Stack Trace : " + exp.StackTrace;
            var client = new SendGridClient(sendGridAppKey.ToString());
            var msg = new SendGridMessage()
            {
                From = new EmailAddress("sj00504630@techmanhindra.com", "WSS Error"),
                Subject = "WSS ERROR !!!",
            };
            msg.AddContent(MimeType.Html, ChatTitle + "\n");
            msg.AddTo(new EmailAddress("sj00504630@techmanhindra.com", "WSS User"));
            client.SendEmailAsync(msg);
        }
    }
}
