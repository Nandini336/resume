﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using Dialogs.Luis;
using System.Collections.Generic;
using WSS.ChatBot.Common;
using ChatBot.Common;

namespace ChatBot.Dialogs
{
    [Serializable]
    public class IRootDialog : IDialog<object>
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public IRootDialog(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;
            await context.Forward(new LuisDialog(ListCreateDbData), ResumeAfterlLuisDialog, activity, CancellationToken.None);
        }

        private async Task ResumeAfterlLuisDialog(IDialogContext context, IAwaitable<object> result)
        {
            context.Wait(MessageReceivedAsync);
        }
    }
}