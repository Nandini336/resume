﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using System.Threading;
using System.Collections.Generic;
using Dialogs.CustomerSupport.Cylinder;
using Dialogs.CustomerSupport.Orders;
using Helper;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using ChatBot.Common;
using ChatBot.Dialogs.Fuel;
using JSONUtils;
using System.Web.Configuration;
using System.Configuration;
using ChatBot.Dialogs.Ropes;
using WSS.Chatbot.Dialogs.Dialogs.Ropes.Level_Conversations;
using WSS.Chatbot.Dialogs.Dialogs.Ropes;
using WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A;
using System.Text.RegularExpressions;
using System.Linq;
using WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.UVTracerkit;
using WSS.Chatbot.Dialogs.Dialogs.GandA;
using WSS.Chatbot.Dialogs.Dialogs.Fuel.CandM;
using WSS.Chatbot.Dialogs.Dialogs.Fuel.Welding;
using WSS.Chatbot.Dialogs.Dialogs.Welding;
using WSS.Chatbot.Dialogs.Dialogs.Air;
using WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.Others;

namespace Dialogs.Luis
{
    [Serializable]
    [LuisModel(Luis.ProductionModelId, Luis.ProductionSubscriptionId, LuisApiVersion.V2, Luis.Domain, Log = true, SpellCheck = true)]
    public class LuisDialog : LuisDialog<object>
    {
        Messages makeMessage = new Messages();

        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public LuisDialog(List<CreateDbData> listcreateDbData)
        {

            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        [LuisIntent(ConstIntents.Yes)]
        public async Task Yes(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var messageActivity = await activity;
            CosmosDbData.UserReplyWithoutIntent(context, messageActivity.Text.ToString());
            var prompt = "Thank you for your time and have a nice day.";

            MailContent = new MailContent(ListCreateDbData);

            CosmosDbData.BotResponsewithQueryResolvedStatus(prompt, string.Empty, context, ListCreateDbData, "");

            var chatbody = "";
            foreach (var data in ListCreateDbData)
            {
                chatbody = MailContent.ChatDataForUserandBot(data.User, data.Bot, data.UserReply, data.BotResponse);
                if (!string.IsNullOrEmpty(data.BotResponse2))
                {
                    chatbody = MailContent.ChatDataForBot(context, data.BotResponse2);
                }
            }
            await MailContent.SendingEmail(chatbody, context.Activity.From.Name);         

            context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);
            //ListCreateDbData.Clear();
            var makeMessage = context.MakeMessage();
            makeMessage.Speak = prompt;
            makeMessage.InputHint = InputHints.AcceptingInput;
            makeMessage.Text = prompt;
            await context.PostAsync(makeMessage);
            context.PrivateConversationData.RemoveValue(WSS.ChatBot.Common.Common.Conversation);
          //  context.EndConversation("End");
            var selection = new EndOfConversation();
            //await selection.EndLevelConversation(context);
            context.Done<object>(null);
            //await selection.EndLevelConversation(context);
        }

        [LuisIntent(ConstIntents.No)]
        public async Task No(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var messageActivity = await activity;
            CosmosDbData.UserReplyWithoutIntent(context, messageActivity.Text.ToString());
            List<CardAction> yesno = new List<CardAction>{
                        new CardAction(ActionTypes.ImBack, title: ConstIntents.Yes, value: ConstIntents.Yes),
                        new CardAction(ActionTypes.ImBack, ConstIntents.No, value: ConstIntents.No) };
            HeroCard card = new HeroCard { Text = "Should I send entire conversation to WSS support team?", Buttons = yesno };
            var message = context.MakeMessage();
            message.Attachments.Add(card.ToAttachment());
            await context.PostAsync(message);

            CosmosDbData.BotResponsewithQueryResolvedStatus(card.Text, string.Empty, context, ListCreateDbData, "no");

            MailContent = new MailContent(ListCreateDbData);

            var intent = ListCreateDbData[0].Intent;
            MailContent.Intent = intent;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            context.Wait(botResponses.EmailFunctionForIBot);
        }

        [LuisIntent("")]
        [LuisIntent(Intents.None)]
        public async Task None(IDialogContext context, LuisResult result)
        {
            var makeMessage = context.MakeMessage();
            string message = $"Sorry, I did not understand **{result.Query}**. Ask me something else.";
            string input = result.Query;
            string order_number = string.Empty;
            string promptMessage = string.Empty;           
            Regex expression = new Regex(@"[-a-zA-Z0-9]{9,}");            
            Match match = expression.Match(input);
            bool isDigitPresent = match.ToString().Any(c => char.IsDigit(c));

            if (match.Success && match.Length == 9 && isDigitPresent == true)
            {
                order_number = match.Value;
                await context.Forward(new Order_Status(order_number), ResumeAfterProductDialog, context.Activity, CancellationToken.None);
            }

            makeMessage.Speak = message;
            makeMessage.InputHint = InputHints.AcceptingInput;
            makeMessage.Text = message;
            await context.PostAsync(makeMessage);
            context.Wait(MessageReceived);
        }

        [LuisIntent(ConstIntents.Thanks)]
        public async Task Thanks(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var title = $"You are welcome {context.Activity.From.Name}.";
            string subtitle = " It was nice talking to you. Have a nice day !!";

            var makeMessage = context.MakeMessage();

            var attachment = BotResponses.getGreeting(context.Activity.From.Name, title, subtitle);

            makeMessage.Attachments.Add(attachment);

            makeMessage.Speak = title + subtitle;
            makeMessage.InputHint = InputHints.AcceptingInput;

            await context.PostAsync(makeMessage);
        }

        [LuisIntent(ConstIntents.ByeIntent)]
        public async Task Bye_Intent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var title = $"It was nice talking to you {context.Activity.From.Name}.";
            string subtitle = "Have a nice day !!";

            var makeMessage = context.MakeMessage();

            var attachment = BotResponses.getGreeting(context.Activity.From.Name, title, subtitle);

            makeMessage.Attachments.Add(attachment);

            makeMessage.Speak = title + subtitle;
            makeMessage.InputHint = InputHints.AcceptingInput;

            await context.PostAsync(makeMessage);
        }

        [LuisIntent(Intents.Greetings)]
        public async Task Greeting(IDialogContext context, LuisResult result)
        {
            var makeMessage = context.MakeMessage();
            string title = $"Hi {context.Activity.From.Name} !! I am IBot.";
            string subtitle = " and I can help resolve your queries . \n Go ahead and talk to me.";

            var attachment = BotResponses.getGreeting(context.Activity.From.Name, title, subtitle);

            makeMessage.Attachments.Add(attachment);

            await context.PostAsync(makeMessage);

        }

        [LuisIntent(Intents.LearningStage)]
        public async Task LearningStage(IDialogContext context, LuisResult result)
        {
            IMessageActivity messageActivity;
            string message = "Hey, I'm still learning and getting better with every conversation. Ask me something else.";

            string speakMessage = "Hey, I'm still learning and getting better with every conversation. Ask me something else.";

            makeMessage.context = context;
            makeMessage.displayTextMessage = message;
            makeMessage.IsSpeak = true;
            makeMessage.speakMessage = speakMessage;
            messageActivity = makeMessage.BotMessage(makeMessage);

            await context.PostAsync(messageActivity);
        }

        [LuisIntent(Intents.Bye)]
        public async Task Bye(IDialogContext context, LuisResult result)
        {
            var makeMessage = context.MakeMessage();
            string message = "It was nice talking to you. Have a nice day !!";
            makeMessage.Speak = message;
            makeMessage.Text = message;
            makeMessage.InputHint = InputHints.AcceptingInput;
            await context.PostAsync(makeMessage);
        }

        private ResumeAfter<object> after()
        {
            return null;
        }

        [LuisIntent(Intents.Order_Count)]
        public async Task ProductNumber(IDialogContext context, LuisResult result)
        {
            await context.Forward(new OrderCount(), ResumeAfterProductDialog, context.Activity, CancellationToken.None);
        }

        [LuisIntent(Intents.All_Orders)]
        public async Task All_Orders(IDialogContext context, LuisResult result)
        {
            await context.Forward(new All_Orders(), ResumeAfterProductDialog, context.Activity, CancellationToken.None);
        }

        [LuisIntent(Intents.Order_Status)]
        public async Task Order_Status(IDialogContext context, LuisResult result)
        {
            string input = result.Query;
            string order_number = string.Empty;
            string promptMessage = string.Empty;            
            Regex expression = new Regex(@"[-a-zA-Z0-9]{9,}");
            Match match = expression.Match(input);
            bool isDigitPresent = match.ToString().Any(c => char.IsDigit(c));
            if (match.Success && match.Length == 9 && isDigitPresent == true)
            {
                order_number = match.Value;
                await context.Forward(new Order_Status(order_number), ResumeAfterProductDialog, context.Activity, CancellationToken.None);
            }
            else
            {
                promptMessage = "Please enter valid order number";
                await context.PostAsync(promptMessage);
            }

            //TODO: Get the order number from //[-a-zA-Z0-9]{9} regex and send it to the item.Entity
            // string order_number = @"[-a-zA-Z0-9]{9}";

            //foreach (var item in result.Entities)
            //{
            //    if (item.Type.Equals("OrderNumberRegexEntity"))
            //    {
            //        await context.Forward(new Order_Status(item.Entity), ResumeAfterProductDialog, context.Activity, CancellationToken.None);
            //    }
            //}
            //string promptMessage = "Please enter valid order number";
            //await context.PostAsync(promptMessage);
        }

        [LuisIntent(Intents.Show_Cylinders)]
        public async Task Show_Cylinders(IDialogContext context, LuisResult result)
        {
            await context.Forward(new Cylinders_Details(), ResumeAfterProductDialog, context.Activity, CancellationToken.None);
        }

        [LuisIntent(Intents.Cylinders_by_Vessel)]
        public async Task Cylinders_by_Vessel(IDialogContext context, LuisResult result)
        {
            await context.Forward(new Cylinders_by_Vessel(), ResumeAfterProductDialog, context.Activity, CancellationToken.None);
        }

        [LuisIntent(Intents.Cylinders_by_Type)]
        public async Task Cylinders_by_Type(IDialogContext context, LuisResult result)
        {
            await context.Forward(new Cylinders_by_Type(), ResumeAfterProductDialog, context.Activity, CancellationToken.None);
        }

        private async Task ResumeAfterProductDialog(IDialogContext context, IAwaitable<object> result)
        {
            // context.EndConversation("End");
            context.Done<object>(null);
        }

        //G&A 29 cases (Easy clean, laundry, galley, skin care, shelf life)

        [LuisIntent(ConstIntents.EasyClean_Window_And_Mirror)]
        public async Task EasyClean_Window_And_Mirror(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Spray **EasyClean Window & Mirror** on the surface at a concentration of 0.5 % to 1 %, wipe dry with a squeegee, dry cloth or paper towel. \n\n" +
                 "2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-window-mirror) for more product info.";

            var qandA = new QandA(this.ListCreateDbData);

            const string speakMessage = "Spray EasyClean Window and Mirror on the surface at a concentration of 0.5 % to 1 %, wipe dry with a squeegee, dry cloth or paper towel.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;

            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.EasyClean_Window_And_Mirror);
        }

        [LuisIntent(ConstIntents.EasyClean_SoftSurface_And_Spot)]
        public async Task EasyClean_SoftSurface_And_Spot(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Remove excess contamination. Spray **EasyClean Soft Surface & Spot** on the stain, brush in with a cloth, leave to dry overnight and vacuum up the residue when dry. Repeat if needed. \n\n" +
               "2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-soft-surface-spot) for more product info.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Remove excess contamination. Spray EasyClean Soft Surface and Spot on the stain, brush in with a cloth, leave to dry overnight and vacuum up the residue when dry. Repeat if needed";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.EasyClean_SoftSurface_And_Spot);
        }

        [LuisIntent(ConstIntents.EasyClean_Floor_And_Hard_Surface)]
        public async Task EasyClean_Floor_And_Hard_Surface(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Spray **EasyClean Floor & Hard Surface** on the surface, rub with a rag and wipe clean. \n\n" +
              "2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-floor-hard-surface) for more product info.  ";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Spray EasyClean Floor and Hard Surface on the surface, rub with a rag and wipe clean.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.EasyClean_Floor_And_Hard_Surface);
        }

        [LuisIntent(ConstIntents.EasyClean_Basin_And_ToiletBowl)]
        public async Task EasyClean_Basin_And_ToiletBowl(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "Spray a 1% solution of **EasyClean Basin & Toilet Bowl** on the surface, scrub and rinse with water. For in case of the toilet bowl, also see **Gamazyme TDS ** .";
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Spray a 1% solution of EasyClean Basin and Toilet Bowl on the surface, scrub and rinse with water. For in case of the toilet bowl, also see Gamazyme TDS";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.EasyClean_Basin_And_ToiletBowl);
        }

        //Accomodation_Gamazyme
        [LuisIntent(ConstIntents.Gamazyme_BTC)]
        public async Task Gamazyme_BTC(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Start using **Gamazyme BTC** as toilet cleaner. The microorganisms will break down and disappear the organic material that causes the smell in the pipes \n\n" +
                " 2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-btc-12-x-1-ltr) for product details: ";
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = " Start using Gamazyme BTC as toilet cleaner. The microorganisms will break down and disappear the organic material that causes the smell in the pipes";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Gamazyme_BTC);
        }

        [LuisIntent(ConstIntents.Gamazyme_TDS)]
        public async Task Gamazyme_TDS(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. For Toilets and Urinals: Add one sachet of **Gamazyme TDS** per toilet every 2 to 3 weeks to dissolve urine-scale, and to maintain a healthy microbiological environment in the pipes and sewage system. \n\n" +
                " 2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-tds) for product details: ";
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = " For Toilets and Urinals, Add one sachet of Gamazyme TDS per toilet every 2 to 3 weeks to dissolve urine-scale, and to maintain a healthy microbiological environment in the pipes and sewage system.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Gamazyme_TDS);
        }

        [LuisIntent(ConstIntents.Gamazyme_Digestor)]
        public async Task Gamazyme_Digestor(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. For Toilets and Urinals: Add one sachet of **Gamazyme TDS** per toilet every 2 to 3 weeks to dissolve urine-scale, and to maintain a healthy microbiological environment in the pipes and sewage system. \n\n" +
                " 2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-tds) for more information on the product details. ";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "For shower, Use 500ml of Gamazyme Digestor per 5cm drain diameter to break down the organic matter. After the blockage is removed a small maintenance dose of Gamazyme Digestor daily will assist in keeping the pipes open.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Gamazyme_Digestor);
        }

        [LuisIntent(ConstIntents.Gamazyme_BOE)]
        public async Task Gamazyme_BOE(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Spray **Gamazyme BOE** onto soft surfaces like curtains, carpets and furniture in the cabin. This will remove cigarette smoke smell and other odours.\n\n" +
                " 2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-boe-12x1-l?tab=ordering&all=1#ordering-tab) for more info on product details.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Spray Gamazyme BOE onto soft surfaces like curtains, carpets and furniture in the cabin. This will remove cigarette smoke smell and other odours.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Gamazyme_BOE);
        }

        //Galley_EasyClean

        [LuisIntent(ConstIntents.Easyclean_Cleaning_And_DisInfection_Sanite128F)]
        public async Task Easyclean_Cleaning_And_DisInfection_Sanite128F(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "If heavily soiled or dirty, clean first with **EasyClean Floor & Hard Surface**. Followed by or if not heavily soiled, clean and disinfect with **EasyClean Cleaning & Disinfection ** or ** Sanite 128 F.**\n\n" +
                "If food is going off quicker ion cold storage, then this might be due to bacteria or fungi growth in the cold storage.Perform a proper cleaning and disinfection with **EasyClean Cleaning & Disinfection** or **Sanite 128 F.**";
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "If heavily soiled or dirty, clean first with EasyClean Floor and Hard Surface. Followed by or if not heavily soiled, clean and disinfect with EasyClean Cleaning and Disinfection or Sanite 128 F.If food is going off quicker ion cold storage, then this might be due to bacteria or fungi growth in the cold storage.Perform a proper cleaning and disinfection with EasyClean Cleaning and Disinfection or Sanite 128 F";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Easyclean_Cleaning_And_DisInfection_Sanite128F);
        }

        [LuisIntent(ConstIntents.Galley_Easyclean_Oven_And_Grill)]
        public async Task Galley_Easyclean_Oven_And_Grill(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Spray **EasyClean Oven & Grill** undiluted on cold surfaces, leave for 15 - 60 minutes and rinse properly with water. \n\n" +
               "2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-oven-grill) for more product info.";
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Spray EasyClean Oven and Grill undiluted on cold surfaces, leave for 15 to 60 minutes and rinse properly with water.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Galley_Easyclean_Oven_And_Grill);
        }

        [LuisIntent(ConstIntents.Galley_Easyclean_Dishwashing_LiquidManual)]
        public async Task Galley_Easyclean_Dishwashing_LiquidManual(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Scrape off excess and clean/scrub with a solution of **EasyClean Dishwashing Liquid Manual** in warm water." +
              " Ensure that there is a layer of foam on top of the cleaning solution to protect against redepositing of the oils and fat.Rinse off with water. \n\n" +
              "2. If in case of oil and greese on plates and cultery: \n\n Replace the cleaning water with a fresh solution of **EasyClean Dishwashing Liquid Manual** at a concentration of 7 ml / 10 Liter. \n\n" +
              "3. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-dishwash-liquid-manual) for more product info.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Scrape off excess and clean or scrub with a solution of EasyClean Dishwashing Liquid Manual in warm water . Ensure that there is a layer of foam on top of the cleaning solution to protect against redepositing of the oils and fat.Rinse off with water .If in case of oil and greese on plates and cultery: Replace the cleaning water with a fresh solution of EasyClean Dishwashing Liquid Manual at a concentration of 7 ml / 10 Liter.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Galley_Easyclean_Dishwashing_LiquidManual);
        }

        [LuisIntent(ConstIntents.Galley_Easyclean_Hand_Sanitizer)]
        public async Task Galley_Easyclean_Hand_Sanitizer(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Start using **EasyClean Hand Sanitizer** before work is started in the galley, between different operations in the galley " +
                "and also make sureguests sanitize their hands with **EasyClean Hand Sanitizer** before entering the eating area. \n\n" +
                "2.  [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-hand-sanitizer) for more product info.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Start using EasyClean Hand Sanitizer before work is started in the galley, between different operations in the galley and also make sureguests sanitize their hands with EasyClean Hand Sanitizer before entering the eating area";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Galley_Easyclean_Hand_Sanitizer);
        }

        //Galley_Gamazyme
        [LuisIntent(ConstIntents.Galley_Gamazyme_Boe)]
        public async Task Galley_Gamazyme_Boe(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Spray **Gamazyme BOE** into the garbage shoot and the foul smell will disappear.  \n\n " +
                "2.[Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-boe-12x1-l) for more info on product details. ";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Spray Gamazyme BOE into the garbage shoot and the foul smell will disappear.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Galley_Gamazyme_Boe);
        }

        [LuisIntent(ConstIntents.Galley_Gamazyme_Digestor)]
        public async Task Galley_Gamazyme_Digestor(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Dose **Gamazyme Digestor** into the grease trap at about 2 litre per  m³ after every work day, and it will start to attack the blockage and remove the bad smell.\n\n" +
                "  2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-digestor-20-ltr-bag-in-box) for more product details";

            //const string replyMsg = "Dose **Gamazyme Digestor** into the grease trap at about 2 litre per m³ after every work day, and it will start to attack the blockage and remove the bad smell.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Dose Gamazyme Digestor into the grease trap at about 2 litre per m³ after every work day, and it will start to attack the blockage and remove the bad smell. ";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Galley_Gamazyme_Digestor);
        }

        //Drains
        [LuisIntent(ConstIntents.Drains_Gamazyme700_FN)]
        public async Task Drains_Gamazyme700_FN(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "Dose **Gamazyme 700 FN** on a regular basis until the planned maintenance.The microorganisms will break down organic material to water(H²O) and carbon dioxide(CO²).\n\n" +
               "In case of any foul smell: \n\n Add the desired dose of **Gamazyme 700 FN** into the tank or through the toilets closest to the tanks.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Dose Gamazyme 700 FN on a regular basis until the planned maintenance.The microorganisms will break down organic material to water H²O and carbon dioxide CO².In case of any foul smell, Add the desired dose of Gamazyme 700 FN into the tank or through the toilets closest to the tanks.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Drains_Gamazyme700_FN);
        }


        //Laundry
        [LuisIntent(ConstIntents.Easyclean_Laundry_Conditioner)]
        public async Task Easyclean_Laundry_Conditioner(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Start to dose 10 ml of **EasyClean Laundry Conditioner** in the dosing chamber or at the final rinse.\n\n" +
               "2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-laundry-conditioner) for more product info.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Start to dose 10 ml of EasyClean Laundry Conditioner in the dosing chamber or at the final rinse.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Easyclean_Laundry_Conditioner);
        }

        [LuisIntent(ConstIntents.Easyclean_Laundry_Powder_ForLaundry)]
        public async Task Easyclean_Laundry_Powder_ForLaundry(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. This might be because of hard water from bunkering of shore water, increase dosage of the " +
                "**EasyClean Laundry Powder** from 50 to 80 grams or **EasyClean Laundry Tablets** from 1 to 2 pcs. \n\n" +
                "2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-laundry-powder) for more product info on powder.";


            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "This might be because of hard water from bunkering of shore water, increase dosage of the EasyClean Laundry Powder from 50 to 80 grams or EasyClean Laundry Tablets from 1 to 2 pcs";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Easyclean_Laundry_Powder_ForLaundry);
        }

        [LuisIntent(ConstIntents.Easyclean_Laundry_Powder_SkinRash)]
        public async Task Easyclean_Laundry_Powder_SkinRash(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Use EasyClean Laundry Powder. in case of very dirty clothes or tough stains increase dosage from 50 to 80 gms and if using tablets increase dosage from 1 to 2 tablets .\n\n" +
                "2. In case you experience rash or itching - The dosed amount of the **EasyClean Laundry Powder** or **Tablets** is too much for the machine to rinse off.Reduce the dosage or use a different cleaning program with more rinsing cycles. \n\n" +
                "3. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-laundry-powder-pack) for more product info on powder.\n\n" +
                "4. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-laundry-tablet-pack) for more product info on tablets.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Use EasyClean Laundry Powder. in case of very dirty clothes or tough stains increase dosage from 50 to 80 gms and if using tablets increase dosage from 1 to 2 tablets .in case you experience rash or itching . The dosed amount of the EasyClean Laundry Powder or Tablets is too much for the machine to rinse off.Reduce the dosage or use a different cleaning program with more rinsing cycles.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Easyclean_Laundry_Powder_SkinRash);
        }

        //SkinCare

        [LuisIntent(ConstIntents.SkinCare_EasyClean_Liquid_Hand_Soap_D)]
        public async Task SkinCare_Liquid_Hand_Soap_D_HandsWithOil(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Wet/rinse the hands with water. Massage the **EasyClean Liquid Hand Soap ( D )** onto the soiled skin and rinse with water. " +
                " Dry thoroughly with a clean cloth or paper towel.They are mild on the skin even with excellent cleaning effect. \n\n" +
                " 2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-liquid-hand-soap-d=) for more product info. ";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Wet/rinse the hands with water. Massage the EasyClean Liquid Hand Soap D onto the soiled skin and rinse with water. Dry thoroughly with a clean cloth or paper towel.They are mild on the skin even with excellent cleaning effect";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.SkinCare_EasyClean_Liquid_Hand_Soap_D);
        }


        [LuisIntent(ConstIntents.SkinCare_EasyClean_Hand_Sanitizer)]
        public async Task SkinCare_Hand_Sanitizer(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Many conventional hand sanitizers are alcohol based, and many of them dry out the skin. " +
                  "**EasyClean Hand Sanitizer** is based on a different technology that sanitizes for a longer time period and moistens the skin.  \n\n" +
                  "2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-hand-sanitizer) for more product info.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Many conventional hand sanitizers are alcohol based, and many of them dry out the skin.EasyClean Hand Sanitizer is based on a different technology that sanitizes for a longer time period and moistens the skin.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.SkinCare_EasyClean_Hand_Sanitizer);
        }

        [LuisIntent(ConstIntents.SkinCare_EasyClean_Hand_Barrier_Cream_Wet)]
        public async Task SkinCare_EasyClean_Hand_Barrier_Cream_Wet(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "Before work, apply 1 pump (1-2 ml) of **EasyClean Hand Barrier Cream Wet**. Rub well into the skin, especially around nails and cuticles." +
                 "If hands are washed before end of work, re-apply the cream for maximum protection.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Before work, apply 1 pump 1-2 ml of EasyClean Hand Barrier Cream Wet. Rub well into the skin, especially around nails and cuticles.If hands are washed before end of work, re-apply the cream for maximum protection.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.SkinCare_EasyClean_Hand_Barrier_Cream_Wet);
        }

        [LuisIntent(ConstIntents.SkinCare_EasyClean_Hand_Barrier_Cream_Dry)]
        public async Task SkinCare_EasyClean_Hand_Barrier_Cream_Dry(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Before work, apply 1 pump (1-2 ml) of **EasyClean Hand Barrier Cream Dry**. Rub well into the skin, especially around nails and cuticles." +
                 "If hands are washed before end of work, re-apply the cream for maximum protection.  \n\n" +
                 "2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-hand-barrier-cream-dry) for more product info.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Before work, apply 1 pump 1-2 ml of EasyClean Hand Barrier Cream Dry. Rub well into the skin, especially around nails and cuticles.If hands are washed before end of work, re-apply the cream for maximum protection.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.SkinCare_EasyClean_Hand_Barrier_Cream_Dry);
        }

        [LuisIntent(ConstIntents.SkinCare_EasyClean_After_Work_Lotion)]
        public async Task SkinCare_EasyClean_After_Work_Lotion(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. Start using **EasyClean After Work Lotion** at the end of the working day. Clean and dry hands thoroughly." +
                "Apply 1 - 3 ml of the lotion and rub well into skin. \n\n" +
                "2. [Click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-afterwork-lotion) for more product info.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = " Start using EasyClean After Work Lotion at the end of the working day. Clean and dry hands thoroughly.Apply 1 - 3 ml of the lotion and rub well into skin";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.SkinCare_EasyClean_After_Work_Lotion);
        }

        [LuisIntent(ConstIntents.SkinCare_EasyClean_Natural_Hand_Cleaner)]
        public async Task SkinCare_EasyClean_Natural_Hand_Cleaner(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "Start using **Natural Hand Cleaner**. This is a heavy duty cleaner that is mild to the skin while removing the most stubborn grime, oil and grease contaminants.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Start using Natural Hand Cleaner. This is a heavy duty cleaner that is mild to the skin while removing the most stubborn grime, oil and grease contaminants.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.SkinCare_EasyClean_Natural_Hand_Cleaner);
        }

        //Shelf Life
        [LuisIntent(ConstIntents.Cleaning_Shelf_life_Gamayzme_TDS)]
        public async Task Cleaning_Shelf_life_Gamayzme_TDS(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var cleaning_Shelf_life_Gamayzme_TDS = new Cleaning_Shelf_life_Gamayzme_TDS(this.ListCreateDbData);
            await cleaning_Shelf_life_Gamayzme_TDS.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Cleaning_Shelf_life_Gamazyme_700FN)]
        public async Task Cleaning_Shelf_life_Gamazyme_700FN(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var cleaning_Shelf_life_Gamazyme_700FN = new Cleaning_Shelf_life_Gamazyme_700FN(this.ListCreateDbData);
            await cleaning_Shelf_life_Gamazyme_700FN.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Cleaning_Shelf_life_Gamazyme_BTC)]
        public async Task Cleaning_Shelf_life_Gamazyme_BTC(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var cleaning_Shelf_life_Gamazyme_BTC = new Cleaning_Shelf_life_Gamazyme_BTC(this.ListCreateDbData);
            await cleaning_Shelf_life_Gamazyme_BTC.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Cleaning_Shelf_life_Gamazyme_DPC)]
        public async Task Cleaning_Shelf_life_Gamazyme_DPC(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var cleaning_Shelf_life_Gamazyme_DPC = new Cleaning_Shelf_life_Gamazyme_DPC(this.ListCreateDbData);
            await cleaning_Shelf_life_Gamazyme_DPC.MainAsync(context, activity, ListCreateDbData);

        }

        //Rope cases (39) 

        [LuisIntent(ConstIntents.RopesConventional)]
        public async Task RopesConventional(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Conventional ropesConventional = new Ropes_Conventional(this.ListCreateDbData);
            await ropesConventional.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.RopesConventionalNylon)]
        public async Task Ropes_Conventional_Nylon(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var ropes_Conventional_Nylon = new Ropes_Conventional_Nylon(this.ListCreateDbData);
            await ropes_Conventional_Nylon.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.RopesConventionalPolyPropylene)]
        public async Task Ropes_Conventional_PolyPropylene(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            RopesConventionalPolyPropylene convPolyPropelene = new RopesConventionalPolyPropylene(this.ListCreateDbData);
            await convPolyPropelene.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Ropes_AceraScott)]
        public async Task Ropes_AceraScott(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var ropes_AceraScott = new Ropes_AceraScott(this.ListCreateDbData);
            await ropes_AceraScott.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.RopesCertification)]
        public async Task Ropes_Certification(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Certification ropesCertification = new Ropes_Certification(this.ListCreateDbData);
            await ropesCertification.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_Stretcher)]
        public async Task Ropes_Stretcher(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Stretcher ropes_Stretcher = new Ropes_Stretcher(this.ListCreateDbData);
            await ropes_Stretcher.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.RopeAccessories)]
        public async Task Rope_Accessories(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Rope_Accessories rope_Accessories = new Rope_Accessories(this.ListCreateDbData);
            await rope_Accessories.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_Sikka)]
        public async Task Ropes_Sikka(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Sikka ropes_Sikka = new Ropes_Sikka(this.ListCreateDbData);
            await ropes_Sikka.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_StretcherRecommendation)]
        public async Task Ropes_StretcherRecommendation(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_StretcherRecommendation ropes_StretcherRecommendation = new Ropes_StretcherRecommendation(this.ListCreateDbData);
            await ropes_StretcherRecommendation.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_SteelWire)]
        public async Task Ropes_SteelWire(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_SteelWire ropes_SteelWire = new Ropes_SteelWire(this.ListCreateDbData);
            await ropes_SteelWire.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_SBA)]
        public async Task Ropes_SBA(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_SBA ropes_SBA = new Ropes_SBA(this.ListCreateDbData);
            await ropes_SBA.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_MixType)]
        public async Task Ropes_MixType(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_MixType mixType = new Ropes_MixType(this.ListCreateDbData);
            await mixType.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_Main)]
        public async Task Ropes_Main(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Main ropesMain = new Ropes_Main(this.ListCreateDbData);
            await ropesMain.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_DalrympleBay)]
        public async Task Ropes_DalrympleBay(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_DalrympleBay ropeDalrympleBay = new Ropes_DalrympleBay(this.ListCreateDbData);
            await ropeDalrympleBay.MainAsync(context, activity, ListCreateDbData);

        }
        [LuisIntent(ConstIntents.Ropes_Lines)]
        public async Task Ropes_Lines(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Lines ropes_Lines = new Ropes_Lines(this.ListCreateDbData);
            await ropes_Lines.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_HeavingLine)]
        public async Task Ropes_HeavingLine(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_HeavingLine ropes_HeavingLine = new Ropes_HeavingLine(this.ListCreateDbData);
            await ropes_HeavingLine.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_PilotLadder)]
        public async Task Ropes_PilotLadder(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_PilotLadder ropes_PilotLadder = new Ropes_PilotLadder(this.ListCreateDbData);
            await ropes_PilotLadder.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_FlagLine)]
        public async Task Ropes_FlagLine(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_FlagLine ropes_FlagLine = new Ropes_FlagLine(this.ListCreateDbData);
            await ropes_FlagLine.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_RatGuard)]
        public async Task Ropes_RatGuard(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_RatGuard ropes_RatGuard = new Ropes_RatGuard(this.ListCreateDbData);
            await ropes_RatGuard.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_ManilaRope)]
        public async Task Ropes_ManilaRope(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_ManilaRope ropes_ManilaRope = new Ropes_ManilaRope(this.ListCreateDbData);
            await ropes_ManilaRope.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_TigerRope)]
        public async Task Ropes_TigerRope(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_TigerRope ropes_TigerRope = new Ropes_TigerRope(this.ListCreateDbData);
            await ropes_TigerRope.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_MessengerLine)]
        public async Task Ropes_MessengerLine(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_TigerRope ropes_TigerRope = new Ropes_TigerRope(this.ListCreateDbData);
            await ropes_TigerRope.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_MinaAlAhmadi)]
        public async Task Ropes_MinaAlAhmadi(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_MinaAlAhmadi ropes_MinaAlAhmadi = new Ropes_MinaAlAhmadi(this.ListCreateDbData);
            await ropes_MinaAlAhmadi.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_OCIMF4)]
        public async Task Ropes_OCIMF4(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_OCIMF4 ropes_OCIMF4 = new Ropes_OCIMF4(this.ListCreateDbData);
            await ropes_OCIMF4.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_Spliced)]
        public async Task Ropes_Spliced(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Spliced ropes_Spliced = new Ropes_Spliced(this.ListCreateDbData);
            await ropes_Spliced.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_SmartRope)]
        public async Task Ropes_SmartRope(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_SmartRope ropes_SmartRope = new Ropes_SmartRope(this.ListCreateDbData);
            await ropes_SmartRope.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_StockPoints)]
        public async Task Ropes_StockPoints(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_StockPoints ropes_StockPoints = new Ropes_StockPoints(this.ListCreateDbData);
            await ropes_StockPoints.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.INT_RS_PSD)]
        public async Task INT_RS_PSD(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            INT_RS_PSD iNT_RS_PSD = new INT_RS_PSD(this.ListCreateDbData);
            await iNT_RS_PSD.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_CowHitch)]
        public async Task Ropes_CowHitch(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_CowHitch ropes_CowHitch = new Ropes_CowHitch(this.ListCreateDbData);
            await ropes_CowHitch.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_Cutter)]
        public async Task Ropes_Cutter(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Cutter ropes_Cutter = new Ropes_Cutter(this.ListCreateDbData);
            await ropes_Cutter.MainAsync(context, activity, ListCreateDbData);
        }
        [LuisIntent(ConstIntents.Ropes_RubberMooringSnubber)]
        public async Task Ropes_RubberMooringSnubber(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_RubberMooringSnubber ropes_RubberMooringSnubber = new Ropes_RubberMooringSnubber(this.ListCreateDbData);
            await ropes_RubberMooringSnubber.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_StretcherRingtailSingleTail)]
        public async Task Ropes_StretcherRingtailSingleTail(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_StretcherRingtailSingleTail ropes_StretcherRingtailSingleTail = new Ropes_StretcherRingtailSingleTail(this.ListCreateDbData);
            await ropes_StretcherRingtailSingleTail.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_Atlas)]
        public async Task Ropes_Atlas(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Atlas ropes_Atlas = new Ropes_Atlas(this.ListCreateDbData);
            await ropes_Atlas.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_TimmWinchline)]
        public async Task Ropes_TimmWinchline(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_TimmWinchline ropes_TimmWinchline = new Ropes_TimmWinchline(this.ListCreateDbData);
            await ropes_TimmWinchline.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_TimmMaster8)]
        public async Task Ropes_TimmMaster8(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var ropesTimmMaster8 = new Ropes_TimmMaster8(this.ListCreateDbData);
            await ropesTimmMaster8.MainAsync(context, activity, ListCreateDbData);

        }
        [LuisIntent(ConstIntents.Ropes_MeasuringDiameter)]
        public async Task Ropes_MeasuringDiameter(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_MeasuringDiameter ropes_MeasuringDiameter = new Ropes_MeasuringDiameter(this.ListCreateDbData);
            await ropes_MeasuringDiameter.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_PanamaCanal)]
        public async Task Ropes_PanamaCanal(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_PanamaCanal ropes_PanamaCanal = new Ropes_PanamaCanal(this.ListCreateDbData);
            await ropes_PanamaCanal.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_TCLL)]
        public async Task Ropes_TCLL(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_TCLL ropes_TCLL = new Ropes_TCLL(this.ListCreateDbData);
            await ropes_TCLL.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_TypeApproval)]
        public async Task Ropes_TypeApproval(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_TypeApproval ropes_TypeApproval = new Ropes_TypeApproval(this.ListCreateDbData);
            await ropes_TypeApproval.MainAsync(context, activity, ListCreateDbData);
        }

        [LuisIntent(ConstIntents.Ropes_Eyes)]
        public async Task Ropes_Eyes(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes_Eyes ropes_Eyes = new Ropes_Eyes(this.ListCreateDbData);
            await ropes_Eyes.MainAsync(context, activity, ListCreateDbData);
        }

        //Ropes 25 excel sheet (Acera dagama cases)
        [LuisIntent(ConstIntents.Ropes_Acera_Products_EDP)]
        [LuisIntent(ConstIntents.Ropes_Acera)]
        public async Task RopesMain(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var messageActivity = await activity;

            var entities = result.Entities;
            LUIS lUIS = new LUIS();

            if (entities.Count == 0)
            {
                WebConfigurationManagerForBot webConfigurationManagerForBot
                 = new WebConfigurationManagerForBot
                 {
                     AzureSubscriptionId = EnvironmentValues.ProductionSubscriptionId,
                     LuisSearchParam = "&spellCheck=true&verbose=true&timezoneOffset=0&",
                     LuisSubscriptionId = EnvironmentValues.ProductionModelId,
                     LuisUrlPath = WebConfigurationManager.AppSettings["LuisURL"]
                 };

                var luisQuery = Uri.EscapeDataString(messageActivity.Text.Trim().Replace("&#160;", "").Trim());
                lUIS = await HttpData.GetLuisResult(lUIS, luisQuery, webConfigurationManagerForBot);
            }
            else
            {
                lUIS = HttpData.WithoutHttpCall(result, entities);
            }

            try
            {
                Context.DoAlgorithm(lUIS, this.ListCreateDbData, context, activity);
            }
            catch (Exception e)
            {
                await context.PostAsync("Oops!! Something went wrong.... Can you please try again !!");
            }
        }

        [LuisIntent(ConstIntents.HeavySludgeVarious)]
        public async Task Heavy_Sludge_Various(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            await activity;

            var message = " Solution: Unitor FuelPower™ Conditioner Product number: 778785 helps resolve issues with - fuel stability and compatibility, increasing instbility problem with chemicals contamination like phenol, styrene, DCPD, Indene in modern marine heavy fuels, especially with blending of low sulfur fuels  \n\n" +
                              "    For more product info please  [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-conditioner) ";


            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.HeavySludgeVarious);
        }

        //Heavy intents apart from re-structure
        [LuisIntent(ConstIntents.HeavyWater)]
        public async Task Heavy_Water(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            await activity;

            var message = " 1. Cause: Incompatible fuel or high water content.   \n\n" +
                " 2. Solution: Demulsify the water in fuel with FuelPower Demulsifier. " +
                " For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-demulsifier?tab=direction&all=1#direction-tab) \n\n" +
                " 3. Normal recommended dosage rate is 1ltr:5 tons of fuel.  \n\n" +
                " 4. Benefits: Unitor™ FuelPower™ Demulsifier rapidly breaks water-in-oil emulsions in all grades of fuel. " +
                "It assists water removal in the settling tank and fuel centrifuges, helps clear separation of water and oil phase, easy for crew to drain out water, helps purifier separate out water more easily and reduction in sludge reduces your maintenance requirements.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.HeavyWater);
        }

        //Oiltest intents apart from re-structure
        [LuisIntent(ConstIntents.OiltestWater)]
        public async Task Oiltest_Water(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            await activity;

            var replyMsg = "1. Solution for water in oil: Our highest seling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs." +
                              " The DIGI Combined Oil Test Kit from Unitor comes complete with tests for Water in Oil, Total Base Number (TBN), Salt, Insolubles and a Viscosity comparison test.  \n\n " +
                              " 2. For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-easy-ship-combined-oil-test-kit)";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.OiltestWater);
        }

        [LuisIntent(ConstIntents.OilBiofuelsulphide)]
        public async Task Oil_Biofuelsulphide(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {

            await activity;
            const string replyMsg = "1. If the fuel is bought according to the new ISO 8217:2017 the bio fuel used should comply with ASTM D6751 and there is a limit on the sulfide content. If the fuel is contaminated it is very difficult to know where the bio-fuel comes from.\n\n" +
                              "2. As a receommendation  DieselPower MAR 71, product nos: 571257 is a good H2S scavenger and can be used as long as the vessel is outside of US and Canada to remove the H2S if needed.\n\n" +
                              "3. For more information on product please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/distillate-fuel-treatment/dieselpowerx-mar-71-25-ltr)";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.OilBiofuelsulphide);
        }

        //workshop
        [LuisIntent(ConstIntents.Workshop_Equipment_Drill)]
        public async Task Workshop_Equipment_Drill(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "Percussion drill 660W 230V (779027),  Percussion drill 1100W 230V (779026) Metal drill 250W 230V (779021), Battery drill 10.8V (779025) Battery drill 18V(779024), Drill bit set in inch (614005) and Drill bit set in mm(614002).";
            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Workshop_Equipment_Drill);

        }

        [LuisIntent(ConstIntents.Workshop_Equipment_Grinder)]
        public async Task Workshop_Equipment_Grinder(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = @"We have 5"" electric grinder(729022), 7"" electric grinder (779028) and 9"" electric grinder(779023).";
            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Workshop_Equipment_Grinder);
        }

        // [LuisIntent(ConstIntents.Ropes_Availability)]
        // [LuisIntent(ConstIntents.Ropes_Queries)]
        // [LuisIntent(ConstIntents.Welding1)]
        // [LuisIntent(ConstIntents.Welding2)]
        [LuisIntent(ConstIntents.OilTest)]
        [LuisIntent(ConstIntents.Heavy)]
        [LuisIntent(ConstIntents.Diesel)]
        [LuisIntent(ConstIntents.CandM1)]
        [LuisIntent(ConstIntents.CandM2)]
        public async Task Heavy(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            try
            {
                var messageActivity = await activity;
                //TODO: check for candm_1 and candm_2 intents. Create a function to return the correct intent. 
                //It should be placed in Common Class. The method should be extension for intent.
                CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, result.Intents[0].Intent);

                var fuelContext = new FuelContext
                {
                    _listCreateDbData = this.ListCreateDbData,
                    mailContent = MailContent
                };

                fuelContext.DoAlgorithmForFuel(context, activity, result);
            }
            catch (Exception e)
            {
                await context.PostAsync("Oops!! Something went wrong.... Can you please try again !!");
            }
        }

        [LuisIntent("M&R_Intent")]
        public async Task MandR(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            try
            {
                var messageActivity = await activity;

                WebConfigurationManagerForBot webConfigurationManagerForBot
                    = new WebConfigurationManagerForBot
                    {
                        AzureSubscriptionId = WebConfigurationManager.AppSettings["MandRSubsId"],
                        LuisSearchParam = "&spellCheck=true&verbose=true&timezoneOffset=0&",
                        LuisSubscriptionId = WebConfigurationManager.AppSettings["MandRLuisId"],
                        LuisUrlPath = WebConfigurationManager.AppSettings["LuisURL"]
                    };


                var luisResult = new LUIS();

                var luisQuery = Uri.EscapeDataString(messageActivity.Text.Trim().Replace("&#160;", "").Trim());
                luisResult = await HttpData.GetLuisResult(luisResult, luisQuery, webConfigurationManagerForBot);

                Context.DoAlgorithm(luisResult, this.ListCreateDbData, context, activity);
            }
            catch (Exception ex)
            {
                await context.PostAsync("Oops!! Something went wrong.... Can you please try again !!");
            }

        }

        [LuisIntent(ConstIntents.Refrigerant_UV_Tracer_Kit_12V)]
        public async Task Refrigerant_UV_Tracer_Kit_12V(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Refrigerant_UV_Tracer_Kit_12V refrigerant_UV_Tracer_Kit_12V = new Refrigerant_UV_Tracer_Kit_12V(this.ListCreateDbData);
            await refrigerant_UV_Tracer_Kit_12V.MainAsync(context, activity, ListCreateDbData);
        }

        //Remaining cases apart from 106 cases
        [LuisIntent(ConstIntents.Vessel_Slip_Coat_Plus_25_Ltr)]
        public async Task Slip_Coat_Plus_25_Ltr(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {

            const string replyMsg = "Yes - This is a standard product available and is ok to use. Please contact WSS for further technical details or refer to the product catalogue.";
            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Vessel_Slip_Coat_Plus_25_Ltr);
        }

        [LuisIntent(ConstIntents.Vessel_Oxytreat_25_Ltr)]
        public async Task Oxytreat_25_Ltr(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            await activity;

            const string replyMsg = "No. We advise you to replace this product by Oxygen Scavenger 25 ltr plus. The dosage of Oxygen scavanger plus is 1 ltr per ton of water compared to Oxytreat which was 1.5.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Vessel_Oxytreat_25_Ltr);
        }

        [LuisIntent(ConstIntents.C_M_Deck_Clean_NP)]
        public async Task C_M_Deck_Clean_NP(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var C_M_Deck_Clean_NP = new C_M_Deck_Clean_NP(this.ListCreateDbData);
            await C_M_Deck_Clean_NP.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.C_M_Defoamer_Concentrate)]
        public async Task C_M_Defoamer_Concentrate(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var C_M_Defoamer_Concentrate = new C_M_Defoamer_Concentrate(this.ListCreateDbData);
            await C_M_Defoamer_Concentrate.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.What_is_Montreal_Protocol)]
        public async Task What_is_Montreal_Protocol(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            await activity;

            Refrigerant_What_is_Montreal_Protocol refrigerant_What_Is_Montreal_Protocol = new Refrigerant_What_is_Montreal_Protocol();
            string replyMsg = refrigerant_What_Is_Montreal_Protocol.DoAlgorithm();
            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.What_is_Montreal_Protocol);
        }


        //Refrigerants 7FAQs
        [LuisIntent(ConstIntents.Refrigerants_Price_On_Request)]
        public async Task Refrigerants_Price_On_Request(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "As you may be aware, the recent regulatory change in the refrigerant market has put tremendous volatility on refrigerant price and its availability. The price of Fluorspar, a key raw material for all refrigerants (e.g.R134a, R404A, R407C, R410A, R417A, etc) has hit a 4 - year high this year.\n\n" +
                "Strict enforcement of government regulations, license renewals, and plant shut down in China have also affected the supply of HFC components, which in turn impacted global refrigerant pricing.\n\n" +
                "Furthermore, the phasedown of HFC and import quota system in EU have put further uncertainty to the refrigerant price. Currently, the refrigerant price is driven by these external factors and it varies from time to time. So, putting refrigerants price on request will allow customer to get a fair price offer based on the market situation.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerants_Price_On_Request);
        }

        [LuisIntent(ConstIntents.Refrigerants_Price_Change)]
        public async Task Refrigerants_Price_Change(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "Prices of medium GWP HFCs are effected by the price increase in raw materials. On top or the raw material price, high GWP HFCs are under additional pressure due to global movement towards HFCs with lower GWP.\n\n" +
                " Under the F-gas regulation in EU, High GWP HFCs will be phased out from 1st Jan 2020 and other regions are expected to follow. So, we expect prices of high GWP HFCs to grow drastically, especially in EU due to HFC import quota system. \n\n" +
                " Medium GWP HFCs:  R134a, R407C, R407F, R410A, R417A, R427A \n\n" +
                " High GWP HFCs: R404A, R507, R422D";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerants_Price_Change);
        }

        [LuisIntent(ConstIntents.Refrigerants_HFC_Quota)]
        public async Task Refrigerants_HFC_Quota(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "Quota can only be used for the calendar year that it is issued, e.g. only for imports/production in the period between 1 January to 31 December of that year. \n\n" +
                "Once the HFC quota is fully consumed, the whole EU are unable to import / produce any more HFCs within that year. Regardless of how much money the customers are willing to pay, they will have to wait until January next year for the HFCs delivery in EU.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerants_HFC_Quota);
        }

        [LuisIntent(ConstIntents.Refrigerants_Anti_Dumping)]
        public async Task Refrigerants_Anti_Dumping(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {

            const string replyMsg = "An anti-dumping duty is a protective tariff that a domestic government imposes on imports that it believes are priced below fair market value. Currently, US imports of HFCs from China are subject to anti-dumping duties between 100% to 200%. Consequently, it has also contributed to the HFC price increase.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerants_Anti_Dumping);
        }

        [LuisIntent(ConstIntents.Refrigerants_F_gas)]
        public async Task Refrigerants_F_gas(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Refrigerants_F_gas refrigerants_F_gas = new Refrigerants_F_gas();
            string replyMsg = refrigerants_F_gas.DoAlgorithm();
            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerants_F_gas);
        }

        [LuisIntent(ConstIntents.Refrigerants_Continue_R404A_and_R507)]
        public async Task Refrigerants_Continue_R404A_and_R507(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "Please be reassured that we will still have ample stock in the network for customers who want to continue using the R-404A and R-507 refrigerants despite the high price. We understand that some customers are willing to pay the higher price because their systems cannot be changed immediately, and that they may need some adjustment time before transiting to a new refrigerant option.  Customers who operate globally may want to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants.";
            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerants_Continue_R404A_and_R507);
        }

        [LuisIntent(ConstIntents.Refrigerants_Move_Away_from_R404A_and_R507)]
        public async Task Refrigerants_Move_Away_from_R404A_and_R507(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "1. There are numerous replacements for R-404A available, most of them with a considerably lower GWP than 3922. However, those options are either not compatible with the existing system or will incur huge retrofitting cost. \n\n\n\n" +
                               "2. In WSS, we recommend Unicool R - 407F as the drop -in replacement for R - 404A in existing system, after extensive testing of the available options. R407F does not required any form of technical upgrade or retrofitting works and able to maintain satisfactory performance.\n\n\n\n" +
                               "3. You can learn more <a href = 'https://www.wilhelmsen.com/marine-products/refrigeration-solutions/mixing-it-up-with-407f/'> here</a> \n\n";


            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerants_Move_Away_from_R404A_and_R507);
        }

        [LuisIntent(ConstIntents.Refrigerants_in_WSS_standard_cylinders)]
        public async Task Refrigerants_in_WSS_standard_cylinders(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Refrigerants_in_WSS_standard_cylinders refrigerants_In_WSS_Standard_Cylinders = new Refrigerants_in_WSS_standard_cylinders();
            string replyMsg = refrigerants_In_WSS_Standard_Cylinders.DoAlgorithm();
            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerants_in_WSS_standard_cylinders);
        }

        [LuisIntent(ConstIntents.Refrigerant_Recovery)]
        public async Task Refrigerant_Recovery(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "The Refrigerant Recovery Package consists of carefully selected quality equipment designed to handle recovery from a vessel's refrigeration systems in a controlled manner.Electrical equipment is set for 115 V / 230V and 50 / 60 Hz.  \n\n\n\n " +
                              "The package consists of the following: \n\n\n\n " +
                              "1. Refrigerant recovery unit \n\n\n\n " +
                              "2. Hand Held Refrigerant Leak Detector(UNIRX - 1A) and the maintenance kit (sensing tips)\n\n\n\n " +
                              "3. Digital Weighing Platform\n\n\n\n " +
                              "4. Vacuum Pump \n\n\n\n " +
                              "5. Digital Vacuum Gauge \n\n\n\n " +
                              "6. deluxe manifold Set 4 - way and Valve Adaptor Set.\n\n\n\n " +
                              "7. Recovery Cylinder 21.6L  \n\n\n\n" +
                              " Besides that, WSS also offer large 56L Recovery Cylinder (Product No: 632588)";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerant_Recovery);
        }

        [LuisIntent(ConstIntents.Refrigerant_Leak_Detection)]
        public async Task Refrigerant_Leak_Detection(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "To keep your system free of leaks and working at its optimum we provide a complete range of leak detection kits.  \n\n\n\n " +
                              "1. Refrigerant Leak Monitor Kit  \n\n\n\n " +
                              "     The refrigerant leak monitor kit is an economical solution to provide round the-clock leak detection. The kit consists of a monitor, sensors and cables which enables you to monitor up to 6 locations for all types of refrigerants (CFC, HCFC and HFC).  \n\n\n\n" +
                              "2. Hand Held Leak Detector  \n\n\n\n " +
                              "     The hand held refrigerant leak detector enabling you to perform refrigerant leak inspection and fnd leaks in your system. It is battery powered and able to detect all types of refrigerants(CFC, HCFC and HFC).The sensing tip need to be changed after 30 hours of usage to ensure detection accuracy.  \n\n\n\n" +
                              "3. UV Tracer Kit  \n\n\n\n " +
                              "     The refrigerant leak detection kit able to locate refrigerant leaks in inaccessible areas by circulating the tracer ﬂuid and using UV light.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerant_Leak_Detection);
        }

        [LuisIntent(ConstIntents.Refrigerant_Return_of_Full_Cylinder)]
        public async Task Refrigerant_Return_of_Full_Cylinder(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            const string replyMsg = "Only Full refrigerant cylinders delivered less than 4 years ago and for which the seal is intact, the filling weight indicates a full cylinder and the cylinder is in a good condition, can be accepted for refund.  \n\n\n\n" +
                               "Full refrigerant cylinders shall always be subject to a re-stocking fee or a reduced refund. Note that Refrigerants are subject to import restrictions in many places (return from a foreign flag vessel is considered as an import). Returns cannot be agreed with Customer unless Supply Coordination at the receiving place has authorized the return.\n\n\n\n" +
                               "Restocking fee is to be set to a minimum 15% of the original sales price. Credit is always based on the original sales price at the moment the cylinder was delivered. \n\n\n\n" +
                               "Full refrigerant cylinders delivered more than 4 year ago can only be returned after approval of Product Management. \n\n\n\n" +
                                " **Note:** the recovery cylinder is sold to customer and it is not part of the cylinder exchange program.";


            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerant_Return_of_Full_Cylinder);
        }

        [LuisIntent(ConstIntents.Refrigerant_Recovery_Cylinder)]
        public async Task Refrigerant_Recovery_Cylinder(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Refrigeration_Recovery_Cylinder refrigeration_Recovery_Cylinder = new Refrigeration_Recovery_Cylinder();
            string replyMsg = refrigeration_Recovery_Cylinder.DoAlgorithm();
            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.Refrigerant_Recovery_Cylinder);
        }


        //Welding cases
        // Welding 
        [LuisIntent(ConstIntents.Welding_Accessories)]
        public async Task Welding_Accessories(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingAccessories = new Welding_Accessories(this.ListCreateDbData);
            await weldingAccessories.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Cutting_Torches)]
        public async Task Welding_Cutting_Torches(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingCuttingTorches = new Welding_Cutting_Torches(this.ListCreateDbData);
            await weldingCuttingTorches.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Cutting_Torches_1)]
        public async Task Welding_Cutting_Torches_1(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingCuttingTorches1 = new Welding_Cutting_Torches_1(this.ListCreateDbData);
            await weldingCuttingTorches1.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Electrode_Competitor)]
        public async Task Welding_Electrode_Competitor(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingElectrodeCompetitor = new Welding_Electrode_Competitor(this.ListCreateDbData);
            await weldingElectrodeCompetitor.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Electrode_Competitor_1)]
        public async Task Welding_Electrode_Competitor_1(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingElectrodeCompetitor1 = new Welding_Electrode_Competitor_1(this.ListCreateDbData);
            await weldingElectrodeCompetitor1.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Electrode_Competitor_2)]
        public async Task Welding_Electrode_Competitor_2(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingElectrodeCompetitor2 = new Welding_Electrode_Competitor_2(this.ListCreateDbData);
            await weldingElectrodeCompetitor2.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Electrode_Competitor_3)]
        public async Task Welding_Electrode_Competitor_3(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingElectrodeCompetitor3 = new Welding_Electrode_Competitor_3(this.ListCreateDbData);
            await weldingElectrodeCompetitor3.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Electrode_Competitor_4)]
        public async Task Welding_Electrode_Competitor_4(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingElectrodeCompetitor4 = new Welding_Electrode_Competitor_4(this.ListCreateDbData);
            await weldingElectrodeCompetitor4.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Electrode_Competitor_5)]
        public async Task Welding_Electrode_Competitor_5(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingElectrodeCompetitor5 = new Welding_Electrode_Competitor_5(this.ListCreateDbData);
            await weldingElectrodeCompetitor5.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Electrode_Competitor_6)]
        public async Task Welding_Electrode_Competitor_6(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingElectrodeCompetitor6 = new Welding_Electrode_Competitor_6(this.ListCreateDbData);
            await weldingElectrodeCompetitor6.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Flashback_Arrestor)]
        public async Task Welding_Flashback_Arrestor(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingFlashBackArrestor = new Welding_Flashback_Arrestor(this.ListCreateDbData);
            await weldingFlashBackArrestor.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Machine_1)]
        public async Task Welding_Machine(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingFlashBackArrestor = new Welding_Machine_1(this.ListCreateDbData);
            await weldingFlashBackArrestor.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Open_Circuit_Voltage)]
        public async Task Welding_Open_Circuit_Voltage(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingOpenCircuitVoltage = new Welding_Open_Circuit_Voltage(this.ListCreateDbData);
            await weldingOpenCircuitVoltage.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Oxygen_Acetylene_Gas_Hoses)]
        public async Task Welding_Oxygen_Acetylene_Gas_Hoses(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var welding_Oxygen_Acetylene_Gas_Hoses = new Welding_Oxygen_Acetylene_Gas_Hoses(this.ListCreateDbData);
            await welding_Oxygen_Acetylene_Gas_Hoses.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Plasma_Machine)]
        public async Task Welding_Plasma_Machine(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingPlasmamachine = new Welding_Plasma_Machine(this.ListCreateDbData);
            await weldingPlasmamachine.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Plasma_Machine_1)]
        public async Task Welding_Plasma_Machine_1(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingPlasmamachine1 = new Welding_Plasma_Machine_1(this.ListCreateDbData);
            await weldingPlasmamachine1.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Regulator_Oxygen_Acetylene)]
        public async Task Welding_Regulator_Oxygen_Acetylene(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingRegulatorOxygenAcetylene = new Welding_Regulator_Oxygen_Acetylene(this.ListCreateDbData);
            await weldingRegulatorOxygenAcetylene.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Rod)]
        public async Task Welding_Rod(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingRod = new Welding_Rod(this.ListCreateDbData);
            await weldingRod.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Rod_1)]
        public async Task Welding_Rod_1(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingRod1 = new Welding_Rod_1(this.ListCreateDbData);
            await weldingRod1.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Stick_Electrode)]
        public async Task Welding_Stick_Electrode(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingStickElectrode = new Welding_Stick_Electrode(this.ListCreateDbData);
            await weldingStickElectrode.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Cylinder_Trolley)]
        public async Task Welding_Cylinder_Trolley(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingCylinderTrolley = new Welding_Cylinder_Trolley(this.ListCreateDbData);
            await weldingCylinderTrolley.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Welding_Wire)]
        public async Task Welding_Wire(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var weldingWire = new Welding_Wire(this.ListCreateDbData);
            await weldingWire.MainAsync(context, activity, ListCreateDbData);

        }

        //Air

        [LuisIntent(ConstIntents.Air_Distributor)]
        public async Task Air_Distributor(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_Distributor = new Air_Distributor(this.ListCreateDbData);
            await air_Distributor.MainAsync(context, activity, ListCreateDbData);

        }
        [LuisIntent(ConstIntents.Air_Hose_Clamp)]
        public async Task Air_Hose_Clamp(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_Hose_Clamp = new Air_Hose_Clamp(this.ListCreateDbData);
            await air_Hose_Clamp.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Air_tools_quick_coupling)]
        public async Task Air_tools_quick_coupling(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_tools_quick_coupling = new Air_tools_quick_coupling(this.ListCreateDbData);
            await air_tools_quick_coupling.MainAsync(context, activity, ListCreateDbData);

        }


        [LuisIntent(ConstIntents.Air_Gun)]
        public async Task Air_Gun(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_Gun = new Air_Gun(this.ListCreateDbData);
            await air_Gun.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Air_Die_Grinder)]
        public async Task Air_Die_Grinder(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_Die_Grinder = new Air_Die_Grinder(this.ListCreateDbData);
            await air_Die_Grinder.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Air_Scaling_Hammer)]
        public async Task Air_Scaling_Hammer(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_Scaling_Hammer = new Air_Scaling_Hammer(this.ListCreateDbData);
            await air_Scaling_Hammer.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Air_Hose)]
        public async Task Air_Hose(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_Hose = new Air_Hose(this.ListCreateDbData);
            await air_Hose.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Air_Angle_Grinder)]
        public async Task Air_Angle_Grinder(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_Angle_Grinder = new Air_Angle_Grinder(this.ListCreateDbData);
            await air_Angle_Grinder.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Air_Deck_Scaler)]
        public async Task Air_Deck_Scaler(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_Deck_Scaler = new Air_Deck_Scaler(this.ListCreateDbData);
            await air_Deck_Scaler.MainAsync(context, activity, ListCreateDbData);

        }

        [LuisIntent(ConstIntents.Air_tools_impact_wrench)]
        public async Task Air_tools_impact_wrench(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var air_tools_impact_wrench = new Air_tools_impact_wrench(this.ListCreateDbData);
            await air_tools_impact_wrench.MainAsync(context, activity, ListCreateDbData);

        }

    }
}