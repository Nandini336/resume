﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace WSS.ChatBot.Infrastructure
{
    public interface IMandRIntentStrategy
    {
        string DoAlgorithm();
        string DoAlgorithmForSpeak();
    } 

  
    public interface IPostData
    {
        //string speakMessage { get; set; }
        Task DoPostData(List<CreateDbData> listCreateDbData, IDialogContext context, IAwaitable<IMessageActivity> activity, string intent,  string botReplyMessage, string speakMessage);
    }

}