﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;

namespace WSS.ChatBot.Infrastructure
{
    public class PostData : IPostData
    {
        

        public async Task DoPostData(List<CreateDbData> listCreateDbData, IDialogContext context, IAwaitable<IMessageActivity> activity, string intent, string botReplyMessage, string speakMessage)
        { 
            var qandA = new QandA(listCreateDbData);

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, botReplyMessage, intent.GetIntent());
        }
    }
}
