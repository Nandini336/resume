﻿using WSS.ChatBot.Common;
using ChatBot.Dialogs.MandR_Refrigerant.Intents;
using ChatBot.Dialogs.MandR_Refrigerant.Intents.Availability;
using ChatBot.Dialogs.MandR_Refrigerant.Intents.GuideLines;
using ChatBot.Dialogs.MandR_Refrigerant.Intents.MoveAway;
using ChatBot.Dialogs.MandR_Refrigerant.Intents.OtherIntents;
using ChatBot.Dialogs.MandR_Refrigerant.Intents.Replace;
using ChatBot.Dialogs.MandR_Refrigerant.Intents.Retrofit;
using ChatBot.Dialogs.MandR_Refrigerant.Intents.Topup;
using JSONUtils;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using ChatBot.Common;
using WSS.Chatbot.Dialogs.Dialogs.Ropes;
using WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.Cylinders;
using WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.UVtracerKit;
using WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.About;
using WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.Others;

namespace WSS.ChatBot.Infrastructure
{

    public class Context
    {
        //This is for Level conversation Class Name. Need to add the class name for levels
        private static List<string> _exceptionList = new List<string>();

        // This is for direct Q&A types
        private static Dictionary<string, IMandRIntentStrategy> _QandAstrategies =
                new Dictionary<string, IMandRIntentStrategy>();

        //This is for Level conversation Strategies. We will put all the scenerios where we dont have direct Q&A.
        private static Dictionary<string, IPostData> _levelConversationStrategies =
               new Dictionary<string, IPostData>();

        static Context()
        {
            //This is for Level conversation Class Name
            _exceptionList.Add("R448A_Availability");
            _exceptionList.Add("R449A_Availability");
            _exceptionList.Add("R22_Replace");
            _exceptionList.Add("R22_Retrofit");

            //This is for Level conversation Strategies. We will put all the scenerios where we dont have direct Q&A.
            _levelConversationStrategies.Add(ConstIntents.PostData.ToString(), new PostData());

            _levelConversationStrategies.Add(ConstIntents.R448A_Availability.ToString(), new Availability());
            _levelConversationStrategies.Add(ConstIntents.R449A_Availability.ToString(), new Availability());
            _levelConversationStrategies.Add(ConstIntents.R22_Replace.ToString(), new R22ReplaceRetrofit());
            _levelConversationStrategies.Add(ConstIntents.R22_Retrofit.ToString(), new R22ReplaceRetrofit());

           

            // This is for direct Q&A types
            _QandAstrategies.Add(ConstIntents.Blank.ToString(), new BlankPage());

            _QandAstrategies.Add(ConstIntents.R404A_Availability.ToString(), new R404A_Availability());
            _QandAstrategies.Add(ConstIntents.R22_Availability.ToString(), new R22_Availability());
            _QandAstrategies.Add(ConstIntents.R407F_Availability.ToString(), new R407F_Availability());
            _QandAstrategies.Add(ConstIntents.R507_Availability.ToString(), new R507_Availability());
            _QandAstrategies.Add(ConstIntents.R422D_Availability.ToString(), new R422D_Availability());

            _QandAstrategies.Add(ConstIntents.R410A_Availability.ToString(), new Refrigerants_in_WSS_standard_cylinders());
            _QandAstrategies.Add(ConstIntents.R427A_Availability.ToString(), new Refrigerants_in_WSS_standard_cylinders());
            _QandAstrategies.Add(ConstIntents.R134A_Availability.ToString(), new Refrigerants_in_WSS_standard_cylinders());
            _QandAstrategies.Add(ConstIntents.R417A_Availability.ToString(), new Refrigerants_in_WSS_standard_cylinders());

            _QandAstrategies.Add(ConstIntents.R407F_R404A_Replace.ToString(), new R407F_R404A_Replace());
            _QandAstrategies.Add(ConstIntents.R404A_R407F_Replace.ToString(), new R404A_R407F_Replace());
            _QandAstrategies.Add(ConstIntents.R404A_Replace.ToString(), new R404A_Replace());
            _QandAstrategies.Add(ConstIntents.R407F_R507_Replace.ToString(), new R407F_R507_R407F_Replace());
            _QandAstrategies.Add(ConstIntents.R507_R407F_Replace.ToString(), new R507_R407F_Replace());
            _QandAstrategies.Add(ConstIntents.R507_Replace.ToString(), new R507_R407F_Replace());
            _QandAstrategies.Add(ConstIntents.R422D_Replace.ToString(), new R422D_Replace());

            _QandAstrategies.Add(ConstIntents.R404A_Price.ToString(), new R404A_Price());
            _QandAstrategies.Add(ConstIntents.R407F_Price, new R407F_Price());

            _QandAstrategies.Add(ConstIntents.R404A_Refrigerants_Continue_R404A_and_R507.ToString(), new R404A_Refrigerants_Continue_R404A_and_R507());
            _QandAstrategies.Add(ConstIntents.R507_Refrigerants_Continue_R404A_and_R507.ToString(), new R507_Refrigerants_Continue_R404A_and_R507());
            _QandAstrategies.Add(ConstIntents.R404A_R507_Refrigerants_Continue_R404A_and_R507.ToString(), new R404A_R507_Refrigerants_Continue_R404A_and_R507());
            _QandAstrategies.Add(ConstIntents.R507_R404A_Refrigerants_Continue_R404A_and_R507.ToString(), new R507_R404A_Refrigerants_Continue_R404A_and_R507());
            

            _QandAstrategies.Add(ConstIntents.R404A_Refrigerants_Move_Away_from_R404A_and_R507.ToString(), new R404A_Refrigerants_Move_Away_from_R404A_and_R507());
            _QandAstrategies.Add(ConstIntents.R507_Refrigerants_Move_Away_from_R404A_and_R507.ToString(), new R507_Refrigerants_Move_Away_from_R404A_and_R507());
            _QandAstrategies.Add(ConstIntents.R404A_R507_Refrigerants_Move_Away_from_R404A_and_R507.ToString(), new R404A_R507_Refrigerants_Move_Away_from_R404A_and_R507());
            _QandAstrategies.Add(ConstIntents.R507_R404A_Refrigerants_Move_Away_from_R404A_and_R507.ToString(), new R507_R404A_Refrigerants_Move_Away_from_R404A_and_R507());

            _QandAstrategies.Add(ConstIntents.R134A_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());
            _QandAstrategies.Add(ConstIntents.R22_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());
            _QandAstrategies.Add(ConstIntents.R404A_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());
            _QandAstrategies.Add(ConstIntents.R407C_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());
            _QandAstrategies.Add(ConstIntents.R417A_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());
            _QandAstrategies.Add(ConstIntents.R422D_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());
            _QandAstrategies.Add(ConstIntents.R427A_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());
            _QandAstrategies.Add(ConstIntents.R407F_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());
            _QandAstrategies.Add(ConstIntents.R410F_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());
            _QandAstrategies.Add(ConstIntents.R507_Refrigerant_GWP_and_Filling_Weight.ToString(), new Refrigerant_GWP_and_Filling_Weight());                      
            
            _QandAstrategies.Add(ConstIntents.R407F_GuideLines.ToString(), new R407F_GuideLines());
            _QandAstrategies.Add(ConstIntents.R407F_R404A_GuideLines.ToString(), new R407F_R404A_GuideLines());

            _QandAstrategies.Add(ConstIntents.R407F_R404A_Retrofit.ToString(), new R407F_R404A_Retrofit());
            _QandAstrategies.Add(ConstIntents.R404A_R407F_Retrofit.ToString(), new R404A_R407F_Retrofit());
            _QandAstrategies.Add(ConstIntents.R507_R407F_Retrofit.ToString(), new R507_R407F_Retrofit());
            _QandAstrategies.Add(ConstIntents.R407F_R507_Retrofit.ToString(), new R407F_R507_Retrofit());
            _QandAstrategies.Add(ConstIntents.R507A_R407F_Retrofit.ToString(), new R507A_R407F_Retrofit());
            _QandAstrategies.Add(ConstIntents.R407F_R507A_Retrofit.ToString(), new R407F_R507A_Retrofit());


            _QandAstrategies.Add(ConstIntents.R407F_R404A_Topup.ToString(), new R407F_R404A_Topup());
            _QandAstrategies.Add(ConstIntents.R404A_R407F_Topup.ToString(), new R404A_R407F_Topup());
            _QandAstrategies.Add(ConstIntents.R407F_R507_Topup.ToString(), new R407F_R507_Topup());
            _QandAstrategies.Add(ConstIntents.R507_R407F_Topup.ToString(), new R507_R407F_Topup());
            _QandAstrategies.Add(ConstIntents.R22_Topup.ToString(), new R22_Topup());
            _QandAstrategies.Add(ConstIntents.R22_R417A_Topup.ToString(), new R22_Topup());
            _QandAstrategies.Add(ConstIntents.R417A_R22_Topup.ToString(), new R22_Topup());

            _QandAstrategies.Add(ConstIntents.Cylinders_Refrigerant_Return_of_Full_Cylinder.ToString(), new Refrigerant_Return_of_Full_Cylinder());
            //_QandAstrategies.Add(ConstIntents.Cylinder_Refrigerant_Return_of_Full_Cylinder.ToString(), new Refrigerant_Return_of_Full_Cylinder());

            //NEW ROPE CASES
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410263.ToString(), new Ropes_Acera_22MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410267.ToString(), new Ropes_Acera_24MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410778.ToString(), new Ropes_Acera_26MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410271.ToString(), new Ropes_Acera_28MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410275.ToString(), new Ropes_Acera_30MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410283.ToString(), new Ropes_Acera_32MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410287.ToString(), new Ropes_Acera_34MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410291.ToString(), new Ropes_Acera_36MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410295.ToString(), new Ropes_Acera_38MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410299.ToString(), new Ropes_Acera_40MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410303.ToString(), new Ropes_Acera_42MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410307.ToString(), new Ropes_Acera_44MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410311.ToString(), new Ropes_Acera_48MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410419.ToString(), new Ropes_Acera_22MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410423.ToString(), new Ropes_Acera_24MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410427.ToString(), new Ropes_Acera_28MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410431.ToString(), new Ropes_Acera_30MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410435.ToString(), new Ropes_Acera_32MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410439.ToString(), new Ropes_Acera_36MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410443.ToString(), new Ropes_Acera_38MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410447.ToString(), new Ropes_Acera_40MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410451.ToString(), new Ropes_Acera_42MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410455.ToString(), new Ropes_Acera_46MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410790.ToString(), new Ropes_Acera_34MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410828.ToString(), new Ropes_Acera_26MM());


            _QandAstrategies.Add(ConstIntents.Ropes_Acera_22MM.ToString(), new Ropes_Acera_22MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_24MM.ToString(), new Ropes_Acera_24MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_26MM.ToString(), new Ropes_Acera_26MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_28MM.ToString(), new Ropes_Acera_28MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_30MM.ToString(), new Ropes_Acera_30MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_32MM.ToString(), new Ropes_Acera_32MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_34MM.ToString(), new Ropes_Acera_34MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_36MM.ToString(), new Ropes_Acera_36MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_38MM.ToString(), new Ropes_Acera_38MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_40MM.ToString(), new Ropes_Acera_40MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_42MM.ToString(), new Ropes_Acera_42MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_44MM.ToString(), new Ropes_Acera_44MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_46MM.ToString(), new Ropes_Acera_46MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_48MM.ToString(), new Ropes_Acera_48MM());
            //_QandAstrategies.Add(ConstIntents.Ropes_Acera_52MM.ToString(), new Ropes_Acera_52MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_400kn_SPLICED.ToString(), new Ropes_Acera_22MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_450kn_UNSPLICED.ToString(), new Ropes_Acera_22MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_470kn_SPLICED.ToString(), new Ropes_Acera_24MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_520kn_UNSPLICED.ToString(), new Ropes_Acera_24MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_540kn_SPLICED.ToString(), new Ropes_Acera_26MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_600kn_UNSPLICED.ToString(), new Ropes_Acera_26MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_610kn_SPLICED.ToString(), new Ropes_Acera_28MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_680kn_UNSPLICED.ToString(), new Ropes_Acera_28MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_690kn_SPLICED.ToString(), new Ropes_Acera_30MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_770kn_UNSPLICED.ToString(), new Ropes_Acera_30MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_780kn_SPLICED.ToString(), new Ropes_Acera_32MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_870kn_UNSPLICED.ToString(), new Ropes_Acera_32MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_860kn_SPLICED.ToString(), new Ropes_Acera_34MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_960kn_UNSPLICED.ToString(), new Ropes_Acera_34MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_940kn_SPLICED.ToString(), new Ropes_Acera_36MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1040kn_UNSPLICED.ToString(), new Ropes_Acera_36MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1040kn_SPLICED.ToString(), new Ropes_Acera_38MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1160kn_UNSPLICED.ToString(), new Ropes_Acera_38MM());
            // _QandAstrategies.Add(ConstIntents.Ropes_Acera_1160kn.ToString(), new Ropes_Acera_38MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1130kn_SPLICED.ToString(), new Ropes_Acera_40MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1260kn_UNSPLICED.ToString(), new Ropes_Acera_40MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1209kn_SPLICED.ToString(), new Ropes_Acera_42MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1350kn_UNSPLICED.ToString(), new Ropes_Acera_42MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1310kn_SPLICED.ToString(), new Ropes_Acera_44MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1460kn_UNSPLICED.ToString(), new Ropes_Acera_44MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1530kn_SPLICED.ToString(), new Ropes_Acera_48MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1700kn_UNSPLICED.ToString(), new Ropes_Acera_48MM());

            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1422kn_SPLICED.ToString(), new Ropes_Acera_46MM());
            _QandAstrategies.Add(ConstIntents.Ropes_Acera_1580kn_UNSPLICED.ToString(), new Ropes_Acera_46MM());

            //  _QandAstrategies.Add(ConstIntents.Ropes_Acera_Products_EDP_410778.ToString(), new Ropes_Amundsen_520KN());
            //

            _QandAstrategies.Add(ConstIntents.Refrigeration_UV_Tracer_Kit_220V_220V.ToString(), new Refrigeration_UV_Tracer_Kit_220V());
            _QandAstrategies.Add(ConstIntents.Refrigeration_UV_Tracer_Kit_220V_587170.ToString(), new Refrigeration_UV_Tracer_Kit_220V());
            _QandAstrategies.Add(ConstIntents.R407F_About.ToString(), new R407F_About());
        }

        public static void DoAlgorithm(LUIS luis, List<CreateDbData> listCreateDbData, IDialogContext context, IAwaitable<IMessageActivity> activity)
        {
            string intent = ConstIntents.Blank.ToString();          
            string luisIntent = luis.intents[0].intent;
            string refMessage = string.Empty;
            string speakMessage = "";

            IList<JSONUtils.Entity> lstEntities = luis.entities;
            try
            {
                // Creating the class name. 
                // If one entity fall then the class name will be "Entity_Intent"
                // If two entity fall then the class name will be "Entity_Entity_Intent"
                // more then 2, we are assuming its wrong case
                if (lstEntities != null && lstEntities.Count > 0)
                {
                    switch (lstEntities.Count)
                    {
                        case 1:
                            intent = lstEntities[0].entity.Replace() + "_" + luisIntent;
                            break;
                        case 2:
                            intent = lstEntities[0].entity.Replace() + "_" + lstEntities[1].entity.Replace() + "_" + luisIntent;
                            break;
                    }
                }

                //TODO: Speak Message

                // Exception list
                if (_exceptionList.Contains(intent))
                    _levelConversationStrategies[intent].DoPostData(listCreateDbData, context, activity, intent, refMessage, speakMessage);
                else
                {
                    refMessage = _QandAstrategies[intent].DoAlgorithm();
                    speakMessage = _QandAstrategies[intent].DoAlgorithmForSpeak();
                }


            }
            catch (Exception exp)
            {
                intent = ConstIntents.Blank.ToString();
                refMessage = _QandAstrategies[intent].DoAlgorithm();
            }


            if (!(_exceptionList.Contains(intent)))
            {
                _levelConversationStrategies[ConstIntents.PostData.ToString()].DoPostData(listCreateDbData, context, activity, intent, refMessage, speakMessage);
            }

            //if ((intent != eIntent.R449A_Availability.ToString()) && (intent != eIntent.R448A_Availability.ToString()))
            //    _postDataStrategies[eIntent.PostData.ToString()].DoPostData(listCreateDbData, context, activity, intent, refMessage);
        }
    }
}