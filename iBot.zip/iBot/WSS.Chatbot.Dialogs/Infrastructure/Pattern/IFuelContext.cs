﻿using System.Collections.Generic;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;

namespace WSS.ChatBot.Infrastructure
{
    public interface IFuelContext
    {
        List<CreateDbData> _listCreateDbData { get; set; }
        MailContent mailContent { get; set; }

        void DoAlgorithmForFuel(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result);
    }
}