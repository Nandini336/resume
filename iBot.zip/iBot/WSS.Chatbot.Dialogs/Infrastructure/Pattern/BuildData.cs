﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Linq;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Fuel_Infrastructure.Pattern
{
    class BuildData
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="activity"></param>
        /// <param name="message"></param>
        /// <param name="listCreateDbData"></param>
        /// <param name="levelConversationStrategies"></param>
        /// <param name="options"></param>
        /// <param name="mailContent"></param>
        public static void CallPostData(IDialogContext context, 
            IAwaitable<IMessageActivity> activity,
            Dictionary<int, string> lstMessages, 
            string message, List<CreateDbData> listCreateDbData, Dictionary<string, IPostDataForFuel> levelConversationStrategies, Dictionary<int, string> options, MailContent mailContent, string source)
        {
            var postData = new PostDataForFuel
            {
                Options = options,
                MessageActivity = activity,
                ListCreateDbData = listCreateDbData,
                Message = message,
                listPromptMessage = lstMessages,
                LevelConversationStrategies = levelConversationStrategies,
                mailContent = mailContent,
                Source = source
            };
            postData.Start(context, activity);
        }

        public static string GetIntentName(string luisIntent, string entity, int counter, Dictionary<int, string> _options)
        {
            var intent = string.Empty;
            switch (luisIntent)
            {
                case ConstIntents.Heavy:
                    switch (entity)
                    {
                        case ConstEntities.stability:
                        case ConstEntities.sediment:
                        case ConstEntities.sludge:
                            intent = ConstIntents.HeavySludge;
                            break;
                        case ConstEntities.soot:
                            intent = ConstIntents.HeavySoot;
                            break;
                        case ConstEntities.corrosion:
                        case ConstEntities.engineparts:
                            intent = ConstIntents.HeavyCorrosion;
                            break;
                        case ConstEntities.combustion:
                        case ConstEntities.wear:
                        case ConstEntities.deposit:
                            intent = ConstIntents.HeavyImproperCombustion;
                            break;
                        default:
                            break;
                    }

                    break;
                case ConstIntents.Diesel:
                    switch (entity)
                    {
                        case ConstEntities.deposit:
                        case ConstEntities.combustion:
                        case ConstEntities.color:
                        case ConstEntities.stability:
                        case ConstEntities.sediment:
                        case ConstEntities.sludge:
                        case ConstEntities.storage:
                            intent = ConstIntents.DieselDiscoloration;
                            break;
                        case ConstEntities.smell:
                        case ConstEntities.bacteria:
                        case ConstEntities.corrosion:
                            intent = ConstIntents.DieselBacteria;
                            break;
                        case ConstEntities.lubricity:
                        case ConstEntities.wear:
                        case ConstEntities.engineparts:
                            intent = ConstIntents.DieselLubricity;
                            break;
                        case ConstEntities.wax:
                            intent = ConstIntents.DieselWaxing;
                            break;
                        default:
                            break;
                    }
                    break;

                case ConstIntents.OilTest:
                    switch (entity)
                    {
                        case ConstEntities.corrosion:
                        case ConstEntities.wear:
                            intent = ConstIntents.OiltestFerrouswear;
                            break;
                        case ConstEntities.stability:
                            intent = ConstIntents.OiltestCompatability;
                            break;
                        case ConstEntities.combustion:
                            intent = ConstIntents.OiltestInsolubles;
                            break;
                        case ConstEntities.salt:
                            intent = ConstIntents.OiltestSaltwater;
                            break;
                        case ConstEntities.tbn:
                            intent = ConstIntents.OiltestTbn;
                            break;
                        case ConstEntities.viscosity:
                            intent = ConstIntents.OiltestViscosity;
                            break;
                        case ConstEntities.cabinet:
                            intent = ConstIntents.OiltestCabinet;
                            break;
                        case ConstEntities.lubricity:
                            intent = ConstIntents.OiltestLubricity;
                            break;
                    }
                    break;

                case ConstIntents.CandM1:
                    switch (entity)
                    {
                        case ConstEntities.engineparts:
                            intent = ConstIntents.C_M_ACC_Plus;
                            break;
                        case ConstEntities.alkaline:
                            intent = ConstIntents.C_M_AQUATUFF;
                            break;
                        case ConstEntities.separate:
                            intent = ConstIntents.C_M_BILGEWATER_FLOCCULANT;
                            break;
                        case ConstEntities.splitting:
                        case ConstEntities.solvent:
                            intent = ConstIntents.C_M_CLEANBREAK;
                            break;
                        case ConstEntities.soot:
                        case ConstEntities.corrosion:
                            intent = ConstIntents.C_M_COMMISSIONING_CLEANER;
                            break;
                    }
                    break;

                case ConstIntents.CandM2:
                    switch (entity)
                    {
                        case ConstEntities.nsf:
                        case ConstEntities.degreasingagent:
                        case ConstEntities.multipurpose:
                            intent = ConstIntents.C_M_AQUABREAK_PX;
                            break;
                        case ConstEntities.carbon:
                        case ConstEntities.soot:
                            intent = ConstIntents.C_M_CARBONCLEAN_LT;
                            break;
                        case ConstEntities.contamination:
                        case ConstEntities.solvent:
                            intent = ConstIntents.C_M_COLDWASH_HD;
                            break;
                    }
                    break;
                case ConstIntents.Welding_1:
                    switch (entity)
                    {
                        case ConstEntities.keys1:
                        case ConstEntities.steel:
                            intent = ConstIntents.Welding_Electrode_Competitor;
                            break;
                        case ConstEntities.keys2:
                            intent = ConstIntents.Welding_Electrode_Competitor_1;
                            break;
                        case ConstEntities.arrestor:
                            intent = ConstIntents.Welding_Flashback_Arrestor;
                            break;
                        case ConstEntities.weldingmachine:
                        case ConstEntities.stick:
                            intent = ConstIntents.Welding_Machine_1;
                            break;
                        case ConstEntities.cut:
                            intent = ConstIntents.Welding_Cutting_Torches;
                            break;
                        case ConstEntities.plasma:
                            intent = ConstIntents.Welding_Plasma_Machine;
                            break;
                        case ConstEntities.corrosion:
                        case ConstEntities.wear:
                            intent = ConstIntents.OiltestFerrouswear;
                            break;
                    }
                    break;
                case ConstIntents.Welding_2:
                    switch (entity)
                    {
                        case ConstEntities.voltage:
                        case ConstEntities.weldingmachine:
                            intent = ConstIntents.Welding_Open_Circuit_Voltage;
                            break;
                        case ConstEntities.regulator:
                            intent = ConstIntents.Welding_Regulator_Oxygen_Acetylene;
                            break;
                        case ConstEntities.stick:
                        case ConstEntities.steel:
                        case ConstEntities.weldingelectrode:
                        case ConstEntities.keys2:
                            intent = ConstIntents.Welding_Stick_Electrode;
                            break;
                    }
                    break;

                case ConstIntents.Ropes_Availability:
                    switch (entity)
                    {
                        case ConstEntities.atlas:
                            intent = ConstIntents.Ropes_Atlas;
                            break;
                        case ConstEntities.scott:
                            intent = ConstIntents.Ropes_AceraScott;
                            break;
                        case ConstEntities.mix:
                            intent = ConstIntents.Ropes_Conventional;
                            break;
                        case ConstEntities.nylon:                  
                            intent = ConstIntents.RopesConventionalNylon;
                            break;
                        case ConstEntities.pp:
                        case ConstEntities.cruise:                        
                            intent = ConstIntents.RopesConventionalPolyPropylene;
                            break;                        
                        case ConstEntities.cutter:
                            intent = ConstIntents.Ropes_Cutter;
                            break;
                        case ConstEntities.dbct:
                            intent = ConstIntents.Ropes_DalrympleBay;
                            break;
                        case ConstEntities.flagline:
                            intent = ConstIntents.Ropes_FlagLine;
                            break;
                        case ConstEntities.heave:
                            intent = ConstIntents.Ropes_HeavingLine;
                            break;
                        case ConstEntities.manila:
                            intent = ConstIntents.Ropes_ManilaRope;
                            break;
                        case ConstEntities.messenger:
                            intent = ConstIntents.Ropes_MessengerLine;
                            break;
                        case ConstEntities.ladder:
                            intent = ConstIntents.Ropes_PilotLadder;
                            break;
                        case ConstEntities.rat:
                            intent = ConstIntents.Ropes_RatGuard;
                            break;
                        case ConstEntities.snubber:
                            intent = ConstIntents.Ropes_RubberMooringSnubber;
                            break;
                        case ConstEntities.sba:
                        case ConstEntities.safe:
                            intent = ConstIntents.Ropes_SBA;
                            break;
                        case ConstEntities.sikka:
                            intent = ConstIntents.Ropes_Sikka;
                            break;
                        case ConstEntities.steel:
                            intent = ConstIntents.Ropes_SteelWire;
                            break;
                        case ConstEntities.tiger:
                            intent = ConstIntents.Ropes_TigerRope;
                            break;
                        case ConstEntities.timm8:
                            intent = ConstIntents.Ropes_TimmMaster8;
                            break;
                        case ConstEntities.winchline:
                            intent = ConstIntents.Ropes_TimmWinchline;
                            break;
                        case ConstEntities.sensor:
                            intent = ConstIntents.Ropes_SmartRope;
                            break;
                        case ConstEntities.strategy:
                            intent = ConstIntents.INT_RS_PSD;
                            break;
                        case ConstEntities.repairkit:
                        case ConstEntities.protection:
                        case ConstEntities.accessories:
                        case ConstEntities.timmchafeguard:
                        case ConstEntities.timmbosslink:
                        case ConstEntities.shackle:
                            intent = ConstIntents.RopeAccessories;
                            break;

                        //Rope_Queries intents switch cases to avoid conflict from LUIS
                        case ConstEntities.certificate:
                            intent = ConstIntents.RopesCertification;
                            break;
                        case ConstEntities.cowhitch:
                            intent = ConstIntents.Ropes_CowHitch;
                            break;
                        case ConstEntities.ropelines:
                            intent = ConstIntents.Ropes_Lines;
                            break;
                        case ConstEntities.MinaAlAhmadi:
                            intent = ConstIntents.Ropes_MinaAlAhmadi;
                            break;
                        case ConstEntities.ocimf:
                            intent = ConstIntents.Ropes_OCIMF4;
                            break;                       
                        case ConstEntities.splice:
                            intent = ConstIntents.Ropes_Spliced;
                            break;
                        case ConstEntities.stockpoint:
                            intent = ConstIntents.Ropes_StockPoints;
                            break;                                           
                        case ConstEntities.panama:
                            intent = ConstIntents.Ropes_PanamaCanal;
                            break;
                        case ConstEntities.tcll:
                            intent = ConstIntents.Ropes_TCLL;
                            break;                       

                    }
                    break;
                
                case ConstIntents.Ropes_Queries:
                    switch (entity)
                    {
                        case ConstEntities.certificate:
                            intent = ConstIntents.RopesCertification;
                            break;
                        case ConstEntities.cowhitch:
                            intent = ConstIntents.Ropes_CowHitch;
                            break;
                        case ConstEntities.ropelines:
                            intent = ConstIntents.Ropes_Lines;
                            break;
                        case ConstEntities.MinaAlAhmadi:
                            intent = ConstIntents.Ropes_MinaAlAhmadi;
                            break;
                        case ConstEntities.ocimf:
                            intent = ConstIntents.Ropes_OCIMF4;
                            break;
                        case ConstEntities.sensor:
                            intent = ConstIntents.Ropes_SmartRope;
                            break;
                        case ConstEntities.splice:
                            intent = ConstIntents.Ropes_Spliced;
                            break;
                        case ConstEntities.stockpoint:
                            intent = ConstIntents.Ropes_StockPoints;
                            break;
                        case ConstEntities.winchline:                        
                            intent = ConstIntents.Ropes_TimmWinchline;
                            break;
                        case ConstEntities.scott:
                            intent = ConstIntents.Ropes_AceraScott;
                            break;
                        case ConstEntities.panama:
                            intent = ConstIntents.Ropes_PanamaCanal;
                            break;
                        case ConstEntities.tcll:
                            intent = ConstIntents.Ropes_TCLL;
                            break;
                        case ConstEntities.strategy:
                            intent = ConstIntents.INT_RS_PSD;
                            break;

                        //Rope_Availability intents switch cases to avoid conflict from LUIS
                        case ConstEntities.atlas:
                            intent = ConstIntents.Ropes_Atlas;
                            break;                       
                        case ConstEntities.mix:
                            intent = ConstIntents.Ropes_Conventional;
                            break;
                        case ConstEntities.nylon:
                            intent = ConstIntents.RopesConventionalNylon;
                            break;
                        case ConstEntities.pp:
                        case ConstEntities.cruise:
                            intent = ConstIntents.RopesConventionalPolyPropylene;
                            break;
                        case ConstEntities.cutter:
                            intent = ConstIntents.Ropes_Cutter;
                            break;
                        case ConstEntities.dbct:
                            intent = ConstIntents.Ropes_DalrympleBay;
                            break;
                        case ConstEntities.flagline:
                            intent = ConstIntents.Ropes_FlagLine;
                            break;
                        case ConstEntities.heave:
                            intent = ConstIntents.Ropes_HeavingLine;
                            break;
                        case ConstEntities.manila:
                            intent = ConstIntents.Ropes_ManilaRope;
                            break;
                        case ConstEntities.messenger:
                            intent = ConstIntents.Ropes_MessengerLine;
                            break;
                        case ConstEntities.ladder:
                            intent = ConstIntents.Ropes_PilotLadder;
                            break;
                        case ConstEntities.rat:
                            intent = ConstIntents.Ropes_RatGuard;
                            break;
                        case ConstEntities.snubber:
                            intent = ConstIntents.Ropes_RubberMooringSnubber;
                            break;
                        case ConstEntities.sba:
                        case ConstEntities.safe:
                            intent = ConstIntents.Ropes_SBA;
                            break;
                        case ConstEntities.sikka:
                            intent = ConstIntents.Ropes_Sikka;
                            break;
                        case ConstEntities.steel:
                            intent = ConstIntents.Ropes_SteelWire;
                            break;
                        case ConstEntities.tiger:
                            intent = ConstIntents.Ropes_TigerRope;
                            break;
                        case ConstEntities.timm8:
                            intent = ConstIntents.Ropes_TimmMaster8;
                            break;                       
                           
                        case ConstEntities.repairkit:
                        case ConstEntities.protection:
                        case ConstEntities.accessories:
                        case ConstEntities.timmchafeguard:
                        case ConstEntities.timmbosslink:
                        case ConstEntities.shackle:
                            intent = ConstIntents.RopeAccessories;
                            break;
                    }
                            break;


            }
            if (!string.IsNullOrEmpty(intent))
                _options.Add(counter, intent);

            return intent;
        }

        public static string GetGenericIntentNameFromEntity(string luisIntent, string entity, int counter, Dictionary<int, string> _options)
        {
            var intent = string.Empty;
            switch (entity)
            {
                //case ConstEntities.stability:
                //case ConstEntities.sediment:
                //case ConstEntities.sludge:
                  //  intent = ConstIntents.HeavySludge;
                    //break;
                //case ConstEntities.soot:
                  //  intent = ConstIntents.HeavySoot;
                    //break;
                //case ConstEntities.corrosion:
                //case ConstEntities.engineparts:
                    //intent = ConstIntents.HeavyCorrosion;
                    //break;
                //case ConstEntities.combustion:
                //case ConstEntities.wear:
                //case ConstEntities.deposit:
                  // intent = ConstIntents.HeavyImproperCombustion;
                   // break;
                case ConstEntities.deposit:
                //case ConstEntities.combustion:
                case ConstEntities.color:
                //case ConstEntities.stability:
                case ConstEntities.sediment:
                case ConstEntities.sludge:
                case ConstEntities.storage:
                    intent = ConstIntents.DieselDiscoloration;
                    break;
                case ConstEntities.smell:
                case ConstEntities.bacteria:
                //case ConstEntities.corrosion:
                    intent = ConstIntents.DieselBacteria;
                    break;
                //case ConstEntities.lubricity:
                //case ConstEntities.wear:
                //case ConstEntities.engineparts:
                  //  intent = ConstIntents.DieselLubricity;
                   // break;
                case ConstEntities.wax:
                    intent = ConstIntents.DieselWaxing;
                    break;
                //case ConstEntities.corrosion:
                //case ConstEntities.wear:
                  //  intent = ConstIntents.OiltestFerrouswear;
                    //break;
                case ConstEntities.stability:
                    intent = ConstIntents.OiltestCompatability;
                    break;
                case ConstEntities.combustion:
                    intent = ConstIntents.OiltestInsolubles;
                    break;
                case ConstEntities.salt:
                    intent = ConstIntents.OiltestSaltwater;
                    break;
                case ConstEntities.tbn:
                    intent = ConstIntents.OiltestTbn;
                    break;
                case ConstEntities.viscosity:
                    intent = ConstIntents.OiltestViscosity;
                    break;
                case ConstEntities.cabinet:
                    intent = ConstIntents.OiltestCabinet;
                    break;
                case ConstEntities.lubricity:
                    intent = ConstIntents.OiltestLubricity;
                    break;
                case ConstEntities.engineparts:
                    intent = ConstIntents.C_M_ACC_Plus;
                    break;
                case ConstEntities.alkaline:
                    intent = ConstIntents.C_M_AQUATUFF;
                    break;
                case ConstEntities.separate:
                    intent = ConstIntents.C_M_BILGEWATER_FLOCCULANT;
                    break;
                case ConstEntities.splitting:
                //case ConstEntities.solvent:
                    intent = ConstIntents.C_M_CLEANBREAK;
                    break;
                case ConstEntities.soot:
                //case ConstEntities.corrosion:
                    intent = ConstIntents.C_M_COMMISSIONING_CLEANER;
                    break;
                case ConstEntities.nsf:
                case ConstEntities.degreasingagent:
                case ConstEntities.multipurpose:
                    intent = ConstIntents.C_M_AQUABREAK_PX;
                    break;
                case ConstEntities.carbon:
                    intent = ConstIntents.C_M_CARBONCLEAN_LT;
                    break;
                case ConstEntities.contamination:
                case ConstEntities.solvent:
                    intent = ConstIntents.C_M_COLDWASH_HD;
                    break;
                case ConstEntities.keys1:
                //case ConstEntities.steel:
                    intent = ConstIntents.Welding_Electrode_Competitor;
                    break;
                //case ConstEntities.keys2:
                  //  intent = ConstIntents.Welding_Electrode_Competitor_1;
                    //break;
                case ConstEntities.arrestor:
                    intent = ConstIntents.Welding_Flashback_Arrestor;
                    break;
                //case ConstEntities.weldingmachine:
                //case ConstEntities.stick:
                  //  intent = ConstIntents.Welding_Machine_1;
                    //break;
                case ConstEntities.cut:
                    intent = ConstIntents.Welding_Cutting_Torches;
                    break;
                case ConstEntities.plasma:
                    intent = ConstIntents.Welding_Plasma_Machine;
                    break;
                case ConstEntities.corrosion:
                case ConstEntities.wear:
                    intent = ConstIntents.OiltestFerrouswear;
                    break;
                case ConstEntities.voltage:
                case ConstEntities.weldingmachine:
                    intent = ConstIntents.Welding_Open_Circuit_Voltage;
                    break;
                case ConstEntities.regulator:
                    intent = ConstIntents.Welding_Regulator_Oxygen_Acetylene;
                    break;
                case ConstEntities.stick:
                case ConstEntities.steel:
                case ConstEntities.weldingelectrode:
                case ConstEntities.keys2:
                    intent = ConstIntents.Welding_Stick_Electrode;
                    break;

            }
            if (!string.IsNullOrEmpty(intent))
                _options.Add(counter, intent);

            return intent;
        }


        public static string GetMessage(string message, string intentName, int counter)
        {
            switch (intentName)
            {
                //Heavy
                case ConstIntents.HeavySludge:
                    message = message + "Sludge in heavy Oil. \n\n\n\n";
                    break;
                case ConstIntents.HeavySoot:
                    message = message + "Soot in boiler. \n\n\n\n";
                    break;
                case ConstIntents.HeavyImproperCombustion:
                    message = message + "Improper Combustion in Fuel. \n\n\n\n";
                    break;
                case ConstIntents.HeavyCorrosion:
                    message = message + "Heavy Corrosion. \n\n\n\n";
                    break;

                    //Diesel
                case ConstIntents.DieselBacteria:
                    message = message + "Bacteria in Diesel. \n\n\n\n";
                    break;
                case ConstIntents.DieselDiscoloration:
                    message = message + "Diesel Discoloration. \n\n\n\n";
                    break;
                case ConstIntents.DieselLubricity:
                    message = message + "Lubricity in Diesel. \n\n\n\n";
                    break;
                case ConstIntents.DieselWaxing:
                    message = message + "Diesel Waxing. \n\n\n\n";
                    break;

                    //C&M
                case ConstIntents.C_M_ACC_Plus:
                    message = message + "Acc Plus. \n\n\n\n";
                    break;
                case ConstIntents.C_M_AQUABREAK_PX:
                    message = message + "Aqua Break. \n\n\n\n";
                    break;
                case ConstIntents.C_M_AQUATUFF:
                    message = message + "Aqua Tuff. \n\n\n\n";
                    break;
                case ConstIntents.C_M_BILGEWATER_FLOCCULANT:
                    message = message + "Bilge Water. \n\n\n\n";
                    break;
                case ConstIntents.C_M_CARBONCLEAN_LT:
                    message = message + "Carbon Clean. \n\n\n\n";
                    break;
                case ConstIntents.C_M_CLEANBREAK:
                    message = message + "Clean Break. \n\n\n\n";
                    break;
                case ConstIntents.C_M_COLDWASH_HD:
                    message = message + "Cold Wash. \n\n\n\n";
                    break;
                case ConstIntents.C_M_COMMISSIONING_CLEANER:
                    message = message + "Commissioning Cleaner. \n\n\n\n";
                    break;

                    //Oiltest
                case ConstIntents.OiltestFerrouswear:
                    message = message + "Oiltest ferrouswear. \n\n\n\n";
                    break;
                case ConstIntents.OiltestInsolubles:
                    message = message + "Oiltest insolubles. \n\n\n\n";
                    break;
                case ConstIntents.OiltestSaltwater:
                    message = message + "Oiltest salt water contamination. \n\n\n\n";
                    break;
                case ConstIntents.OiltestTbn:
                    message = message + "Oiltest tbn information. \n\n\n\n";
                    break;
                case ConstIntents.OiltestViscosity:
                    message = message + "Oiltest viscosity. \n\n\n\n";
                    break;
                case ConstIntents.OiltestCabinet:
                    message = message + "Oiltest cabinet. \n\n\n\n";
                    break;
                case ConstIntents.OiltestLubricity:
                    message = message + "Oiltest lubricity. \n\n\n\n";
                    break;

                    //Welding
                case ConstIntents.Welding_Electrode_Competitor:
                    message = message + "Welding Electrode_Competitor. \n\n\n\n";
                    break;
                case ConstIntents.Welding_Electrode_Competitor_1:
                    message = message + "Welding Electrode_Competitor1. \n\n\n\n";
                    break;
                case ConstIntents.Welding_Flashback_Arrestor:
                    message = message + "Welding Flashback Arrestor. \n\n\n\n";
                    break;
                case ConstIntents.Welding_Machine_1:
                    message = message + "Welding Machine. \n\n\n\n";
                    break;
                case ConstIntents.Welding_Open_Circuit_Voltage:
                    message = message + "Welding Open Circuit Voltage. \n\n\n\n";
                    break;
                case ConstIntents.Welding_Regulator_Oxygen_Acetylene:
                    message = message + "Welding Regulator Oxygen Acetylene. \n\n\n\n";
                    break;
                case ConstIntents.Welding_Stick_Electrode:
                    message = message + "Welding Stick Electrode. \n\n\n\n";
                    break;
                case ConstIntents.Welding_Plasma_Machine:
                    message = message + "Welding Plasma Machine. \n\n\n\n";
                    break;
                case ConstIntents.Welding_Cutting_Torches:
                    message = message + "Welding Cutting Torches. \n\n\n\n";
                    break;

                //Old Ropes
                case ConstIntents.RopeAccessories:
                    message = message + "Rope accessories. \n\n";
                        break;
                case ConstIntents.Ropes_Atlas:
                    message = message + "Atlas ropes. \n\n";
                    break;
                case ConstIntents.RopesCertification:
                    message = message + "Rope certification. \n\n";
                    break;
                case ConstIntents.RopesConventional:
                    message = message + "Mixed conventional ropes. \n\n";
                    break;
                case ConstIntents.RopesConventionalNylon:
                    message = message + "Conventional nylon ropes. \n\n";
                    break;
                case ConstIntents.RopesConventionalPolyPropylene:
                    message = message + "Conventional polypropylene ropes. \n\n";
                    break;
                case ConstIntents.Ropes_CowHitch:
                    message = message + "Rope connections. \n\n";
                    break;
                case ConstIntents.Ropes_Cutter:
                    message = message + "Ropes cutter. \n\n";
                    break;
                case ConstIntents.Ropes_DalrympleBay:
                    message = message + "Ropes for dalrymple bay. \n\n";
                    break;
                case ConstIntents.Ropes_FlagLine:
                    message = message + "Ropes for flagline. \n\n";
                    break;
                case ConstIntents.Ropes_HeavingLine:
                    message = message + "Heaving line. \n\n";
                    break;
                case ConstIntents.Ropes_Lines:
                    message = message + "Rope lines. \n\n";
                    break;
                case ConstIntents.Ropes_Main:
                    message = message + "Different types of ropes. \n\n";
                    break;
                case ConstIntents.Ropes_ManilaRope:
                    message = message + "Manila ropes. \n\n";
                    break;
                case ConstIntents.Ropes_MessengerLine:
                    message = message + "Messenger lines. \n\n";
                    break;
                case ConstIntents.Ropes_MinaAlAhmadi:
                    message = message + "Ropes for port of Mina Al Ahmadi. \n\n";
                    break;
                case ConstIntents.Ropes_MixType:
                    message = message + "Mixed ropes. \n\n";
                    break;
                case ConstIntents.Ropes_OCIMF4:
                    message = message + "New OCIMF mooring guidelines. \n\n";
                    break;
                case ConstIntents.Ropes_PilotLadder:
                    message = message + "Pilot ladder ropes. \n\n";
                    break;
                case ConstIntents.Ropes_RatGuard:
                    message = message + "Rat guards. \n\n";
                    break;
                case ConstIntents.Ropes_RubberMooringSnubber:
                    message = message + "Rubber mooring snnubber. \n\n";
                    break;
                case ConstIntents.Ropes_SBA:
                    message = message + "Snap back arrestor. \n\n";
                    break;
                case ConstIntents.Ropes_Sikka:
                    message = message + "Ropes going to Sikka port. \n\n";
                    break;
                case ConstIntents.Ropes_SmartRope:
                    message = message + "Rope sensors / Smart ropes. \n\n";
                    break;
                case ConstIntents.Ropes_Spliced:
                    message = message + "Spliced and unspliced ropes. \n\n";
                    break;
                case ConstIntents.Ropes_SteelWire:
                    message = message + "Steel wire ropes. \n\n";
                    break;
                case ConstIntents.Ropes_StockPoints:
                    message = message + "Ropes stock points. \n\n";
                    break;
                case ConstIntents.Ropes_Stretcher:
                    message = message + "Stretcher ropes. \n\n";
                    break;
                case ConstIntents.Ropes_StretcherRecommendation:
                    message = message + "MBL spliced and unspliced recommended for stretchers. \n\n";
                    break;
                case ConstIntents.Ropes_StretcherRingtailSingleTail:
                    message = message + "Difference between singletail and ringtail. \n\n";
                    break;
                case ConstIntents.Ropes_TigerRope:
                    message = message + "Tiger ropes. \n\n";
                    break;
                case ConstIntents.Ropes_TimmMaster8:
                    message = message + "Timm master 8 ropes. \n\n";
                    break;
                case ConstIntents.Ropes_TimmWinchline:
                    message = message + "Timm Winchline ropes. \n\n";
                    break;
                case ConstIntents.INT_RS_PSD:
                    message = message + "Non-standard or different lengths of ropes. \n\n";
                    break;
                case ConstIntents.Ropes_AceraScott:
                    message = message + "Acera Scott ropes. \n\n";
                    break;
                case ConstIntents.Ropes_MeasuringDiameter:
                    message = message + "Diameter or size of the ropes. \n\n";
                    break;
                case ConstIntents.Ropes_PanamaCanal:
                    message = message + "Ropes for Panama Canal. \n\n";
                    break;
                case ConstIntents.Ropes_TCLL:
                    message = message + "TCLL testing. \n\n";
                    break;
                case ConstIntents.Ropes_TypeApproval:
                    message = message + "Rope type approval. \n\n";
                    break;


                default:
                    message = message + " No entity found.";
                    break;
            }

            return message;
        }

        // public static List<string> LstIntents { get; } = new List<string>();

        //public static List<string> listPromptMessage = new List<string>();

        public static Dictionary<int, string>  conversationlMessages= new Dictionary<int , string>();

        public static Dictionary<int, string> GetFileIntent(List<string> entities, string luisIntent, bool isSingleEntity, Dictionary<int, string> options)
        {
            string message = "";
            int iCount = 1;
            foreach (var entity in entities)
            {
                var intentName = GetIntentName(luisIntent, entity.ToLower(), iCount, options);
                // LstIntents.Add(intentName);

                if ((!string.IsNullOrEmpty(intentName)))
                {
                    if (isSingleEntity)
                    {
                        if (entities.Count == iCount)
                        {
                            //return intentName;
                          //  listPromptMessage.Add(intentName);
                            conversationlMessages.Add(iCount, intentName);
                            return conversationlMessages;
                        }
                        else
                        {
                            message = intentName;
                        }
                    }
                    else if (!isSingleEntity)
                    {
                        message = GetMessage("",intentName, 0);
                    }
                   // listPromptMessage.Add(message);
                    conversationlMessages.Add(iCount, message);
                    iCount = iCount + 1;
                }

            

             
            }
            return conversationlMessages;
        }

        public static List<string> GetDistinctEntities(LuisResult result)
        {
            var entities = result.Entities;
            var entityRecommendations = entities.Select(entity => entity.Resolution).ToList();

            var normalizedValues = new List<string>();
            var keyValuePair = new List<KeyValuePair<string, object>>();

            foreach (var item in entityRecommendations)
            {
                if (item != null)
                    keyValuePair.AddRange(item);
            }
            foreach (var item in keyValuePair)
            {
                var values = ((List<object>)item.Value);
                foreach (var value in values)
                {
                    normalizedValues.Add(value.ToString());
                }
            }
            var distinctEntities = normalizedValues.Distinct().ToList();
            return distinctEntities;
        }

    }
}
