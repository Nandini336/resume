﻿using ChatBot.Common;
using ChatBot.Dialogs.Fuel;
using ChatBot.Dialogs.Ropes;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using WSS.Chatbot.Dialogs.Dialogs.Fuel;
using WSS.Chatbot.Dialogs.Dialogs.Fuel.CandM;
using WSS.Chatbot.Dialogs.Dialogs.Fuel.Welding;
using WSS.Chatbot.Dialogs.Dialogs.OilTest;
using WSS.Chatbot.Dialogs.Dialogs.Ropes;
using WSS.Chatbot.Dialogs.Dialogs.Ropes.Level_Conversations;
using WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A;
using WSS.Chatbot.Dialogs.Fuel_Infrastructure.Pattern;
using WSS.ChatBot.Common;

namespace WSS.ChatBot.Infrastructure
{
    [Serializable]
    public class FuelContext 
    {
        //This is for Level conversation Class Name. Need to add the class name for levels
        private static List<string> _exceptionList = new List<string>();

        public  Dictionary<int, string> _options = new Dictionary<int, string>();

        //This is for Level conversation Strategies. We will put all the scenerios where we dont have direct Q&A.
        public static Dictionary<string, IPostDataForFuel> _levelConversationStrategies = new Dictionary<string, IPostDataForFuel>();

        public static Dictionary<string, IWrongIntentStrategy> _wrongConversationStrategies = new Dictionary<string, IWrongIntentStrategy>();

        public List<CreateDbData> _listCreateDbData { get; set; }
        public MailContent mailContent { get; set; }
        public static string Intent { get; set; }
        public static string refMessage { get; set; }
        /// <summary>
        /// Instantiate the Entity Class
        /// </summary>
        /// <param name="context"></param>
        /// <param name="activity"></param>
        /// <param name="result"></param>
        //public static void DoAlgorithmForFuel(result luis, List<CreateDbData> listCreateDbData, IDialogContext context, IAwaitable<IMessageActivity> activity)
        public void DoCallClass(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            try
            {
                if (_levelConversationStrategies.Count == 0)
                {
                    //Heavy Fuel
                    _levelConversationStrategies.Add(ConstIntents.HeavySludge.ToString(),
                        new HeavySludge(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.HeavySoot.ToString(),
                        new HeavySoot(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.HeavyImproperCombustion.ToString(),
                        new Heavy_ImproperCombustion(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.HeavyCorrosion.ToString(),
                        new Heavy_Corrosion(_listCreateDbData));

                    //Diesel Oil
                    _levelConversationStrategies.Add(ConstIntents.DieselBacteria.ToString(),
                        new Diesel_Bacteria(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.DieselDiscoloration.ToString(),
                        new Diesel_Discoloration(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.DieselLubricity.ToString(),
                        new Diesel_Lubricity(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.DieselWaxing, new Diesel_Waxing(_listCreateDbData));

                    //Oil Test
                    _levelConversationStrategies.Add(ConstIntents.OiltestFerrouswear, new Oiltest_Ferrouswear(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.OiltestInsolubles, new Oiltest_Insolubles(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.OiltestSaltwater, new Oiltest_Saltwater(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.OiltestTbn, new Oiltest_TBN(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.OiltestCabinet, new Oiltest_cabinet(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.OiltestCompatability, new Oiltest_compatability(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.OiltestLubricity, new Oiltest_lubricity(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.OiltestViscosity, new Oiltest_Viscosity(_listCreateDbData));

                   
                    //CandM1
                    _levelConversationStrategies.Add(ConstIntents.C_M_ACC_Plus, new C_M_ACC_Plus(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.C_M_AQUATUFF, new C_M_AQUATUFF(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.C_M_BILGEWATER_FLOCCULANT, new C_M_BILGEWATER_FLOCCULANT(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.C_M_CLEANBREAK, new C_M_CLEANBREAK(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.C_M_COMMISSIONING_CLEANER, new C_M_COMMISSIONING_CLEANER(_listCreateDbData));

                    //CandM2
                    _levelConversationStrategies.Add(ConstIntents.C_M_AQUABREAK_PX, new C_M_AQUABREAK_PX(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.C_M_CARBONCLEAN_LT, new C_M_CARBONCLEAN_LT(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.C_M_COLDWASH_HD, new C_M_COLDWASH_HD(_listCreateDbData));

                    //Welding1
                    _levelConversationStrategies.Add(ConstIntents.Welding_Electrode_Competitor, new Welding_Electrode_Competitor(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Welding_Electrode_Competitor_1, new Welding_Electrode_Competitor_1(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Welding_Flashback_Arrestor, new Welding_Flashback_Arrestor(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Welding_Machine_1, new Welding_Machine_1(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Welding_Cutting_Torches, new Welding_Cutting_Torches(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Welding_Plasma_Machine, new Welding_Plasma_Machine(_listCreateDbData));
                   
                    //Welding2
                    _levelConversationStrategies.Add(ConstIntents.Welding_Open_Circuit_Voltage, new Welding_Open_Circuit_Voltage(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Welding_Regulator_Oxygen_Acetylene, new Welding_Regulator_Oxygen_Acetylene(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Welding_Stick_Electrode, new Welding_Stick_Electrode(_listCreateDbData));

                    _levelConversationStrategies.Add(ConstIntents.Blank, new BlankPage(_listCreateDbData));

                    //Old Rope cases
                    //_levelConversationStrategies.Add(ConstIntents.RopesConventionalNylon, new Ropes_Conventional_Nylon(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_Atlas, new Ropes_Atlas(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.RopesCertification, new Ropes_Certification(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_Conventional, new Ropes_Conventional(_listCreateDbData));
                   _levelConversationStrategies.Add(ConstIntents.RopesConventionalPolyPropylene, new RopesConventionalPolyPropylene(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_CowHitch, new Ropes_CowHitch(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_Cutter, new Ropes_Cutter(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_DalrympleBay, new Ropes_DalrympleBay(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_FlagLine, new Ropes_FlagLine(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_HeavingLine, new Ropes_HeavingLine(_listCreateDbData));
                   // _levelConversationStrategies.Add(ConstIntents.Ropes_Lines, new Ropes_Lines(_listCreateDbData));
                   // _levelConversationStrategies.Add(ConstIntents.Ropes_Main, new Ropes_Main(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_ManilaRope, new Ropes_ManilaRope(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_MessengerLine, new Ropes_MessengerLine(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_MinaAlAhmadi, new Ropes_MinaAlAhmadi(_listCreateDbData));
                   // _levelConversationStrategies.Add(ConstIntents.Ropes_MixType, new Ropes_MixType(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_OCIMF4, new Ropes_OCIMF4(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_PilotLadder, new Ropes_PilotLadder(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_RatGuard, new Ropes_RatGuard(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_RubberMooringSnubber, new Ropes_RubberMooringSnubber(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_SBA, new Ropes_SBA(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_Sikka, new Ropes_Sikka(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_SmartRope, new Ropes_SmartRope(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_Spliced, new Ropes_Spliced(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_SteelWire, new Ropes_SteelWire(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_StockPoints, new Ropes_StockPoints(_listCreateDbData));
                   // _levelConversationStrategies.Add(ConstIntents.Ropes_Stretcher, new Ropes_Stretcher(_listCreateDbData));
                    //_levelConversationStrategies.Add(ConstIntents.Ropes_StretcherRecommendation, new Ropes_StretcherRecommendation(_listCreateDbData));
                    //_levelConversationStrategies.Add(ConstIntents.Ropes_StretcherRingtailSingleTail, new Ropes_StretcherRingtailSingleTail(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_TigerRope, new Ropes_TigerRope(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_TimmMaster8, new Ropes_TimmMaster8(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_TimmWinchline, new Ropes_TimmWinchline(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.INT_RS_PSD, new INT_RS_PSD(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.RopeAccessories, new Rope_Accessories(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_AceraScott, new Ropes_AceraScott(_listCreateDbData));
                   // _levelConversationStrategies.Add(ConstIntents.Ropes_MeasuringDiameter, new Ropes_MeasuringDiameter(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_PanamaCanal, new Ropes_PanamaCanal(_listCreateDbData));
                    _levelConversationStrategies.Add(ConstIntents.Ropes_TCLL, new Ropes_TCLL(_listCreateDbData));
                  // _levelConversationStrategies.Add(ConstIntents.Ropes_TypeApproval, new Ropes_TypeApproval(_listCreateDbData));
                    

                }


                _levelConversationStrategies[Intent].MainAsync(context, activity, _listCreateDbData);

            }
            catch (Exception exp)
            {
                _levelConversationStrategies[ConstIntents.Blank].MainAsync(context, activity, _listCreateDbData);

                //context.PostAsync(exp.Message);
                //throw;
            }
        }


        public void DoAlgorithmForFuel(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)

        {
            var luisIntent = result.Intents[0].Intent;
            List<string> lstIntents = new List<string>();

            var distinctEntities = BuildData.GetDistinctEntities(result);
            int iCount = 1;
            foreach (var entity in distinctEntities)
            {
                var intentName = BuildData.GetIntentName(luisIntent, entity.ToLower(), iCount, _options);
                if ((!lstIntents.Contains(intentName)) && (!string.IsNullOrEmpty(intentName)))
                {
                    lstIntents.Add(intentName);

                    iCount = iCount + 1;
                }
            }

            _options.Clear();
            _levelConversationStrategies.Clear();
            _wrongConversationStrategies.Clear();
           // BuildData.listPromptMessage.Clear();
            BuildData.conversationlMessages.Clear();

            switch (lstIntents.Count)
            {
                case 0:
                    FuelContext.Intent = ConstIntents.Blank;
                    DoCallClass(context, activity, result);
                    break;
                case 1:
                   // BuildData.listPromptMessage.Clear();
                    var intent = BuildData.GetFileIntent(distinctEntities, luisIntent, true, _options);
                    FuelContext.Intent = intent[1].ToString();
                    DoCallClass(context, activity, result);
                    break;

                default:
                    {

                       // BuildData.listPromptMessage.Clear();

                        var messages = BuildData.GetFileIntent(distinctEntities, luisIntent, false, _options);

                        string logMessage = "Do you want to know about ?\n\n\n\n";

                        string message = "";
                        foreach (var item in messages)
                        {
                            message = message + item.Key + ") " +  item.Value;
                        }

                        logMessage = logMessage + message;

                        mailContent.ChatDataForUserandBot(context, logMessage);

                        CosmosDbData.BotResponse(logMessage, context, luisIntent, _listCreateDbData);

                        BuildData.CallPostData(context, activity, messages, logMessage, _listCreateDbData, _levelConversationStrategies, _options, mailContent, ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString());

                        break;
                    }
            }
        }


    }
}