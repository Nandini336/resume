﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChatBot.Common;
using WSS.ChatBot.Common;

namespace WSS.ChatBot.Infrastructure
{
    [Serializable]
    public class PostDataForFuel //: IDialog<IMessageActivity>
    { 

        public Dictionary<string, IPostDataForFuel> LevelConversationStrategies { get; set; }
        public Dictionary<int, string> Options { get; set; }
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent mailContent { get; set; }
        public IAwaitable<IMessageActivity> MessageActivity { get; set; }
        public string Message { get; set; }

        public string Source { get; set; }

        public Dictionary<int, string> listPromptMessage = new Dictionary<int, string>();

        public void CosmosData(IDialogContext context, string message, List<CreateDbData> _listCreateDbData)
        {
            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse = message;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = "";
            _listCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, _listCreateDbData);
        }
        /// <summary>
        /// 1.Gets the value from the user reply in the bot .
        /// 2.checks whether the user input is right or wrongOption.
        /// 3.If user enters "right-option" propmts the message.
        /// 4.if user enters "wrong-option" prompts error message.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="activity"></param>
        /// <returns></returns>
        public async Task AfterMenuSelection(IDialogContext context, IAwaitable<object> activity)

        {

            var fuelContext = new FuelContext
            {
                _listCreateDbData = ListCreateDbData,
                _options = Options
            };

            var message = await activity;

            string value = "";

            if (this.Source == Common.Common.QBot)
            {
                value = Options.FirstOrDefault(x => x.Key.ToString() == message.ToString()).Value ??
                            ConstIntents.WrongOption;
                
            }
            else
            {
                string getValuefromDict = listPromptMessage.FirstOrDefault(x => x.Value.ToString() == message.ToString()).Key.ToString() ??
                        ConstIntents.WrongOption;
                value = Options.FirstOrDefault(x => x.Key.ToString() == getValuefromDict.ToString()).Value ??
                           ConstIntents.WrongOption;
            }

            if (value == ConstIntents.WrongOption)
            {

                const string wrongOptionMessage = "You have selected an invalid option. Please select valid option.";

                mailContent.ChatDataForUserandBot(context, message.ToString());

                CosmosData(context, wrongOptionMessage, ListCreateDbData);

                PromptDialog.Text(
                    context: context,
                    resume: this.AfterMenuSelection,
                    prompt: wrongOptionMessage,
                    retry: "Sorry, I didn't understand that. Please try again."
                );
            }
            else
            {
                mailContent.ChatDataForUserandBot(context, "");

                CreateDbData.Instance.Bot = "";
                CreateDbData.Instance.BotResponse = "";
                CreateDbData.Instance.BotResponseDatetime = DateTime.Now;

                CosmosDbData.UserReplyWithoutIntent(context, message.ToString());
             
                FuelContext.Intent = value;
                FuelContext.refMessage = this.Message;
                FuelContext._levelConversationStrategies = LevelConversationStrategies;

                CreateDbData.Instance.UserReply = message.ToString();
               fuelContext.DoCallClass(context, MessageActivity, null);
            }
            
        }
        /// <summary>
        /// prompt the message and resume for AfterMenuSelection.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="activity"></param>
        public void Start(IDialogContext context, IAwaitable<IMessageActivity> activity)
        {
            // await this.AfterMenuSelection(context, activity);

            if (this.Source == Common.Common.QBot)
            {
                PromptDialog.Text(
                        context: context,
                        resume: this.AfterMenuSelection,
                        prompt: Message,
                        retry: "Sorry, I didn't understand that. Please try again."
                    );

            }
            else
            {
                string mainMessage = "Do you want to know about ?\n\n\n\n";

                List<string> options = new List<string>();
                foreach (var item in listPromptMessage)
                {
                    options.Add(item.Value);
                }

                PromptDialog.Choice(
                    context,
                    this.AfterMenuSelection,
                    options,
                    mainMessage,
                    "Please choose a valid option from below !!", 1);

            }
            MessageActivity = activity;
        }

        public async Task StartAsync(IDialogContext context)
        {
            await AfterMenuSelection(context, null);
        }
    }
}
