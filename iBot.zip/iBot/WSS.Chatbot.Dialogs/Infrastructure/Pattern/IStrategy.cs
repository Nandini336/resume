﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;

namespace WSS.ChatBot.Infrastructure
{
    public interface IFuelIntentStrategy
    {
        string DoAlgorithmForFuel(); 
    }

    public interface IWrongIntentStrategy
    {
        Task WrongIntent(IDialogContext context, IAwaitable<IMessageActivity> activity,
            List<CreateDbData> listCreateDbData, Dictionary<int, string> Options,
            Dictionary<string, IPostDataForFuel> LevelConversationStrategies);
    }

    public interface IPostDataForFuel
    {
        List<CreateDbData> ListCreateDbData { get; set; }
        MailContent MailContent { get; set; }
        Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData);
    }

}