﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace WSS.ChatBot.Common.Utils
{
    public class FinalQuery
    {
        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        public FinalQuery(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }
        public async Task LogForFinalQuery(IDialogContext context, IAwaitable<object> result, string Prompt, string mailMessage, string intent)
        {
           // context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            MailContent.ChatDataForBot(context, Prompt);
            string finalPrompt = $"Was I able to help resolve your query? \n\n Yes / No";
            await context.PostAsync(finalPrompt);
            MailContent.ChatDataForBot(context, finalPrompt);

            CosmosDbData.BotResponse2withBlankIntent(Prompt, finalPrompt, context, ListCreateDbData);

            var selection = new EndOfConversation();
            await selection.EndLevelConversation(context);
        }
    }
}
