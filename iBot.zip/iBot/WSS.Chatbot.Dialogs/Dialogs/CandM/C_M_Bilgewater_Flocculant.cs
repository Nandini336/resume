﻿using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.CandM
{
    public class C_M_BILGEWATER_FLOCCULANT : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public C_M_BILGEWATER_FLOCCULANT(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {

                message = $"1. WSS recommends Unitor™ Bilge Water Flocculant™, Product number: 690669. Unitor™ Bilge Water Flocculant™ is a very effective liquid treatment based on Poly Aluminium Chloride to separate oil residues from bilge water.\n\n" +
                             "2. For more product information, dosage rates and direction for use, please please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/cleaning-and-maintenance/bilge-water-flocculantx-25-l)";
            }
            else
            {
                message = "1. WSS recommends Unitor™ Bilge Water Flocculant™, Product number: 690669. Unitor™ Bilge Water Flocculant™ is a very effective liquid treatment based on Poly Aluminium Chloride to separate oil residues from bilge water.\n\n" +
                            "2. For more product information, dosage rates and direction for use, please please <a href='http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/cleaning-and-maintenance/bilge-water-flocculantx-25-l'>click here.</a>";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "WSS recommends Unitor™ Bilge Water Flocculant™, Product number: 690669. Unitor™ Bilge Water Flocculant™ is a very effective liquid treatment based on Poly Aluminium Chloride to separate oil residues from bilge water.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.C_M_BILGEWATER_FLOCCULANT);
        }
    }
}
