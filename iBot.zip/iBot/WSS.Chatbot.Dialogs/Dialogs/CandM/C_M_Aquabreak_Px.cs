﻿using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.CandM
{
    public class C_M_AQUABREAK_PX : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public C_M_AQUABREAK_PX(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = $"1. WSS recommends Unitor™ Aquabreak PX™, Product number: 575613. Unitor™ Aquabreak PX™ is a multipurpose cleaning and degreasing agent. Dirt and oily matters is effectively removed without the use of solvents and caustic based cleaners. It is low-toxic, non-caustic, free of hydrocarbon solvents and biodegradable.\n\n" +
                            "2. For more product information, dosage rates and direction for use, please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/cleaning-and-maintenance/aquabreak-pxx-25-l)";
            }
            else
            {
                message = "1. WSS recommends Unitor™ Aquabreak PX™, Product number: 575613. Unitor™ Aquabreak PX™ is a multipurpose cleaning and degreasing agent. Dirt and oily matters is effectively removed without the use of solvents and caustic based cleaners. It is low-toxic, non-caustic, free of hydrocarbon solvents and biodegradable.\n\n" +
                            "2. For more product information, dosage rates and direction for use, please <a href='http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/cleaning-and-maintenance/aquabreak-pxx-25-l'>click here.</a>";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "WSS recommends Unitor™ Aquabreak PX™, Product number: 575613. Unitor™ Aquabreak PX™ is a multipurpose cleaning and degreasing agent. Dirt and oily matters is effectively removed without the use of solvents and caustic based cleaners. It is low-toxic, non-caustic, free of hydrocarbon solvents and biodegradable.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.C_M_AQUABREAK_PX);
        }
    }
}
