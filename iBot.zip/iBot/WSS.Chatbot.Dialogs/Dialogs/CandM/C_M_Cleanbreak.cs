﻿using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.CandM
{
    public class C_M_CLEANBREAK : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public C_M_CLEANBREAK(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {

                 message = $"1. WSS recommends Unitor™ Cleanbreak™, Product number: 571497. Unitor™ Cleanbreak™ is a degreaser containing self-splitting emulsifiers. It allows the slop water to break into separate oil and water phases.\n\n" +
                               "2. For more product information, dosage rates and direction for use, please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/cleaning-and-maintenance/cleanbreakx-25-l)";
            }
            else
            {
                 message = "1. WSS recommends Unitor™ Cleanbreak™, Product number: 571497. Unitor™ Cleanbreak™ is a degreaser containing self-splitting emulsifiers. It allows the slop water to break into separate oil and water phases.\n\n" +
                             "2. For more product information, dosage rates and direction for use, please <a href='http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/cleaning-and-maintenance/cleanbreakx-25-l'>click here.</a>";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "WSS recommends ACC Plus™ 25 l, Product number: 698704. Unitor™ ACC Plus is a powerful cleaning agent for cleaning of diesel engine air coolers, scavenging air systems and the compressor side of turbochargers.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.C_M_CLEANBREAK);
        }
    }
}
