﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel
{
    public class Diesel_Waxing : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Diesel_Waxing(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;
            string replyMsg = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                replyMsg = $" 1. Cause: The paraffin’s are quite large molecules and have a tendency to come together and form larger structures as the temperature drops in the fuel. The paraffin’s can also be referred to as wax \n\n" +
                $" 2. Solution: Unitor™ DieselPower™ CFPP product nos: 778405 will help reduce the wax formation and also to reduce the risk of wax fallout and accumulation. Normal recommended dosage rate: 1Ltr:1ton of fuel. " +
                  $"    For more product info please [click here](http://wssproductss.wilhelmsen.com/marine-chemicals/chemicals/distillate-fuel-treatment/dieselpowerx-cfpp) \n\n" +
                $" 3. Benefits: DieselPower CFPP reduces the cold filter plug point by an avg of 10 Celsius thus preventing the risk of waxing in your diesel oil";
            }
            else
            {
                replyMsg = $" 1. Cause: The paraffin’s are quite large molecules and have a tendency to come together and form larger structures as the temperature drops in the fuel. The paraffin’s can also be referred to as wax \n\n\n\n" +
               $" 2. Solution: Unitor™ DieselPower™ CFPP product nos: 778405 will help reduce the wax formation and also to reduce the risk of wax fallout and accumulation. Normal recommended dosage rate: 1Ltr:1ton of fuel." +
               $"    For more product info please <a href = 'http://wssproductss.wilhelmsen.com/marine-chemicals/chemicals/distillate-fuel-treatment/dieselpowerx-cfpp'>click here</a>\n\n\n\n" +
               $" 3. Benefits: DieselPower CFPP reduces the cold filter plug point by an avg of 10 Celsius thus preventing the risk of waxing in your diesel oil";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Cause: The paraffin’s are quite large molecules and have a tendency to come together and form larger structures as the temperature drops in the fuel. The paraffin’s can also be referred to as wax .Solution: Unitor™ DieselPower™ CFPP product nos: 778405 will help reduce the wax formation and also to reduce the risk of wax fallout and accumulation. Normal recommended dosage rate: 1 litre:1 ton of fuel.Benefits: Diesel Power CFPP reduces the cold filter plug point by an avg of 10 Celsius thus preventing the risk of waxing in your diesel oil";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.DieselWaxing);
        }
    }
}
