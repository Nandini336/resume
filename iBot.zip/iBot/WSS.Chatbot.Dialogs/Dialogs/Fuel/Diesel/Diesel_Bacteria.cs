﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel
{
    public class Diesel_Bacteria : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Diesel_Bacteria(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = $" 1. Cause: microbial contamination exhibit a foul smell. Water is a precursor for microbial growth and as little as 0,0001% (100 ppm) of water is enough for microbes to grow. \n\n" +
                $" 2. Solution: DieselPower MAR 71 is used to prevent bacterial growth if water contamination is suspected. Normal dosage rate is: 0.2Ltr per ton of fuel for preventive measures." +
                 $"    For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/distillate-fuel-treatment/dieselpowerx-mar-71-25-ltr?tab=direction&all=1#direction-tab) \n\n" +
                $" 3. Benefits: DieselPower MAR71 is a biocide that prevents and removes microbial contamination from your fuel.";
            }
            else
            {
               message = $" 1. Cause: microbial contamination exhibit a foul smell. Water is a precursor for microbial growth and as little as 0,0001% (100 ppm) of water is enough for microbes to grow. \n\n\n\n" +
               $" 2. Solution: DieselPower MAR 71 is used to prevent bacterial growth if water contamination is suspected. Normal dosage rate is: 0.2Ltr per ton of fuel for preventive measures." +
               $"    For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/distillate-fuel-treatment/dieselpowerx-mar-71-25-ltr?tab=direction&all=1#direction-tab'>click here</a>\n\n" +
               $" 3. Benefits: DieselPower MAR71 is a biocide that prevents and removes microbial contamination from your fuel.";

            }

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Cause: microbial contamination exhibit a foul smell. Water is a precursor for microbial growth and as little as 0.0001% that is 100 ppm of water is enough for microbes to grow. Solution: DieselPower MAR 71 is used to prevent bacterial growth if water contamination is suspected. Normal dosage rate is: 0.2Ltr per ton of fuel for preventive measures.Benefits: DieselPower MAR71 is a biocide that prevents and removes microbial contamination from your fuel.";
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.DieselBacteria);
        }
    }
}
