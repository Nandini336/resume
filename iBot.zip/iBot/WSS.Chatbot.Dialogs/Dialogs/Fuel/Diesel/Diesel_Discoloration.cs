﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel
{
    public class Diesel_Discoloration : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Diesel_Discoloration(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;

            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                 message = $" 1. Cause: Diesel or distillate oils are by nature are degrading or oxidizing all the time as long as they are in contact with oxygen. \n\n" +
                 $" 2. Solution: DieselPower Enhancer will keep the sedimentation reactions under control ensuring no sediment is formed from fuel instability. Normal dosage rate is 0.6 ltr / ton of fuel." +
                  $"    For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/distillate-fuel-treatment/dieselpowerx-enhancer-25-ltr?tab=direction&all=1#direction-tab) \n\n" +
                 $" 3. Benefits: Unitor™ DieselPower™ Lubricity reduces the HFRR to close to 360 micron meter which is below the OEM recommendation of 460 micron meter.  ";
            }
            else
            {
                message = $" 1. Cause: Diesel or distillate oils are by nature are degrading or oxidizing all the time as long as they are in contact with oxygen. \n\n\n\n" +
                 $" 2. Solution: DieselPower Enhancer will keep the sedimentation reactions under control ensuring no sediment is formed from fuel instability. Normal dosage rate is 0.6 ltr / ton of fuel." +
                 $"    For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/distillate-fuel-treatment/dieselpowerx-enhancer-25-ltr?tab=direction&all=1#direction-tab'>click here</a> \n\n" +
                 $" 3. Benefits: Unitor™ DieselPower™ Lubricity reduces the HFRR to close to 360 micron meter which is below the OEM recommendation of 460 micron meter.  ";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Cause: Diesel or distillate oils are by nature are degrading or oxidizing all the time as long as they are in contact with oxygen. Solution: DieselPower Enhancer will keep the sedimentation reactions under control ensuring no sediment is formed from fuel instability. Normal dosage rate is 0.6 litre or ton of fuel.Benefits: Unitor™ DieselPower™ Lubricity reduces the HFRR to close to 360 micron meter which is below the OEM recommendation of 460 micron meter.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.DieselDiscoloration);
        }
    }
}
