﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel
{
    public class Diesel_Lubricity : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Diesel_Lubricity(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;
            string replyMsg = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                replyMsg = $"1. Cause: Refining process reduces the naturally occurring lubricants in diesel or distillate oils. Heavy / residual oils do not have lubricity issues . \n\n" +
                $"2. Solution: Unitor™ DieselPower™ Lubricity is formulated to enhance the lubricity of marine diesel / distillate / ULSFO fuels. Normal recommended dosage rate is: 100ml / 1 ton of fuel. " +
                $"   For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/distillate-fuel-treatment/dieselpowerx-lubricity?tab=direction&all=1#direction-tab) \n\n" +
                $"3. Benefits: Unitor™ DieselPower™ Lubricity reduces the HFRR to close to 360 micron meter which is below the OEM recommendation of 460 micron meter.  please ask your WSS representative for performance test reports.";
            }
            else
            {
               replyMsg = $"1. Cause: Refining process reduces the naturally occurring lubricants in diesel or distillate oils. Heavy / residual oils do not have lubricity issues . \n\n" +
               $"2. Solution: Unitor™ DieselPower™ Lubricity is formulated to enhance the lubricity of marine diesel / distillate / ULSFO fuels. Normal recommended dosage rate is: 100ml / 1 ton of fuel." +
               $"   For more product info please <a href = ' http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/distillate-fuel-treatment/dieselpowerx-lubricity?tab=direction&all=1#direction-tab'>click here</a> \n\n\n\n" +
               $"3. Benefits: Unitor™ DieselPower™ Lubricity reduces the HFRR to close to 360 micron meter which is below the OEM recommendation of 460 micron meter.  please ask your WSS representative for performance test reports.";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Cause: Refining process reduces the naturally occurring lubricants in diesel or distillate oils. Heavy / residual oils do not have lubricity issues.Solution: Unitor™ DieselPower™ Lubricity is formulated to enhance the lubricity of marine diesel or distillate or ULSFO fuels. Normal recommended dosage rate is: 100ml or 1 ton of fuel.Benefits: Unitor™ DieselPower™ Lubricity reduces the HFRR to close to 360 micron meter which is below the OEM recommendation of 460 micron meter.  please ask your WSS representative for performance test reports";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.DieselLubricity);

        }
    }
}
