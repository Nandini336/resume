﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;

/// <summary>
/// Class to implement level conversation for Heavy_Soot
/// </summary>

namespace ChatBot.Dialogs.Fuel
{

    [Serializable]
    public class BlankPage : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        public BlankPage(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;
            const string message = "Can you please check your query and try again !!";
            var QandA = new QandA(this.ListCreateDbData);
            await QandA.MainWithIntent(context, activity, message, ConstIntents.Blank);
        }
      
    }
}