﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel
{
    public class Heavy_Corrosion : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Heavy_Corrosion(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = $"1. Cause: Ash, vanadium and sodium components in the fuel are prone to build low melting point deposits.\n\n\n\n" +
                $" 2. Solution: FuelPower AshFree, product nos 778789 contains components that will reduce the deposit formation and increase the melting point of the deposit." +
                $" For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-ashfree-25-ltr?tab=direction&all=1#direction-tab)\n\n\n\n" +
                $" Normal recommended dosage rate is 3kg per day.  \n\n\n\n" +
                $" 3. Normal recommended dosage rate is: 1 ltr per 5 toms of fuel.\n\n" +
                $" 4. Benefits: \n\n" +
                $"     • You can rely on Unitor FuelPower AshFree to keep your sensitive engine parts free from corrosive deposits.\n\n" +
                $"     • Reduction of deposits and corrosion ensures your engine operates more efficiently.";
            }
            else
            {
                message = $"1. Cause: Ash, vanadium and sodium components in the fuel are prone to build low melting point deposits.\n\n\n\n" +
               $" 2. Solution: FuelPower AshFree, product nos 778789 contains components that will reduce the deposit formation and increase the melting point of the deposit." +
               $" For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-ashfree-25-ltr?tab=direction&all=1#direction-tab'>click here</a>" +
               $" Normal recommended dosage rate is 3kg per day.  \n\n\n\n" +
               $" 3. Normal recommended dosage rate is: 1 ltr per 5 toms of fuel.\n\n" +
               $" 4. Benefits: \n\n" +
               $"     • You can rely on Unitor FuelPower AshFree to keep your sensitive engine parts free from corrosive deposits.\n\n" +
               $"     • Reduction of deposits and corrosion ensures your engine operates more efficiently.";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Cause: Ash, vanadium and sodium components in the fuel are prone to build low melting point deposits. Solution: FuelPower AshFree, product nos 778789 contains components that will reduce the deposit formation and increase the melting point of the deposit.Normal recommended dosage rate is 3kg per day.Normal recommended dosage rate is: 1 ltr per 5 toms of fuel.Benefits:You can rely on Unitor FuelPower AshFree to keep your sensitive engine parts free from corrosive deposits.Reduction of deposits and corrosion ensures your engine operates more efficiently ";
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.HeavyCorrosion);
        }
    }
}
