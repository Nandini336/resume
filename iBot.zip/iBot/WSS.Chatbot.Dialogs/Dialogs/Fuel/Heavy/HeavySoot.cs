﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using System.Configuration;

/// <summary>
/// Class to implement level conversation for Heavy_Soot
/// </summary>

namespace ChatBot.Dialogs.Fuel
{

    [Serializable]
    public class HeavySoot : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        public HeavySoot(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                 message =   "1. Solution for Exhaust gas boiler / Economizer: FuelPower Soot Remover Liquid Plus product nos: 778848 is injected into the fuel gas, For more product info please  [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-soot-remover-liquid-plus). Normal recommended dosage is 3ltr per day continuous in exhaust system using out auto dosing unit. \n\n " +
                             "2. Solution for Auxiliary or main boiler: FuelPower Soot Remover Powder product nos: 571240." +
                             "    For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-soot-remover)" +
                             "    Normal recommended dosage rate is 3kg per day.\n\n" +
                             "3. Benefits: It will burn excess soot and dry out the remaining ash reducing deposits and keeping the exhaust gas economizer efficient for a longer time. ";
            }
            else
            {
                 message = "1. Solution for Exhaust gas boiler / Economizer: FuelPower Soot Remover Liquid Plus product nos: 778848 is injected into the fuel gas, For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-soot-remover-liquid-plus.'>click here</a>" +
                            "    Normal recommended dosage is 3ltr per day continuous in exhaust system using out auto dosing unit.   \n\n " +
                            "2. Solution for Auxiliary or main boiler: FuelPower Soot Remover Powder product nos: 571240." +
                            "    For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-soot-remover'>click here</a>" +
                            "    Normal recommended dosage rate is 3kg per day.  \n\n " +
                            "3. Benefits: It will burn excess soot and dry out the remaining ash reducing deposits and keeping the exhaust gas economizer efficient for a longer time. ";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Solution for Exhaust gas boiler or Economizer: FuelPower Soot Remover Liquid Plus product nos: 778848 is injected into the fuel gas. Normal recommended dosage is 3 litre per day continuous in exhaust system using out auto dosing unit.Solution for Auxiliary or main boiler: FuelPower Soot Remover Powder product nos: 571240.Normal recommended dosage rate is 3kg per day. Benefits: It will burn excess soot and dry out the remaining ash reducing deposits and keeping the exhaust gas economizer efficient for a longer time.";
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.HeavySoot);
        }
      
    }
}