﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using WSS.ChatBot.Common.Helper;
using System.Configuration;

/// <summary>
/// Class to implement level conversation for Heavy_Sludge
/// </summary>

namespace ChatBot.Dialogs.Fuel
{
    [Serializable]
    public class HeavySludge : IPostDataForFuel, IDialog<object>
    {

        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public HeavySludge(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> _ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.HeavySludge;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.HeavySludge);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.IncompatibleFuel +
                $"2. " + ConversationalOptions.HighWater +
                $"3. " + ConversationalOptions.Both +
                $"4. " + ConversationalOptions.None;
            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.IncompatibleFuel +
                           ConversationalOptions.HighWater +
                           ConversationalOptions.Both +
                           ConversationalOptions.None;
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.HeavySludge, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, AfterMenuSelection,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.AfterMenuSelection,
                 ConversationalOptions.HeavySludgeModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;
            switch (message.ToString())
            {
                case ConversationalOptions.IncompatibleFuel:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {

                        prompt = $"You should stabilize fuel with FuelPower Conditioner. Please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-conditioner) for the product details and dosage details.";
                    }
                    else
                    {
                        prompt = $"You should stabilize fuel with FuelPower Conditioner. Please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-conditioner'>click here</a> for the product details and dosage details.";
                    }
                    break;
                case ConversationalOptions.HighWater:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {

                        prompt = $"Please demulsify water in fuel with FuelPower Demulsifier. Please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-demulsifier) for the product details and dosage details.";
                    }
                    else
                    {
                        prompt = $"Please demulsify water in fuel with FuelPower Demulsifier. Please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-demulsifier'>click here</a> for the product details and dosage details.";
                    }
                    break;
                case ConversationalOptions.Both:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "You should stabilize fuel with FuelPower Conditioner. Please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-conditioner) for the product details and dosage details.";
                    }
                    else
                    {
                        prompt = "You should stabilize fuel with FuelPower Conditioner. Please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-conditioner'>click here</a> for the product details and dosage details.";
                    }
                    break;
                case ConversationalOptions.None:
                case "4":
                    prompt = "We will send your request to you WSS customer service and we will get in touch with you soon.";
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.AfterMenuSelection, prompt);
                    return;
            }

            var chatbody = MailContent.ChatDataForUserandBot(context, prompt);

            CreateDbData.Instance.BotResponse = prompt;

            string botResponse2Message = prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage;

            string resolvePrompt = botResponse2Message + " \n\n Yes / No";

            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse2 = WSS.ChatBot.Common.Common.HeaderMessage;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = "";
            ListCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            MailContent.ChatDataForBot(context, WSS.ChatBot.Common.Common.HeaderMessage + " \n\n Yes / No");

            var selection =
                new EndOfConversation(MailContent, ListCreateDbData)
                { Intent = ConstIntents.HeavySludge };

            MailContent.Intent = selection.Intent;
            //context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var activity = await result;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                await botResponses.YesNoCard(context, botResponse2Message);
            }
            else
            {
                await context.PostAsync(resolvePrompt);
            }
        }

        Task IDialog<object>.StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }

    }
}