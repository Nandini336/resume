﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using System.Configuration;

/// <summary>
/// Class to implement level conversation for Heavy_ImproperCombustion
/// </summary>

namespace ChatBot.Dialogs.Fuel
{
    [Serializable]
    public class Heavy_ImproperCombustion : IPostDataForFuel
    {
        public MailContent MailContent { get; set; }

        public List<CreateDbData> ListCreateDbData { get; set; }

        public Heavy_ImproperCombustion(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;
            string replyMsg = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                replyMsg = " 1. Cause: An unstable fuel can start coaking on the injectors causing fouling, flame impingement, black smoke and poor combustion efficiency. \n\n\n\n" +
                         " 2. Solution: FuelPower Catalyst product nos: 778787 contains a fuel conditioning component as well as a catalyst to help stabilize the fuel and to improve combustion of the fuel." +
                         " For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-catalyst-25-ltr?tab=direction&all=1#direction-tab)\n\n\n\n" +
                         " In addition at low loads we advise you to maintain high scavenge air temperature. \n\n\n\n" +
                         " 3. Normal dosage rate is 1ltr:15 tons of fuel  \n\n\n\n " +
                         " 4. Benefits: Improved combustion efficiency, reduced fuel ignition temperature, lesser carbon deposits, no black smoke or soot in exhaust, cleaner exhaust systems.";
            }
            else
            {
                replyMsg = " 1. Cause: An unstable fuel can start coaking on the injectors causing fouling, flame impingement, black smoke and poor combustion efficiency. \n\n\n\n" +
                         " 2. Solution: FuelPower Catalyst product nos: 778787 contains a fuel conditioning component as well as a catalyst to help stabilize the fuel and to improve combustion of the fuel." +
                         " For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/chemicals/fuel-oil-treatment/fuelpowerx-catalyst-25-ltr?tab=direction&all=1#direction-tab'>click here</a> " +
                         " In addition at low loads we advise you to maintain high scavenge air temperature. \n\n\n\n" +
                         " 3. Normal dosage rate is 1ltr:15 tons of fuel  \n\n\n\n " +
                         " 4. Benefits: Improved combustion efficiency, reduced fuel ignition temperature, lesser carbon deposits, no black smoke or soot in exhaust, cleaner exhaust systems.";

            }

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Cause: An unstable fuel can start coaking on the injectors causing fouling, " +
                "flame impingement, black smoke and poor combustion efficiency.Solution: FuelPower Catalyst product " +
                "nos: 778787 contains a fuel conditioning component as well as a catalyst to help stabilize the fuel and " +
                "to improve combustion of the fuel. In addition at low loads we advise you to maintain high scavenge air " +
                "temperature.Normal dosage rate is 1ltr:15 tons of fuel .Benefits: Improved combustion efficiency, reduced " +
                "fuel ignition temperature, lesser carbon deposits, no black smoke or soot in exhaust, cleaner exhaust systems";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg, ConstIntents.HeavyImproperCombustion);
        }


    }
}