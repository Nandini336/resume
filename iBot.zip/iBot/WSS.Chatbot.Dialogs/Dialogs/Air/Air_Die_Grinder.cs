﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Air
{
    public class Air_Die_Grinder : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Air_Die_Grinder(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {

            await activity;
            string message = $"We have 2 type of die grinder for this purpose. DG-PRO 18 (722009) and DG-PRO 22 (722017). Tools are to be use together with grinding stone set 536797.";


            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "We have 2 type of die grinder for this purpose. DG-PRO 18 (722009) and DG-PRO 22 (722017). Tools are to be use together with grinding stone set 536797.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Air_Die_Grinder);
        }
    }
}
