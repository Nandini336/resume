﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;


namespace WSS.Chatbot.Dialogs.Dialogs.Air
{
    [Serializable]
    public class Air_Angle_Grinder : IPostDataForFuel, IDialog<object>
    {

        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Air_Angle_Grinder(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> _ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Air_Angle_Grinder;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Air_Angle_Grinder);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.Pneumatic +
                $"2. " + ConversationalOptions.Cutting_grinding +
                $"3. " + ConversationalOptions.MopDisk +
                $"4. " + ConversationalOptions.SandingDisk +
                $"5. " + ConversationalOptions.InoxCutting;

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.Pneumatic +
                           ConversationalOptions.Cutting_grinding +
                           ConversationalOptions.MopDisk +
                           ConversationalOptions.SandingDisk +
                           ConversationalOptions.InoxCutting;

            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Air_Angle_Grinder, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, AfterMenuSelection,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.AfterMenuSelection,
                 ConversationalOptions.Air_Angle_GrinderModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;
            switch (message.ToString())
            {
                case ConversationalOptions.Pneumatic:
                case "1":

                    prompt = @"The range consist of AG-PRO 4B (756901) which is a 4"""+@"angle grinder, AG-PRO 5(721985) which is a 5"""+@" angle grinder and AG-PRO 7 (721977) which is a 7"""+" angle grinder.";

                    break;
                case ConversationalOptions.Cutting_grinding:
                case "2":

                    prompt = @"4"""+@"cutting disc(633515) 4"""+@" grinding disc (633523) 5"""+@" cutting disc(633547) 5"""+@" grinding disc (633555) 7"""+@" cutting disc(633563) 7"""+" grinding disc (633571)";

                    break;
                    
                case ConversationalOptions.MopDisk:
                case "3":

                    prompt = @"4"""+@" Mop disc #36 (633691), 4"""+@" Mop disc #60 (633699), 4"""+@" Mop disc #80 (633707), 5"""+@" Mop disc #36 (633715), 5"""+@" Mop disc #60 (633723)  5"""+@" Mop disc #80 (633731),  7"""+" Mop disc #60 (633747)";

                    break;
                case ConversationalOptions.SandingDisk:
                case "4":

                    prompt = @"Rubber pad for AG-PRO 4B (779063), Rubber pad for AG-PRO 7 (779064), 4"""+@" sanding disc #16 (656157), 4"""+@" sanding disc #36 (692582), 7"""+@" sanding disc #36 (633675)";

                    break;
                case ConversationalOptions.InoxCutting:
                case "5":

                    prompt = @"5"""+@" cutting disc INOX(633603), 5"""+@" grinding disc INOX(633595), 7"""+" cutting disc INOX(633611)";

                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.AfterMenuSelection, prompt);
                    return;
            }

            var chatbody = MailContent.ChatDataForUserandBot(context, prompt);

            CreateDbData.Instance.BotResponse = prompt;

            string botResponse2Message = prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage;

            string resolvePrompt = botResponse2Message + " \n\n Yes / No";

            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse2 = WSS.ChatBot.Common.Common.HeaderMessage;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = "";
            ListCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            MailContent.ChatDataForBot(context, WSS.ChatBot.Common.Common.HeaderMessage + " \n\n Yes / No");

            var selection =
                new EndOfConversation(MailContent, ListCreateDbData)
                { Intent = ConstIntents.Air_Angle_Grinder };

            MailContent.Intent = selection.Intent;
            context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var activity = await result;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                await botResponses.YesNoCard(context, botResponse2Message);
            }
            else
            {
                await context.PostAsync(resolvePrompt);
            }
        }

        Task IDialog<object>.StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }

    }
}