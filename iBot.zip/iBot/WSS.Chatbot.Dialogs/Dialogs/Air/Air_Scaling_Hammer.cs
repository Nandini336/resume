﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Air
{
    public  class Air_Scaling_Hammer : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Air_Scaling_Hammer(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {

            await activity;
            string message = $"We have SH-PRO 1 (722157) with 1 hammer and SH-PRO 3 (722165) with 3 hammer for faster and efficient coating removal. To support the equipment we have hammer replacement for SH-PRO 1(722462) and SH-PRO 3 (722769).";


            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "We have SH-PRO 1 (722157) with 1 hammer and SH-PRO 3 (722165) with 3 hammer for faster and efficient coating removal. To support the equipment we have hammer replacement for SH-PRO 1(722462) and SH-PRO 3 (722769).";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Air_Scaling_Hammer);
        }
    }
}
