﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

namespace WSS.Chatbot.Dialogs.Dialogs.Air
{
    [Serializable]
    public class Air_Hose : IPostDataForFuel, IDialog<object>
    {

        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Air_Hose(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> _ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Air_Hose;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Air_Hose);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.Rubber +
                $"2. " + ConversationalOptions.PVC;
              
            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.Rubber +
                           ConversationalOptions.PVC;
                          
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Air_Hose, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, AfterMenuSelection,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.AfterMenuSelection,
                 ConversationalOptions.Air_HoseModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;
            switch (message.ToString())
            {
                case ConversationalOptions.Rubber:
                case "1":
                    
                        prompt = @"We have a variety of rubber reinforce hoses ranging from 1/4"""+@"(671743) ,3 / 8"""+ @" (671750) , 1/2""" + @"(671768) , 3 / 4""" + @" (671776) and 1""" + @"(671786).";
                   
                    break;
                case ConversationalOptions.PVC:
                case "2":
                   
                        prompt = @"We have a variety of PVC reinforce hoses ranging from 1/4""" + @"(671693) , 3 / 8""" + @" (671701) , 1/2""" + @"(671719), 3 / 4""" + @" (671727) and 1""" + @"(671735).";
                   
                    break;
               
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.AfterMenuSelection, prompt);
                    return;
            }

            var chatbody = MailContent.ChatDataForUserandBot(context, prompt);

            CreateDbData.Instance.BotResponse = prompt;

            string botResponse2Message = prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage;

            string resolvePrompt = botResponse2Message + " \n\n Yes / No";

            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse2 = WSS.ChatBot.Common.Common.HeaderMessage;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = "";
            ListCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            MailContent.ChatDataForBot(context, WSS.ChatBot.Common.Common.HeaderMessage + " \n\n Yes / No");

            var selection =
                new EndOfConversation(MailContent, ListCreateDbData)
                { Intent = ConstIntents.Air_Hose };

            MailContent.Intent = selection.Intent;
            context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var activity = await result;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                await botResponses.YesNoCard(context, botResponse2Message);
            }
            else
            {
                await context.PostAsync(resolvePrompt);
            }
        }

        Task IDialog<object>.StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }

    }
}