﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;
using WSS.ChatBot.Common.Utils;
/// <summary>
/// Class to implement level conversation for Ropes_Main
/// </summary>

namespace WSS.Chatbot.Dialogs.Dialogs.Air
{
    [Serializable]
    public class Air_tools_quick_coupling : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }


        public Air_tools_quick_coupling(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Air_tools_quick_coupling;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Air_tools_quick_coupling);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                        $"1. " + ConversationalOptions.socketSeries +
                        $"2. " + ConversationalOptions.plusSeries;
                      
            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.socketSeries +
                           ConversationalOptions.plusSeries;
                          
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_Main, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Air_tools_quick_couplingModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 3);
            }
        }
        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;

            switch (message.ToString())
            {
                case ConversationalOptions.socketSeries:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "We have 3 types of socket quick coupling.";

                        var prompt2 = ConversationalOptions.CommonMessage +
                            ConversationalOptions.USM_Option1 +
                            ConversationalOptions.USF_Option2 +
                            ConversationalOptions.USH_Option3;
                            
                        PromptDialog.Choice(context, this.Level2_1,
                                            ConversationalOptions.Air_tools_quick_coupling1ModelCollection(),
                                          prompt + " \n\n  " + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "We have 3 types of socket quick coupling .";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.USM_Option1 +
                                $"2. " + ConversationalOptions.USF_Option2 +
                                $"3. " + ConversationalOptions.USH_Option3;
                              
                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2_1, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

              
                case ConversationalOptions.plusSeries:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "WSS recommend Acera ropes. Acera ropes are made both with and without cover. Please read more in our product portfolio.";

                        var prompt2 = ConversationalOptions.CommonMessage +
                                ConversationalOptions.UPH_Option1 +
                                ConversationalOptions.UPM_Option2 +
                                ConversationalOptions.UPF_Option3;

                        PromptDialog.Choice(context, this.Level2_2,
                                            ConversationalOptions.Air_tools_quick_coupling2ModelCollection(),
                                          prompt + " \n\n  " + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = "WSS recommend Acera ropes. Acera ropes are made both with and without cover. Please read more in our product portfolio.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.UPH_Option1 +
                                $"2. " + ConversationalOptions.UPM_Option2 +
                                $"3. " + ConversationalOptions.UPF_Option3;

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2_2, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;
               
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }

        }
        public async Task Level2_1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.USM_Option1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"USM come in sizes of 1/4"""+@"MPT , 3 / 8"""+@"MPT , 1/2"""+@"MPT , 3 / 4"""+@"MPT and 1"""+"MPT.For more information please refer to our online product catalogue.";
                        await botResponses.YesNoCard(context, prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);

                    }
                    else
                    {
                        
                         prompt = @"USM come in sizes of 1/4""" + @"MPT , 3 / 8""" + @"MPT , 1/2""" + @"MPT , 3 / 4""" + @"MPT and 1""" + "MPT.For more information please refer to our online product catalogue.";
                         await context.PostAsync(prompt);
                         MailContent.ChatDataForUserandBot(context, prompt);
                         await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Air_tools_quick_coupling);

                    }
                    break;

                case ConversationalOptions.USF_Option2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"USF come in sizes of 1/4"""+@"FPT , 3 / 8"""+@"FPT , 1/2"""+@"FPT , 3 / 4"""+@"FPT and 1"""+"FPT.For more information please refer to our online product catalogue.";
                        await botResponses.YesNoCard(context, prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"USF come in sizes of 1/4""" + @"FPT , 3 / 8""" + @"FPT , 1/2""" + @"FPT , 3 / 4""" + @"FPT and 1""" + "FPT.For more information please refer to our online product catalogue.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Air_tools_quick_coupling);
                    }
                    break;

                case ConversationalOptions.USH_Option3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"USH come in sizes of 1/4"""+@" , 3 / 8"""+@" , 1/2"""+@" , 3 / 4"""+@" and 1"""+" For more information please refer to our online product catalogue.";
                        await botResponses.YesNoCard(context, prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"USH come in sizes of 1/4""" + @" , 3 / 8""" + @" , 1/2""" + @" , 3 / 4""" + @" and 1""" + " For more information please refer to our online product catalogue.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Air_tools_quick_coupling);
                    }
                    break;
               
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2_1, prompt);
                    return;
            }
        }

        public async Task Level2_2(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.UPH_Option1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"UPH come in sizes of 1/4"""+@" , 3 / 8"""+@" , 1/2"""+@" , 3 / 4"""+@" and 1"""+" For more information please refer to our online product catalogue.";
                        await botResponses.YesNoCard(context, prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);

                    }
                    else
                    {

                        prompt = @"UPH come in sizes of 1/4""" + @" , 3 / 8""" + @" , 1/2""" + @" , 3 / 4""" + @" and 1""" + " For more information please refer to our online product catalogue.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Air_tools_quick_coupling);

                    }
                    break;

                case ConversationalOptions.UPM_Option2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"UPM come in sizes of 1/4"""+@" MPT , 3 / 8"""+@"MPT , 1/2"""+@"MPT , 3 / 4"""+@"MPT and 1"""+"MPT.For more information please refer to our online product catalogue.";
                        await botResponses.YesNoCard(context, prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"UPM come in sizes of 1/4""" + @" MPT , 3 / 8""" + @"MPT , 1/2""" + @"MPT , 3 / 4""" + @"MPT and 1""" + "MPT.For more information please refer to our online product catalogue.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Air_tools_quick_coupling);
                    }
                    break;

                case ConversationalOptions.UPF_Option3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"UPF come in sizes of 1/4"""+@"FPT , 3 / 8"""+@"FPT , 1/2"""+@"FPT , 3 / 4"""+@"FPT and 1"""+"FPT.For more information please refer to our online product catalogue.";
                        await botResponses.YesNoCard(context, prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"UPF come in sizes of 1/4""" + @"FPT , 3 / 8""" + @"FPT , 1/2""" + @"FPT , 3 / 4""" + @"FPT and 1""" + "FPT.For more information please refer to our online product catalogue.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Air_tools_quick_coupling);
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2_2, prompt);
                    return;
            }
        }
        
    }
}