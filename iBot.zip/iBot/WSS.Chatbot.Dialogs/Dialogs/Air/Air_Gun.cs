﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Air
{
    
    public class Air_Gun : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Air_Gun(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {

            await activity;
            string message = $"We have 2 type of air gun in our range. AG - PRO 10(718910) is a shorter version with 10cm in length while AG - PRO 30(718957) is a longer version with 30cm in length.";
            
           
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "We have two type of air gun in our range. AG - PRO 10(718910) is a shorter version with 10cm in length while AG - PRO 30(718957) is a longer version with 30cm in length.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Air_Gun);
        }
    }
}
