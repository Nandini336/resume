﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class SkinCare_EasyClean_Natural_Hand_Cleaner : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public SkinCare_EasyClean_Natural_Hand_Cleaner(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Start using **Natural Hand Cleaner**. This is a heavy duty cleaner that is mild to the skin while removing the most stubborn grime, oil and grease contaminants.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.SkinCare_EasyClean_Natural_Hand_Cleaner);
        }
    }
}
