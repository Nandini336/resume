﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class Galley_Gamazyme_Digestor : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Galley_Gamazyme_Digestor(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "1. Dose **Gamazyme Digestor** into the grease trap at about 2 litre per m� after every work day, and it will start to attack the blockage and remove the bad smell.\n\n" +
                "2. Click here for more product details: http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-digestor-20-ltr-bag-in-box";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Galley_Gamazyme_Digestor);
        }
    }
}
