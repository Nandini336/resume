﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class Cleaning_Shelf_life_Gamayzme_TDS : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Cleaning_Shelf_life_Gamayzme_TDS(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Gamazyme TDS has no shelf life as such. It is important that the product is stored in sealed containers protected from frost and heat as advised in the SDS, regular inspection is recommended to secure that the packaging is in good condition. Wilhelmsen Ships Service recommends to consume the product within 5 years from date of delivery.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Cleaning_Shelf_life_Gamayzme_TDS);
        }
    }
}
