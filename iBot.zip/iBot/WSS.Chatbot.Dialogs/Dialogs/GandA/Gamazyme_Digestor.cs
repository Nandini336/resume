﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;
namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class Gamazyme_Digestor : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Gamazyme_Digestor(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "1. For shower: Use 500ml of **Gamazyme Digestor** per 5cm drain diameter to break down the organic matter. After the blockage is removed a small maintenance dose of **Gamazyme Digestor** daily will assist in keeping the pipes open.\n\n" +
                "2. click for more product details: http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-digestor-20-ltr-bag-in-box ";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Gamazyme_Digestor);
        }
    }
}
