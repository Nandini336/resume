﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class SkinCare_EasyClean_After_Work_Lotion : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public SkinCare_EasyClean_After_Work_Lotion(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "1. Start using **EasyClean After Work Lotion** at the end of the working day. Clean and dry hands thoroughly." + $"Apply 1 - 3 ml of the lotion and rub well into skin. \n\n" +
              "2. click here for more product info: http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-afterwork-lotion ";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.SkinCare_EasyClean_After_Work_Lotion);
        }
    }
}
