﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class SkinCare_EasyClean_Hand_Barrier_Cream_Wet : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public SkinCare_EasyClean_Hand_Barrier_Cream_Wet(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Before work, apply 1 pump (1-2 ml) of **EasyClean Hand Barrier Cream Wet**. Rub well into the skin, especially around nails and cuticles." + $"If hands are washed before end of work, re-apply the cream for maximum protection.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.SkinCare_EasyClean_Hand_Barrier_Cream_Wet);
        }
    }
}
