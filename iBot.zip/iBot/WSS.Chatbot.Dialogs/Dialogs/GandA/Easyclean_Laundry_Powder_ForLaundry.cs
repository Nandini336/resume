﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class Easyclean_Laundry_Powder_ForLaundry : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Easyclean_Laundry_Powder_ForLaundry(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "1. This might be because of hard water from bunkering of shore water, increase dosage of the " + $"**EasyClean Laundry Powder** from 50 to 80 grams or **EasyClean Laundry Tablets** from 1 to 2 pcs. \n\n" +
                "2. click here for product info on powder: http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-laundry-powder ";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Easyclean_Laundry_Powder_ForLaundry);
        }
    }
}
