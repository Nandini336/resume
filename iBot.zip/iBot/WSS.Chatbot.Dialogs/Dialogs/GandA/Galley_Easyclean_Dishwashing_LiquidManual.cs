﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class Galley_Easyclean_Dishwashing_LiquidManual : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Galley_Easyclean_Dishwashing_LiquidManual(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "1. Scrape off excess and clean/scrub with a solution of **EasyClean Dishwashing Liquid Manual** in warm water." + $" Ensure that there is a layer of foam on top of the cleaning solution to protect against redepositing of the oils and fat.Rinse off with water.\n\n" + "If in case of oil and grease on plates and cutlery: \n\n Replace the cleaning water with a fresh solution of **EasyClean Dishwashing Liquid Manual** at a concentration of 7 ml / 10 Liter.\n\n" +
                "2. click here for more product info: http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-dishwash-liquid-manual ";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Galley_Easyclean_Dishwashing_LiquidManual);
        }
    }
}
