﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class Easyclean_Cleaning_And_DisInfection_Sanite128F : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Easyclean_Cleaning_And_DisInfection_Sanite128F(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "If heavily soiled or dirty, clean first with **EasyClean Floor & Hard Surface**. Followed by or if not heavily soiled, clean and disinfect with **EasyClean Cleaning & Disinfection or Sanite 128 F.**\n\n" 
                + "If food is going off quicker ion cold storage, then this might be due to bacteria or fungi growth in the cold storage.Perform a proper cleaning and disinfection with **EasyClean Cleaning & Disinfection** or **Sanite 128 F.**";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Easyclean_Cleaning_And_DisInfection_Sanite128F);
        }
    }
}
