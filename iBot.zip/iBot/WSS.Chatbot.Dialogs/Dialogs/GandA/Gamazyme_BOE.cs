﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class Gamazyme_BOE : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Gamazyme_BOE(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "1. Spray **Gamazyme BOE** onto soft surfaces like curtains, carpets and furniture in the cabin. This will remove cigarette smoke smell and other odours.\n\n" +
                "2. click here for more info on product: http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-boe-12x1-l?tab=ordering&all=1#ordering-tab";


           var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Gamazyme_BOE);
        }
    }
}
