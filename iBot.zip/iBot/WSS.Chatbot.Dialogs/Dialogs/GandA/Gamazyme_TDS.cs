﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class Gamazyme_TDS : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Gamazyme_TDS(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "1. For Toilets and Urinals: Add one sachet of **Gamazyme TDS** per toilet every 2 to 3 weeks to dissolve urine-scale, and to maintain a healthy microbiological environment in the pipes and sewage system.\n\n" +
               "2. Click for more information on the product : http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/bio-chemicals/gamazymex-tds ";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Gamazyme_TDS);
        }
    }
}
