﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;


namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class Drains_Gamazyme700_FN : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Drains_Gamazyme700_FN(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Dose **Gamazyme 700 FN** on a regular basis until the planned maintenance.The microorganisms will break down organic material to water(H�O) and carbon dioxide(CO�).\n\n" +
                "In case of any foul smell: \n\n Add the desired dose of **Gamazyme 700 FN** into the tank or through the toilets closest to the tanks.";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Drains_Gamazyme700_FN);
        }
    }
}
