﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.GandA
{
    public class SkinCare_EasyClean_Hand_Sanitizer : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public SkinCare_EasyClean_Hand_Sanitizer(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "1. Many conventional hand sanitizers are alcohol based, and many of them dry out the skin. " + $"**EasyClean Hand Sanitizer** is based on a different technology that sanitizes for a longer time period and moistens the skin. \n\n" +
                "2. click here for more product info: http://wssproducts.wilhelmsen.com/marine-chemicals/cleaning-and-maintenance-1/galley-and-accommodation/easycleanx-hand-sanitizer";

            var qandA = new QandA(this.ListCreateDbData);
            await qandA.MainWithIntent(context, activity, message, ConstIntents.SkinCare_EasyClean_Hand_Sanitizer);
        }
    }
}
