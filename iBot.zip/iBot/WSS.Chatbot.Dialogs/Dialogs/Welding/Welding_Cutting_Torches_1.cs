﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.Welding
{
    [Serializable]
    public class Welding_Cutting_Torches_1 : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Welding_Cutting_Torches_1(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Cutting nozzle for use with our Unitor cutting torch. Available in 4 different nozzle design for different plate thickness. Cutting nozzle No 2 (3-10mm), cutting nozzle No 3 (10-25), cutting nozzle No 4 (25-50) and cutting nozzle No 5 (50-100). For more information please refer to our online product catalogue.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Cutting nozzle for use with our Unitor cutting torch. Available in 4 different nozzle design for different plate thickness. Cutting nozzle No 2 (3 - 10 mm), cutting nozzle No 3 (10 - 25 mm), cutting nozzle No 4 (25 - 50 mm) and cutting nozzle No 5 (50 - 100 mm). For more information please refer to our online product catalogue.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Welding_Cutting_Torches_1);
        }
    }
}