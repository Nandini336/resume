﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.Welding
{
    [Serializable]
    public class Welding_Accessories : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Welding_Accessories(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Unitor offer a wide range of accessories ranging from electrode holder, return clamp, welding cable, cable connector chipping hammer, wire brush ect. For more information, please refer to our online product catalogue.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Unitor offer a wide range of accessories ranging from electrode holder, return clamp, welding cable, cable connector chipping hammer, wire brush ect. For more information, please refer to our online product catalogue.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Welding_Accessories);
        }
    }
}