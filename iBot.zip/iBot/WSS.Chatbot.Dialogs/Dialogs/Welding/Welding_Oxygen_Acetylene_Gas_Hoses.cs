﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

/// <summary>
/// Class to implement level conversation for Ropes_MixType
/// </summary>

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.Welding
{
    [Serializable]
    public class Welding_Oxygen_Acetylene_Gas_Hoses : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Welding_Oxygen_Acetylene_Gas_Hoses(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Welding_Oxygen_Acetylene_Gas_Hoses;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Welding_Oxygen_Acetylene_Gas_Hoses);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1 +
                $"2. " + ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_2 ;


            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1 +
                           ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_2;                          


            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Welding_Oxygen_Acetylene_Gas_Hoses, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Welding_Oxygen_Acetylene_Gas_HosesModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }
      
        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;

            switch (message.ToString())
            {
                case ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"The gas hoses come in 2 sizes, 1/4""(6.3mm) and 3 / 8""(9mm). We have these hoses in either twin hoses(Ox & Ac) or individual hoses(Ox hose or Ac hose).";

                        var prompt2 = ConversationalOptions.CommonMessage +
                            ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1_1 +
                            ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1_2 ;

                        PromptDialog.Choice(context, this.Level2,
                                            ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = @"The gas hoses come in 2 sizes, 1/4""(6.3mm) and 3 / 8""(9mm). We have these hoses in either twin hoses(Ox & Ac) or individual hoses(Ox hose or Ac hose).";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1_1 +
                                $"2. " + ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1_2;
                               

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;
                case ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"Yes we do have individual gas hoses for Oxygen and Acetylene line. They are in hose size of 1/4""(6.3mm) or 3/8""(9mm).";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"Yes we do have individual gas hoses for Oxygen and Acetylene line. They are in hose size of 1/4""(6.3mm) or 3/8""(9mm).";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Flashback_Arrestor);
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }


        private async Task Level2(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"Yes we have fix length gas hoses with fittings on both ends. They are available in 10m twin hose 1/4""(6.3mm) or 10m and 25m twin hose 3 / 8""(9mm).";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"Yes we have fix length gas hoses with fittings on both ends. They are available in 10m twin hose 1/4""(6.3mm) or 10m and 25m twin hose 3 / 8""(9mm).";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Oxygen_Acetylene_Gas_Hoses);
                    }

                    break;
                case ConversationalOptions.Welding_Oxygen_Acetylene_Gas_Hoses_1_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"They are supply together in either 1/4"" or 3 / 8"" coil.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"They are supply together in either 1/4"" or 3 / 8"" coil.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Oxygen_Acetylene_Gas_Hoses);
                    }

                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2, prompt);
                    return;

            }      
        }

      
    }
}