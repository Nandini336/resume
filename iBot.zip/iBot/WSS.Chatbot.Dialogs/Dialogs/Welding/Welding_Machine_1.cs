﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

/// <summary>
/// Class to implement level conversation for Ropes_MixType
/// </summary>

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.Welding
{
    [Serializable]
    public class Welding_Machine_1 : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Welding_Machine_1(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Welding_Machine_1;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Welding_Machine_1);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.Welding_Machine_1_1 +
                $"2. " + ConversationalOptions.Welding_Machine_1_2 +
                $"3. " + ConversationalOptions.Welding_Machine_1_3;
            


            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.Welding_Machine_1_1 +
                           ConversationalOptions.Welding_Machine_1_2 +
                           ConversationalOptions.Welding_Machine_1_3;


            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Welding_Machine_1, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Welding_Machine_1ModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }

        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;

            switch (message.ToString())
            {
                case ConversationalOptions.Welding_Machine_1_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"We do not have welding machine that operates on 110V power supply.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"We do not have welding machine that operates on 110V power supply.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Machine_1);
                    }
                    break;

                case ConversationalOptions.Welding_Machine_1_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"UWI-150TP operates on 230V and supply 150amps. It is able to perform stick and TIG welding with the correct accessories.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"UWI-150TP operates on 230V and supply 150amps. It is able to perform stick and TIG welding with the correct accessories.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Machine_1);
                    }
                    break;

                case ConversationalOptions.Welding_Machine_1_3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"We have a few welding machine model that we are able to function on 400/440V power supply.";

                        var prompt2 = ConversationalOptions.CommonMessage +
                            ConversationalOptions.Welding_Machine_1_3_1 +
                            ConversationalOptions.Welding_Machine_1_3_2+
                            ConversationalOptions.Welding_Machine_1_3_3;

                        PromptDialog.Choice(context, this.Level2,
                                            ConversationalOptions.Welding_Machine_1_3ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = @"We have a few welding machine model that we are able to function on 400/440V power supply.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.Welding_Machine_1_3_1 +
                                $"2. " + ConversationalOptions.Welding_Machine_1_3_2 +
                                $"3. " + ConversationalOptions.Welding_Machine_1_3_3;

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;              
                
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }


        private async Task Level2(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;

            switch (message.ToString())
            {
                case ConversationalOptions.Welding_Machine_1_3_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"UWI-203TP operate with 400/440V power supply and provide max 200amps welding amperage. 
                        It is able to perform stick and TIG welding with the correct accessories.
                        Recommended welding electrode size of up to 4.0mm.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"UWI-203TP operate with 400/440V power supply and provide max 200amps welding amperage. 
                        It is able to perform stick and TIG welding with the correct accessories.
                        Recommended welding electrode size of up to 4.0mm.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Machine_1);
                    }
                    break;

                case ConversationalOptions.Welding_Machine_1_3_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"UWI-320TP operate with 400/440V power supply and provide max 320amps welding amperage.
                            It is able to perform stick and TIG welding with the correct accessories.
                            Recommended welding electrode size of up to 5.0mm.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"UWI-320TP operate with 400/440V power supply and provide max 320amps welding amperage.
                            It is able to perform stick and TIG welding with the correct accessories.
                            Recommended welding electrode size of up to 5.0mm.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Machine_1);
                    }
                    break;
                case ConversationalOptions.Welding_Machine_1_3_3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"UWI-500TP operate with 400/440V power supply and provide max 500amps welding amperage.
                            It is able to perform Stick/TIG welding with the correct accessories. In combination with UWF-102, you can perform MIG/MAG welding. 
                            Air carbon gouging is also possible with the right accessories. Recommended welding electrode size of up to 6.0mm.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"UWI-500TP operate with 400/440V power supply and provide max 500amps welding amperage.
                            It is able to perform Stick/TIG welding with the correct accessories. In combination with UWF-102, you can perform MIG/MAG welding. 
                            Air carbon gouging is also possible with the right accessories. Recommended welding electrode size of up to 6.0mm.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Machine_1);
                    }
                    break;

                    default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2, prompt);
                    return;

            }
        }


    }
}