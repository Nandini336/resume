﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

/// <summary>
/// Class to implement level conversation for Ropes_MixType
/// </summary>

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.Welding
{
    [Serializable]
    public class Welding_Regulator_Oxygen_Acetylene : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Welding_Regulator_Oxygen_Acetylene(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Welding_Regulator_Oxygen_Acetylene;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Welding_Regulator_Oxygen_Acetylene);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.OxygenandAcetylene +
                $"2. " + ConversationalOptions.regFun +
                $"2. " + ConversationalOptions.regServicing;

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.OxygenandAcetylene +
                           ConversationalOptions.regFun +
                           ConversationalOptions.regServicing;


            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Welding_Regulator_Oxygen_Acetylene, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Welding_Regulator_Oxygen_AcetyleneModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }

        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {

            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;

            switch (message.ToString())
            {
                case ConversationalOptions.OxygenandAcetylene:
                case "1":

                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"We have a few model design for different area application. We have R510, R520 and R530.";

                        var prompt2 = ConversationalOptions.CommonMessage +
                            ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_1_1 +
                            ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_1_2 +
                            ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_1_3;

                        PromptDialog.Choice(context, this.Level2ForOption1,
                                            ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_1ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = @"We have a few model design for different area application. We have R510, R520 and R530.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.Welding_Flashback_Arrestor_1_1 +
                                $"2. " + ConversationalOptions.Welding_Flashback_Arrestor_1_2 +
                                $"3. " + ConversationalOptions.Welding_Flashback_Arrestor_1_3;

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2ForOption1, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }                  
                    break;

                case ConversationalOptions.regFun:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"It is to bring down the gas pressure to a suitable working pressure.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"It is to bring down the gas pressure to a suitable working pressure.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Regulator_Oxygen_Acetylene);
                    }
                    break;
                case ConversationalOptions.regServicing:
                case "3":

                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"No, it is not advisable to repair or service regulator. The assembly and setting is done during the manufacturer process and are not to be tempered with.
                                You can only replace the display gauges if they are damage.	 ";

                        var prompt2 = ConversationalOptions.CommonMessage +
                            ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3_1 +
                            ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3_2 +
                             ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3_3;

                        PromptDialog.Choice(context, this.Level2ForOption3,
                                            ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = @"No, it is not advisable to repair or service regulator. The assembly and setting is done during the manufacturer process and are not to be tempered with.
                                You can only replace the display gauges if they are damage.	 ";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3_1 +
                                $"2. " + ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3_2 +
                                $"3. " + ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3_3;

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2ForOption3, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }

        private async Task Level2ForOption1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_1_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"We recommend to use R510 Oxygen regulator and R510 Acetylene regulator for direct cylinder mounting.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"We recommend to use R510 Oxygen regulator and R510 Acetylene regulator for direct cylinder mounting.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Regulator_Oxygen_Acetylene);
                    }

                    break;
                case ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_1_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"We recommend to use R530 Oxygen regulator and R530 Acetylene regulator for gas outlet station.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"We recommend to use R530 Oxygen regulator and R530 Acetylene regulator for gas outlet station.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Regulator_Oxygen_Acetylene);
                    }

                    break;
                case ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_1_3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"We recommend to use R520 Oxygen regulator and R520 Acetylene regulator for cylinder central storage area.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"We recommend to use R520 Oxygen regulator and R520 Acetylene regulator for cylinder central storage area.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Regulator_Oxygen_Acetylene);
                    }

                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2ForOption1, prompt);
                    return;

            }                  
        
        }

        private async Task Level2ForOption3(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"Regulator are recommend to be replace at least every 5 years.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"Regulator are recommend to be replace at least every 5 years.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Regulator_Oxygen_Acetylene);
                    }

                    break;

                case ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"We have content gauge and working gauge as spares available for order as a separate item.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"We have content gauge and working gauge as spares available for order as a separate item.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Regulator_Oxygen_Acetylene);
                    }

                    break;
                case ConversationalOptions.Welding_Regulator_Oxygen_Acetylene_3_3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = @"The gauges are design differently because of cylinder pressure. Typical 40L Oxygen cylidner is 150bar while 40L Acetylene cylinder is 18bar.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = @"The gauges are design differently because of cylinder pressure. Typical 40L Oxygen cylidner is 150bar while 40L Acetylene cylinder is 18bar.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Regulator_Oxygen_Acetylene);
                    }

                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2ForOption3, prompt);
                    return;
            }

        }

    }
}