﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;


namespace WSS.Chatbot.Dialogs.Dialogs.Welding
{
    [Serializable]
    public class Welding_Wire : IPostDataForFuel, IDialog<object>
    {

        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Welding_Wire(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> _ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Welding_Wire;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Welding_Wire);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.aluminium +
                $"2. " + ConversationalOptions.structural_steels +
                $"3. " + ConversationalOptions.stainless_steel +
                $"4. " + ConversationalOptions.nickel_alloy +
                $"5. " + ConversationalOptions.aluminium_alloy;

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.aluminium +
                           ConversationalOptions.structural_steels +
                           ConversationalOptions.stainless_steel +
                           ConversationalOptions.nickel_alloy +
                           ConversationalOptions.aluminium_alloy;

            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Welding_Wire, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, AfterMenuSelection,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.AfterMenuSelection,
                 ConversationalOptions.Welding_WireModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;
            switch (message.ToString())
            {
                case ConversationalOptions.aluminium:
                case "1":

                    prompt = $"We have ALUMAG W 235 in spool of 1.0mm, 2kg for welding of aluminium and aluminium alloys. For more information, please refer to our online product catalogue.structural steel, stainless steel, mild steel to stainless steel, copper nickel alloys, Yorcalbro and aluminium alloy. For more information, please refer to our online product catalogue.";

                    break;
                case ConversationalOptions.structural_steels:
                case "2":

                    prompt = $"We have GPS W 200 in spool of 0.8mm, 5kg for welding of structural steel. MS-W-201 Selfshield in spool of 0.8mm, 4.5kg for welding of mild steel to structural steel. For more information, please refer to our online product catalogue.";

                    break;

                case ConversationalOptions.stainless_steel:
                case "3":

                    prompt = $"We have S316 M-GF 221 in spool of 0.9mm, 2.5kg for welding of stainless steel. S309 M-GF 222 in spool of 0.9mm, 2.5kg for welding of mild steel to stainless. For more information, please refer to our online product catalogue.";

                    break;
                case ConversationalOptions.nickel_alloy:
                case "4":

                    prompt = $"We have ICUNI W 239 in spool of 0.8mm, 5kg for welding of cunifer pipe. For more information, please refer to our online product catalogue.";

                    break;
                case ConversationalOptions.aluminium_alloy:
                case "5":

                    prompt = $"We have IALBRO W 237 in spool of 0.8mm, 5kg for welding of Yorcalbro pipes. For more information, please refer to our online product catalogue.";

                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.AfterMenuSelection, prompt);
                    return;
            }

            var chatbody = MailContent.ChatDataForUserandBot(context, prompt);

            CreateDbData.Instance.BotResponse = prompt;

            string botResponse2Message = prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage;

            string resolvePrompt = botResponse2Message + " \n\n Yes / No";

            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse2 = WSS.ChatBot.Common.Common.HeaderMessage;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = "";
            ListCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            MailContent.ChatDataForBot(context, WSS.ChatBot.Common.Common.HeaderMessage + " \n\n Yes / No");

            var selection =
                new EndOfConversation(MailContent, ListCreateDbData)
                { Intent = ConstIntents.Welding_Wire };

            MailContent.Intent = selection.Intent;
           // context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var activity = await result;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                await botResponses.YesNoCard(context, botResponse2Message);
            }
            else
            {
                await context.PostAsync(resolvePrompt);
            }
        }

        Task IDialog<object>.StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }

    }
}