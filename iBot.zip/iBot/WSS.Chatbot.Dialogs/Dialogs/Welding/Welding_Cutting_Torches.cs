﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.Welding
{
    [Serializable]
    public class Welding_Cutting_Torches : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Welding_Cutting_Torches(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Unitor combination torch UCT-500 covers all normally occurring, heating, brazing, welding and cutting application for which the acetylene and oxygen flame maybe used. For more information please refer to our online product catalogue.";

            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Unitor combination torch UCT - 500 covers all normally occurring, heating, brazing, welding and cutting application for which the acetylene and oxygen flame maybe used. For more information please refer to our online product catalogue.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Welding_Cutting_Torches);
        }
    }
}