﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

/// <summary>
/// Class to implement level conversation for Ropes_Main
/// </summary>

namespace WSS.Chatbot.Dialogs.Dialogs.Fuel.Welding
{
    [Serializable]
    public class Welding_Flashback_Arrestor : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Welding_Flashback_Arrestor(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Welding_Flashback_Arrestor;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Welding_Flashback_Arrestor);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.Welding_Flashback_Arrestor_1 +
                $"2. " + ConversationalOptions.Welding_Flashback_Arrestor_2;              

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.Welding_Flashback_Arrestor_1 +
                           ConversationalOptions.Welding_Flashback_Arrestor_2 ;


            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Welding_Flashback_Arrestor, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Welding_Flashback_ArrestorModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }

        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;

            switch (message.ToString())
            {
                case ConversationalOptions.Welding_Flashback_Arrestor_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "We have 3 different model of flashback arrestor available in our product range. \n\n" +
                                 "Torch mounted flashback arrestor model FR-20.\n\n" +
                                 " Cylinder mounted/outlet station flashback arrestor model W-66(high flow capacity) or S-55(lower flow capacity).\n\n" +
                                 " Lastly is cylinder central mounted flashback arrestor model 85-10.";

                        var prompt2 = ConversationalOptions.CommonMessage +
                            ConversationalOptions.Welding_Flashback_Arrestor_1_1 +
                            ConversationalOptions.Welding_Flashback_Arrestor_1_2 +
                            ConversationalOptions.Welding_Flashback_Arrestor_1_3;

                        PromptDialog.Choice(context, this.Level2_1,
                                            ConversationalOptions.Welding_Flashback_Arrestor_1_1ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = "We have 3 different model of flashback arrestor available in our product range. \n\n" +
                                 "Torch mounted flashback arrestor model FR-20.\n\n" +
                                 " Cylinder mounted/outlet station flashback arrestor model W-66(high flow capacity) or S-55(lower flow capacity).\n\n" +
                                 " Lastly is cylinder central mounted flashback arrestor model 85-10.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.Welding_Flashback_Arrestor_1_1 +
                                $"2. " + ConversationalOptions.Welding_Flashback_Arrestor_1_2 +
                                $"3. " + ConversationalOptions.Welding_Flashback_Arrestor_1_3;

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2_1, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

                case ConversationalOptions.Welding_Flashback_Arrestor_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "Unitor flashback arrestor depending on model comes with \n\n **Flame arrestor** which stopped and quench the flashback.\n\n " +
                                 "**Non -return valve** stops a sudden reverse flow. \n\n" +
                                 "**Pressure sensitive cut off valve** stop the gas flow when experiencing an increasing reverse gas flow.\n\n " +
                                 "**Temperature sensitive cut off valve** automatically close upon reaching a critical flashback temperature of 95 degree C.\n\n " +
                                 "**Explosion pressure relief valve** spring loaded venting of the flashback shock waves and soot.";

                        var prompt2 = ConversationalOptions.CommonMessage +
                            ConversationalOptions.Welding_Flashback_Arrestor_2_1 +
                            ConversationalOptions.Welding_Flashback_Arrestor_2_2 +
                             ConversationalOptions.Welding_Flashback_Arrestor_2_3 +
                            ConversationalOptions.Welding_Flashback_Arrestor_2_4;

                        PromptDialog.Choice(context, this.Level2_2,
                                            ConversationalOptions.Welding_Flashback_Arrestor_2_1ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = "Unitor flashback arrestor depending on model comes with \n\n **Flame arretor** which stopped and quench the flashback.\n\n " +
                                 "**Non -return valve** stops a sudden reverse flow. \n\n" +
                                 "**Pressure sensitive cut off valve** stop the gas flow when experiencing an increasing reverse gas flow.\n\n " +
                                 "**Temperature sensitive cut off valve** automatically close upon reaching a critical flashback temperature of 95 degree C.\n\n " +
                                 "**Explosion pressure relief valve** spring loaded venting of the flashback shock waves and soot.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.Welding_Flashback_Arrestor_1_1 +
                                $"2. " + ConversationalOptions.Welding_Flashback_Arrestor_1_2 +
                                $"3. " + ConversationalOptions.Welding_Flashback_Arrestor_1_3;

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2_2, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }
      
  

      public async Task Level2_1(IDialogContext context, IAwaitable<object> result)
      {
        var message = await result;
        string prompt;
        FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
        BotResponses botResponses = new BotResponses(ListCreateDbData);
        CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

        switch (message.ToString())
        {
            case ConversationalOptions.Welding_Flashback_Arrestor_1_1:
            case "1":
                if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                {
                    prompt = @"You are recommended to use S-55 flashback arrestor.";
                    await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                }
                else
                {
                    prompt = @"You are recommended to use S-55 flashback arrestor.";
                    await context.PostAsync(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Flashback_Arrestor);
                }

                break;

            case ConversationalOptions.Welding_Flashback_Arrestor_1_2:
            case "2":
                if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                {
                    prompt = @"You are recommended to use S-55 flashback arrestor for gas welding and brazing operation that is using less that 10m length gas hoses W-66 for gas welding,
                              cutting and gouging operation with gas hoses longer than 10m in length. This is to ensure sufficient gas hose.";
                    await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                }
                else
                {
                    prompt = @"You are recommended to use S-55 flashback arrestor for gas welding and brazing operation that is using less that 10m length gas hoses W-66 for gas welding,
                              cutting and gouging operation with gas hoses longer than 10m in length. This is to ensure sufficient gas hose.";
                    await context.PostAsync(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Flashback_Arrestor);
                }

                break;

            case ConversationalOptions.Welding_Flashback_Arrestor_1_3:
            case "3":
                if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                {
                    prompt = @"You are recommend to use 85-10 flashback arrestor.";
                    await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                }
                else
                {
                    prompt = @"You are recommend to use 85-10 flashback arrestor.";
                    await context.PostAsync(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Flashback_Arrestor);
                }
                break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2_1, prompt);
                    return;
        }
      }
        public async Task Level2_2(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.Welding_Flashback_Arrestor_2_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Unitor FR-20 flashback arrestor is a basic arrestor that comes with **flame arrestor** & **Non return valve**.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Unitor FR-20 flashback arrestor is a basic arrestor that comes with **flame arrestor** & **Non return valve**.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Flashback_Arrestor);
                    }

                    break;

                case ConversationalOptions.Welding_Flashback_Arrestor_2_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Unitor W-66 flashback arrestor comes with a complete safety elements like **flame arrestor**, **Non return valve**, **Pressure sensitive cut off valve**, **Temperature sensitive cut off valve** and **Explosion pressure relief valve**.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Unitor W-66 flashback arrestor comes with a complete safety elements like **flame arrestor**, **Non return valve**, **Pressure sensitive cut off valve**, **Temperature sensitive cut off valve** and **Explosion pressure relief valve**.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Flashback_Arrestor);
                    }

                    break;

                case ConversationalOptions.Welding_Flashback_Arrestor_2_3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Unitor S-55 flashback arrestor comes with a safety elements like **flame arrestor**, **Non return valve**, & **Temperature sensitive cut off valve**.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Unitor S-55 flashback arrestor comes with a safety elements like **flame arrestor**, **Non return valve**, & **Temperature sensitive cut off valve**.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Flashback_Arrestor);
                    }
                    break;
                case ConversationalOptions.Welding_Flashback_Arrestor_2_4:
                case "4":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Unitor S-55 flashback arrestor comes with a safety elements like **flame arrestor**, **Non return valve**, & **Temperature sensitive cut off valve**.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Unitor S-55 flashback arrestor comes with a safety elements like **flame arrestor**, **Non return valve**, & **Temperature sensitive cut off valve**.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Welding_Flashback_Arrestor);
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2_2, prompt);
                    return;
            }
        }
       

      
    }
}
  
