﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.OilTest
{
    public class Oiltest_Viscosity : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Oiltest_Viscosity(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;

            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "1. Solution for viscosity of oil: Our highest seling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs." +
                             " The DIGI Combined Oil Test Kit from Unitor comes complete with tests for Water in Oil, Total Base Number (TBN), Salt, Insolubles and a Viscosity comparison test. \n\n\n\n " +
                             " 2. For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-easy-ship-combined-oil-test-kit)";
            }
            else
            {
                message = "1. Solution for viscosity of oil: Our highest seling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs." +
                            " The DIGI Combined Oil Test Kit from Unitor comes complete with tests for Water in Oil, Total Base Number (TBN), Salt, Insolubles and a Viscosity comparison test. \n\n\n\n " +
                            " 2. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-easy-ship-combined-oil-test-kit'>click here</a>";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Solution for viscosity of oil: Our highest seling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.OiltestViscosity);
        }
    }
}
