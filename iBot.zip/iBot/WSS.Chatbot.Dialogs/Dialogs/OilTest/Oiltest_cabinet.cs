﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.OilTest
{
    public class Oiltest_cabinet : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Oiltest_cabinet(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;

            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "1. Solution: Fuel oil test cabinet product nos: 607820. All equipment is contained in a robust, metal case that is fully lockable for safe and secure sample storage. " +
                                 "Certified by Germanischer Lloyd, providing everything you need to ensure that your fuel samples are compliant with IMO MARPOL 73/78 Annex VI regulations.\n\n\n\n " +
                            " 2. For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/the-fuel-oil-test-cabinet-1)";
            }
            else
            {
                message = "1. Solution: Fuel oil test cabinet product nos: 607820. All equipment is contained in a robust, metal case that is fully lockable for safe and secure sample storage. " +
                                 "Certified by Germanischer Lloyd, providing everything you need to ensure that your fuel samples are compliant with IMO MARPOL 73/78 Annex VI regulations.\n\n\n\n " +
                            " 2. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/the-fuel-oil-test-cabinet-1'>click here</a>";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = " Solution: Fuel oil test cabinet product nos: 607820. All equipment is contained in a robust, metal case that is fully lockable for safe and secure sample storage.Certified by Germanischer Lloyd, providing everything you need to ensure that your fuel samples are compliant with IMO MARPOL 73/78 Annex VI regulations";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.OiltestCabinet);
        }
    }
}
