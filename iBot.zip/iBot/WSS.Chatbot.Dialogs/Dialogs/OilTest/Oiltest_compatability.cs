﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.OilTest
{
    public class Oiltest_compatability : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Oiltest_compatability(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;

            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                 message = "1. Solution: Unitor™ Compatibility Test Kit Product number: 773153 is possibly the most useful and underrated tool available for testing fuel oils." +
                " This kit provides a quick and extremely useful tool for engineers faced with the necessity to mix or blend residual fuel oil.</br>" +
                " 2. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-compatibility-test-kit'>click here</a>";
            }
            else
            {
                message = "1. Solution: Unitor™ Compatibility Test Kit Product number: 773153 is possibly the most useful and underrated tool available for testing fuel oils." +
              " This kit provides a quick and extremely useful tool for engineers faced with the necessity to mix or blend residual fuel oil. \n\n " +
              " 2. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-compatibility-test-kit'>click here</a>";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Solution: Unitor™ Compatibility Test Kit Product number: 773153 is possibly the most useful and underrated tool available for testing fuel oils.This kit provides a quick and extremely useful tool for engineers faced with the necessity to mix or blend residual fuel oil";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.OiltestCompatability);
        }
    }
}