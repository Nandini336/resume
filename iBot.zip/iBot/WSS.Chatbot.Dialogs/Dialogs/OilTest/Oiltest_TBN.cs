﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.OilTest
{
    public class Oiltest_TBN : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Oiltest_TBN(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;

            string replyMsg1 = "";
            string replyMsg2 = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                replyMsg1 = $" 1. Solution: Wilhelmsen offers two test kits - Unitor™ Easy Ship Combined Oil Test Kit product nos: 773154 and Unitor™ TBN Test Kit product nos: 773150." +
               $" Both test kits gives results for crankcase and other lubricants in a very short time, normally about 5 minutes. Designed for testing lubricants with TBN up to 150. " +
               $" The results may be used as an in-service check of depleting TBN to the equilibrium value. \n\n\n\n" +
               $" 2. Our recommend is to use  Unitor™ Easy Ship Combined Oil Test Kit as this is a 5 in 1 yest kit incl TBN test offering more value. \n\n\n\n " +
               $" 3. For more product info on Unitor™ TBN Test Kit please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-tbn-test-kit)\n\n\n\n" +
               $" 4. For more product info on Unitor™ Easy Ship Combined Oil Test Kit please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-easy-ship-combined-oil-test-kit)\n\n\n\n" + "";

                replyMsg2 = "Or \n\n\n\n 1. Our highest selling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs. The DIGI Combined Oil Test Kit from Unitor comes complete with tests for Water in Oil, Total Base Number (TBN), Salt, Insolubles and a Viscosity comparison test." +
                    "\n\n 2. For more product info please [click here](http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-easy-ship-combined-oil-test-kit)";
            }
            else
            {
                replyMsg1 = " 1. Solution: Wilhelmsen offers two test kits - Unitor™ Easy Ship Combined Oil Test Kit product nos: 773154 and Unitor™ TBN Test Kit product nos: 773150." +
             " Both test kits gives results for crankcase and other lubricants in a very short time, normally about 5 minutes. Designed for testing lubricants with TBN up to 150. " +
             " The results may be used as an in-service check of depleting TBN to the equilibrium value. \n\n\n\n" +
             " 2. Our recommend is to use  Unitor™ Easy Ship Combined Oil Test Kit as this is a 5 in 1 yest kit incl TBN test offering more value. \n\n\n\n " +
             " 3. For more product info on Unitor™ TBN Test Kit please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-tbn-test-kit'>click here</a>\n\n\n\n" +
             " 4. For more product info on Unitor™ Easy Ship Combined Oil Test Kit please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-easy-ship-combined-oil-test-kit'>click here</a>\n\n" + "";

                replyMsg2 = "Or \n\n 1. Our highest selling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs. The DIGI Combined Oil Test Kit from Unitor comes complete with tests for Water in Oil, Total Base Number (TBN), Salt, Insolubles and a Viscosity comparison test." +
                    "\n\n 2. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-easy-ship-combined-oil-test-kit'>click here</a>";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Solution: Wilhelmsen offers two test kits - Unitor™ Easy Ship Combined Oil Test Kit product nos: 773154 and Unitor™ TBN Test Kit product nos: 773150.Both test kits gives results for crankcase and other lubricants in a very short time, normally about 5 minutes. Designed for testing lubricants with TBN up to 150.The results may be used as an in-service check of depleting TBN to the equilibrium value. Our recommend is to use  Unitor™ Easy Ship Combined Oil Test Kit as this is a 5 in 1 yest kit incl TBN test offering more value. Our highest selling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs. The DIGI Combined Oil Test Kit from Unitor comes complete with tests for Water in Oil, Total Base Number (TBN), Salt, Insolubles and a Viscosity comparison test.";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg1 + replyMsg2, ConstIntents.OiltestTbn);
        }
    }
}
