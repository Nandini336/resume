﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.OilTest
{
    public class Oiltest_Insolubles : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Oiltest_Insolubles(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;

            string replyMsg1 = "";
            string replyMsg2 = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
               replyMsg1 = "1. Solution: Unitor Insolubles Test Kit product nos: 625749 allows you to test your fuel and lubes for Insolubles contamination usually comes from combustion and mainly in the form of unburned hydrocarbon. " +
                             "High insolubles loading will cause laquering and other undesirable effects like stiction and increased wear.</br>" +
                               " 2. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/insolubles-test-1'>click here</a> </br> " + "";


                replyMsg2 = "Or </br> 1. Our highest selling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs. The DIGI Combined Oil Test Kit from Unitor comes complete with tests for Water in Oil, Total Base Number (TBN), Salt, Insolubles and a Viscosity comparison test." +
                              "</br> 2. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-easy-ship-combined-oil-test-kit'>click here</a>";
            }
            else
            {
                replyMsg1 = "1. Solution: Unitor Insolubles Test Kit product nos: 625749 allows you to test your fuel and lubes for Insolubles contamination usually comes from combustion and mainly in the form of unburned hydrocarbon. " +
                                            "High insolubles loading will cause laquering and other undesirable effects like stiction and increased wear.\n\n\n\n " +
                                            " 2. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/insolubles-test-1'>click here</a>\n\n" + "";


                replyMsg2 = "Or \n\n 1. Our highest selling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs. The DIGI Combined Oil Test Kit from Unitor comes complete with tests for Water in Oil, Total Base Number (TBN), Salt, Insolubles and a Viscosity comparison test." +
                             "\n\n 2. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-easy-ship-combined-oil-test-kit'>click here</a>";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Solution: Unitor Insolubles Test Kit product nos: 625749 allows you to test your fuel and lubes for Insolubles contamination usually comes from combustion and mainly in the form of unburned hydrocarbon.High insolubles loading will cause laquering and other undesirable effects like stiction and increased wear. Our highest selling Unitor™ Easy Ship Combined Oil Test Kit Product number: 773154 upplied ready for use, in durable ABS cases, Unitors multi-parameter DIGI Combined Oil Test Kit contains all of the necessary equipment and consumables for oil condition monitoring needs. The DIGI Combined Oil Test Kit from Unitor comes complete with tests for Water in Oil, Total Base Number TBN, Salt, Insolubles and a Viscosity comparison test";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, replyMsg1 + replyMsg2, ConstIntents.OiltestInsolubles);
        }
    }
}