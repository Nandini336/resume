﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.OilTest
{
    public class Oiltest_lubricity : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Oiltest_lubricity(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;

            string message = "";

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "1. At present WSS does not have a test kit to determine the lubricity value for your diesel or distillate fuel oil. </br> " +
                          "2. WSS recommendation is to use DieselPower Lubricity, Product number: 777195, to ensure proper lubricating properties of your diesel or distillate fuel.";

            }
            else
            {
                message = "1. At present WSS does not have a test kit to determine the lubricity value for your diesel or distillate fuel oil.\n\n" +
                         "2. WSS recommendation is to use DieselPower Lubricity, Product number: 777195, to ensure proper lubricating properties of your diesel or distillate fuel.";

            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "At present WSS does not have a test kit to determine the lubricity value for your diesel or distillate fuel oil.WSS recommendation is to use DieselPower Lubricity, Product number: 777195, to ensure proper lubricating properties of your diesel or distillate fuel";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.OiltestLubricity);
        }
    }
}
