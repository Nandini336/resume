﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.OilTest
{
    public class Oiltest_Ferrouswear : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Oiltest_Ferrouswear(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            await activity;
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                 message = "1. Solution: Unitor™ Ferrous Wear Meter Product number: 735754 detects metal particles in an oil samples taken from lubricated machinery. The Unitor Ferrous Wear Meter offers a simple, easy to use instrument that offers Wilhelmsen Ships Service Unitor quality, accuracy and reliability." +
                              "  This unit is ideal for testing and analysing oil samples on-site, on-board or in remote locations where full laboratory analysis is not possible. </br>" +
                             "2. Contaminants in fuel like phenol's have acidic content and can damage lubrication surfaces.</br>" +
                             "3. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-ferrous-wear-meter'>click here</a>";

            }
            else
            {
                 message = "1. Solution: Unitor™ Ferrous Wear Meter Product number: 735754 detects metal particles in an oil samples taken from lubricated machinery. The Unitor Ferrous Wear Meter offers a simple, easy to use instrument that offers Wilhelmsen Ships Service Unitor quality, accuracy and reliability." +
                              "  This unit is ideal for testing and analysing oil samples on-site, on-board or in remote locations where full laboratory analysis is not possible. \n\n" +
                             "2. Contaminants in fuel like phenol's have acidic content and can damage lubrication surfaces." +
                             "3. For more product info please <a href = 'http://wssproducts.wilhelmsen.com/marine-chemicals/test-kits-and-reagents/fuel-oil-test-kits/unitorx-ferrous-wear-meter'>click here</a>";


            }
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "Solution: Unitor™ Ferrous Wear Meter Product number: 735754 detects metal particles in an oil samples taken from lubricated machinery.The Unitor Ferrous Wear Meter offers a simple, easy to use instrument that offers Wilhelmsen Ships Service Unitor quality, accuracy and reliability.This unit is ideal for testing and analysing oil samples on-site, on-board or in remote locations where full laboratory analysis is not possible.Contaminants in fuel like phenol's have acidic content and can damage lubrication surfaces";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.OiltestFerrouswear);
        }
    }
}