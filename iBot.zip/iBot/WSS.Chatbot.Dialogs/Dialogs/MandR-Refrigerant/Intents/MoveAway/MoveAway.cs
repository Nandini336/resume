﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.MoveAway
{
    public class MoveAway : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "1. There are numerous replacements for R-404A available, most of them with a considerably lower GWP than 3922. However, those options are either not compatible with the existing system or will incur huge retrofitting cost. \n\n\n\n" +
                                   "2. In WSS, we recommend Unicool R - 407F as the drop -in replacement for R - 404A in existing system, after extensive testing of the available options. R407F does not required any form of technical upgrade or retrofitting works and able to maintain satisfactory performance.\n\n\n\n" +
                                   "3. You can learn more [click here](https://www.wilhelmsen.com/marine-products/refrigeration-solutions/mixing-it-up-with-407f/)";
            }
            else
            {
                message = "1. There are numerous replacements for R-404A available, most of them with a considerably lower GWP than 3922. However, those options are either not compatible with the existing system or will incur huge retrofitting cost. \n\n\n\n" +
                          "2. In WSS, we recommend Unicool R - 407F as the drop -in replacement for R - 404A in existing system, after extensive testing of the available options. R407F does not required any form of technical upgrade or retrofitting works and able to maintain satisfactory performance.\n\n\n\n" +
                          "3. You can learn more <a href = 'https://www.wilhelmsen.com/marine-products/refrigeration-solutions/mixing-it-up-with-407f/'> here</a> \n\n";

            }
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "There are numerous replacements for R-404A available, most of them with a considerably lower GWP than 3922. However, those options are either not compatible with the existing system or will incur huge retrofitting cost.In WSS, we recommend Unicool R - 407F as the drop -in replacement for R - 404A in existing system, after extensive testing of the available options. R407F does not required any form of technical upgrade or retrofitting works and able to maintain satisfactory performance.";

            return message;
        }
    }

    public class R404A_R507_Refrigerants_Move_Away_from_R404A_and_R507 : MoveAway
    {

    }
    public class R507_R404A_Refrigerants_Move_Away_from_R404A_and_R507 : MoveAway
    {

    }

    public class R404A_Refrigerants_Move_Away_from_R404A_and_R507 : MoveAway
    {

    }
    public class R507_Refrigerants_Move_Away_from_R404A_and_R507 : MoveAway
    {

    }

}