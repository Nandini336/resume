﻿
using WSS.ChatBot.Infrastructure;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.UVtracerKit 
{
    public class Refrigeration_UV_Tracer_Kit_220V : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //   message = "The UV Tracer Kit 220V is an effective tool for locating refrigerant leaks in inaccessible areas by circulating the tracer fluid and using UV-light. "+ 
            //              "If it is not available, you may get the UV tracer Kit 12V with product number 711523.It is a compact, portable kit with a 12V UV torch.";
            //}
            //else
            //{
            message = "The UV Tracer Kit 220V is an effective tool for locating refrigerant leaks in inaccessible areas by circulating the tracer fluid and using UV-light. " +
                          "If it is not available, you may get the UV tracer Kit 12V with product number 711523. It is a compact, portable kit with a 12V UV torch.";

            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "The UV Tracer Kit 220V is an effective tool for locating refrigerant leaks in inaccessible areas by circulating the tracer fluid and using UV-light. " +
                          "If it is not available, you may get the UV tracer Kit 12V with product number 711523. It is a compact, portable kit with a 12V UV torch.";


            return message;
        }
    }
}


