﻿using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.UVTracerkit
{
    public class Refrigerant_UV_Tracer_Kit_12V : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Refrigerant_UV_Tracer_Kit_12V(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "The UV Tracer Kit 12V is an effective tool for locating refrigerant leaks in inaccessible areas by circulating the tracer fluid and using UV - light.The kit consists of the following: \n\n" +
            //                "1) Protective Goggles\n\n" +
            //                "2) UV Torch with rechargeable battery\n\n" +
            //                "3) Charger\n\n" +
            //                "4) 4 x 250ml bottles of Tracer Fluid  ";
            //}
            //else
            //{
                message = "The UV Tracer Kit 12V is an effective tool for locating refrigerant leaks in inaccessible areas by circulating the tracer fluid and using UV - light.The kit consists of the following: \n\n " +
                            "1) Protective Goggles\n\n " +
                            "2) UV Torch with rechargeable battery\n\n " +
                            "3) Charger\n\n " +
                            "4) 4 x 250ml bottles of Tracer Fluid  ";
            //}
            var qandA = new QandA(this.ListCreateDbData);
            const string speakMessage = "The UV Tracer Kit 12 Volte is an effective tool for locating refrigerant leaks in inaccessible areas by circulating the tracer fluid and using UV - light. The kit consists of the following: \n\n " +
                            " Protective Goggles " +
                            " UV Torch with rechargeable battery " +
                            " Charger " +
                            " 4 by 250 ml bottles of Tracer Fluid  ";

            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Refrigerant_UV_Tracer_Kit_12V);
        }
    }
}
