﻿using WSS.ChatBot.Infrastructure;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.About
{
    class R407F_About : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //   message = "R-407F is a HFC blend that is suitable for use in low temperature and medium temperature applications with low GWP at 1824. It has been tested and widely used in marine applications."+
            //   "It is an ideal drop in replacement solution for existing R-404A system. There is no retrofit works required as they are fully compatible with each other.";
            //}
            //else
            //{
            message = "R-407F is a HFC blend that is suitable for use in low temperature and medium temperature applications with low GWP at 1824. It has been tested and widely used in marine applications."+
                       "It is an ideal drop in replacement solution for existing R-404A system. There is no retrofit works required as they are fully compatible with each other.";

            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "R-407F is a HFC blend that is suitable for use in low temperature and medium temperature applications with low GWP at 1824. It has been tested and widely used in marine applications." +
                       "It is an ideal drop in replacement solution for existing R-404A system. There is no retrofit works required as they are fully compatible with each other.";


            return message;
        }
    }
}


