﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    public class R22_Topup : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "R-22 is a pure refrigerant which should not be mix with other type of refrigerant. "+
                           "All R-22 shall be recovered from the whole system when you are retrofitting the system to other type of refrigerant.";

            }
            else
            {
                message = "R-22 is a pure refrigerant which should not be mix with other type of refrigerant. " +
                           "All R-22 shall be recovered from the whole system when you are retrofitting the system to other type of refrigerant.";

            }
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "R22 is a pure refrigerant which should not be mix with other type of refrigerant. " +
                           "All R22 shall be recovered from the whole system when you are retrofitting the system to other type of refrigerant.";

            return message;
        }
    }
}