﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.Topup
{
    public class R407F_R507_R407F_Topup : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{

            //    message = "To further reduce downtime and cost, you may top up the existing R-507 System with R407F to eliminate the need to recover R-507 and charge R-407F to the whole system.\n\n"+
            //               "However, please note that the option of mixing refrigerant is not applicable for ships carrying the US flag.";


            //}
            //else
            //{
                message = "To further reduce downtime and cost, you may top up the existing R-507 System with R407F to eliminate the need to recover R-507 and charge R-407F to the whole system.\n\n " +
                           "However, please note that the option of mixing refrigerant is not applicable for ships carrying the US flag.";

            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "To further reduce downtime and cost, you may top up the existing R507 System with R407F to eliminate the need to recover R507 and charge R407F to the whole system." +
                                    "However, please note that the option of mixing refrigerant is not applicable for ships carrying the US flag.";
            return message;
        }
    }
    public class R407F_R507_Topup : R407F_R507_R407F_Topup
    {

    }

    public class R507_R407F_Topup : R407F_R507_R407F_Topup
    {

    }
}