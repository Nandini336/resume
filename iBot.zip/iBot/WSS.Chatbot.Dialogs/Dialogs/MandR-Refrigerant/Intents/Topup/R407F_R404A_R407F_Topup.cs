﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.Topup
{
    public class R407F_R404A_R407F_Topup : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "To further reduce downtime and cost, you may top up the existing R-404A System with R407F to eliminate the need to recover R-404A and charge R-407F to the whole system.\n\n"+
            //              "The option of mixing R404A and R407F has been tested in both low temperature and high temperature applications with satisfactory results. To date, more than 100 ship owners have benefitted(zero downtime and zero retrofitting cost) from the option of mixing R-404A and R - 407F.";

            //}
            //else
            //{
               message = "To further reduce downtime and cost, you may top up the existing R-404A System with R407F to eliminate the need to recover R-404A and charge R-407F to the whole system.\n\n " +
                          "The option of mixing R404A and R407F has been tested in both low temperature and high temperature applications with satisfactory results. To date, more than 100 ship owners have benefitted(zero downtime and zero retrofitting cost) from the option of mixing R-404A and R - 407F.";

            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "To further reduce downtime and cost, you may top up the existing R404A System with R407F to eliminate the need to recover R404A and charge R407F to the whole system."+
                          "The option of mixing R404A and R407F has been tested in both low temperature and high temperature applications with satisfactory results. To date, more than 100 ship owners have benefitted (zero downtime and zero retrofitting cost) from the option of mixing R404A and R407F.";
                        return message;
        }
    }
    public class R407F_R404A_Topup : R407F_R404A_R407F_Topup
    {

    }

    public class R404A_R407F_Topup : R407F_R404A_R407F_Topup
    {

    }
}