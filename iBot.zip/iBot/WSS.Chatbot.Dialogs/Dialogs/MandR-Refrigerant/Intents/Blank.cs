﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    public class BlankPage : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            const string message = "Can you please check your query and try again !!";
            return message;
        }

        public string DoAlgorithmForSpeak()
        {
            const string message = "Can you please check your query and try again !!";
            return message;
        }
    }
}