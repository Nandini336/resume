﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.OtherIntents
{
    public class Continue : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            const string message = "Please be reassured that we will still have ample stock in the network for customers who want to continue using the R-404A and R-507 refrigerants despite the high price. We understand that some customers are willing to pay the higher price because their systems cannot be changed immediately, and that they may need some adjustment time before transiting to a new refrigerant option.  Customers who operate globally may want to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants.";

            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "Please be reassured that we will still have ample stock in the network for customers who want to continue using the R-404A and R-507 refrigerants despite the high price. We understand that some customers are willing to pay the higher price because their systems cannot be changed immediately, and that they may need some adjustment time before transiting to a new refrigerant option.  Customers who operate globally may want to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants.";

            return message;
        }
    }

    public class R404A_R507_Refrigerants_Continue_R404A_and_R507 : Continue
    {
    }

    public class R507_R404A_Refrigerants_Continue_R404A_and_R507 : Continue
    {
    }

    public class R507_Refrigerants_Continue_R404A_and_R507 : Continue
    {

    }
    public class R404A_Refrigerants_Continue_R404A_and_R507 : Continue
    {

    }

}
