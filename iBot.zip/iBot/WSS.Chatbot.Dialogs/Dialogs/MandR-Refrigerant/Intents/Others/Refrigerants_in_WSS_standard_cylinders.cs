﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.Others
{
    [Serializable]
    public class Refrigerants_in_WSS_standard_cylinders : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "Only Full refrigerant cylinders delivered less than 4 years ago and for which the seal is intact, the filling weight indicates a full cylinder and the cylinder is in a good condition, can be accepted for refund.</br>" +
            //            "Full refrigerant cylinders shall always be subject to a re-stocking fee or a reduced refund. Note that Refrigerants are subject to import restrictions in many places (note : return from a foreign flag vessel is considered as an import).</br> " +
            //            " Returns cannot be agreed with Customer unless Supply Coordination at the receiving place has authorized the return.</br>" +
            //            "Restocking fee is to be set to a minimum 15 % of the original sales price. Credit is always based on the original sales price at the moment the cylinder was delivered.</br>" +
            //            "Full refrigerant cylinders delivered more than 4 year ago can only be returned after approval of Product Management.</br>" +
            //            "Note: the recovery cylinder is sold to customer and it is not part of the cylinder exchange program.";
            //}
            //else
            //{
            message = "WSS have the following refrigerants available in our global network: \n\n\n\n" +
                " 1. R-22 (57kg & 12.5kg)\n\n\n\n " +
                " 2. R-134a 57kg & 12.5kg)\n\n\n\n " +
                " 3. R-404A (45kg & 9.5kg)\n\n\n\n " +
                " 4. R-407C (52kg & 11kg) \n\n\n\n " +
                " 5. R-407F (51kg & 11kg)\n\n\n\n " +
                " 6. R-410A 45kg & 9.5kg) \n\n\n\n " +
                " 7. R-417A 51kg & 11kg) \n\n\n\n " +
                " 8. R-422D (52kg)\n\n\n\n " +
                " 9. R-427A (53kg)\n\n\n\n " +
                " 10. R-507 (45kg & 9.5kg)  \n\n\n\n" +
                " For other refrigerants not in the list above, WSS will evaluate and supply on case by case basis.";


            //  }
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "WSS have the following refrigerants available in our global network: \n\n\n\n" +
                "  R-22 (57kg and 12.5kg) " +
                " R-134a 57kg and 12.5kg) " +
                " R-404A (45kg and 9.5kg) " +
                "  R-407C (52kg and 11kg) " +
                "  R-407F (51kg and 11kg)" +
                "  R-410A 45kg and 9.5kg) " +
                "  R-417A 51kg and 11kg) " +
                "  R-422D (52kg)" +
                " R-427A (53kg)" +
                "  R-507 (45kg and 9.5kg)" +
                " For other refrigerants not in the list above, WSS will evaluate and supply on case by case basis.";

            return message;
        }
    }
}