﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;


namespace WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.Others
{
    [Serializable]
    public class Refrigerant_What_is_Montreal_Protocol : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "Only Full refrigerant cylinders delivered less than 4 years ago and for which the seal is intact, the filling weight indicates a full cylinder and the cylinder is in a good condition, can be accepted for refund.</br>" +
            //            "Full refrigerant cylinders shall always be subject to a re-stocking fee or a reduced refund. Note that Refrigerants are subject to import restrictions in many places (note : return from a foreign flag vessel is considered as an import).</br> " +
            //            " Returns cannot be agreed with Customer unless Supply Coordination at the receiving place has authorized the return.</br>" +
            //            "Restocking fee is to be set to a minimum 15 % of the original sales price. Credit is always based on the original sales price at the moment the cylinder was delivered.</br>" +
            //            "Full refrigerant cylinders delivered more than 4 year ago can only be returned after approval of Product Management.</br>" +
            //            "Note: the recovery cylinder is sold to customer and it is not part of the cylinder exchange program.";
            //}
            //else
            //{
            message = "Montreal Protocol was first established in 1987 to phase out Ozone depleting substances e.g. CFCs and HCFCs (R-22). " +
                " The replacement refrigerants, HFCs have zero Ozone depletion but they are having medium to high global warming potential (GWP).  " +
                "The Kigali Amendment was agreed in October 2016 by the 197 Parties to the Montreal Protocol, in order to gradually reduce" +
                " global production and consumption of HFCs. Developed countries will go first, but developing countries also take on firm " +
                "reduction commitments in the medium term.";

            //  }
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "Montreal Protocol was first established in 1987 to phase out Ozone depleting substances e.g. CFCs and HCFCs (R-22). " +
                " The replacement refrigerants, HFCs have zero Ozone depletion but they are having medium to high global warming potential (GWP).  " +
                "The Kigali Amendment was agreed in October 2016 by the 197 Parties to the Montreal Protocol, in order to gradually reduce" +
                " global production and consumption of HFCs. Developed countries will go first, but developing countries also take on firm " +
                "reduction commitments in the medium term.";

            return message;
        }
    }
}
