﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;


namespace WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.Others
{
    [Serializable]
   public class Refrigerants_F_gas : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "Only Full refrigerant cylinders delivered less than 4 years ago and for which the seal is intact, the filling weight indicates a full cylinder and the cylinder is in a good condition, can be accepted for refund.</br>" +
            //            "Full refrigerant cylinders shall always be subject to a re-stocking fee or a reduced refund. Note that Refrigerants are subject to import restrictions in many places (note : return from a foreign flag vessel is considered as an import).</br> " +
            //            " Returns cannot be agreed with Customer unless Supply Coordination at the receiving place has authorized the return.</br>" +
            //            "Restocking fee is to be set to a minimum 15 % of the original sales price. Credit is always based on the original sales price at the moment the cylinder was delivered.</br>" +
            //            "Full refrigerant cylinders delivered more than 4 year ago can only be returned after approval of Product Management.</br>" +
            //            "Note: the recovery cylinder is sold to customer and it is not part of the cylinder exchange program.";
            //}
            //else
            //{
            message = "The F-gas regulation (EC 517/2014) on fluorinated greenhouse gases entered into force since 1st Jan 2015. \n " +
                          "" +
                        "1. It limits the amount of HFCs which can be placed on the market in the EU through the production and " +
                        "import quota on HFCs. The quota is calculated based on its ton of CO2 equivalent / GWP. It means that the higher " +
                        "the GWP for the refrigerant, the faster the quota is consumed. The quota reducing in steps with the first " +
                        "significant reduction in 2018(-37 %). So, since end of 2017, there have been significant shortage of high GWP " +
                        "HFCs supply because the manufacturers will prefer import HFCs with lower GWP. For example, given the same " +
                        "quota, the manufacturer can sell 2.15kg of R407F instead of 1kg of R404A. With that, the high GWP HFCs like " +
                        "R404A will be naturally squeezed out of the market by Suppliers. " +
                        "\n " +
                        "2. Service Ban on the use of HFCs with high GWP o HFCs with GWP > 2500 will be banned from 1st Jan 2020. \n" +
                        "Affected HFCs are as follows" +
                        "- R - 404A(GWP = 3922) " +
                        "- R - 507(GWP = 3985) " +
                        "- R - 422D(GWP = 2729) " +
                        "\n " +
                        "3. Refrigerant Leakage Control o Increased need for leak checks, leak detection systems and consumption record." +
                        "The F - gas Regulation will help to reduce emissions from industry to 70 per cent below 1990 levels by 2030. " +
                        "It aims to decrease the EUs emissions of fluorinated greenhouse gases (F-gases) by 70 million tonnes (mt) of " +
                        "CO2 equivalent, to 35 mt of CO2 equivalent by 2030. ";


            //  }
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "The F-gas regulation (EC 517/2014) on fluorinated greenhouse gases entered into force since 1st Jan 2015." +
                        " It limits the amount of HFCs which can be placed on the market in the EU through the production and " +
                        "import quota on HFCs. The quota is calculated based on its ton of CO2 equivalent / GWP.It means that the higher " +
                        "the GWP for the refrigerant, the faster the quota is consumed.o The quota reducing in steps with the first " +
                        "significant reduction in 2018(-37 %).So, since end of 2017, there have been significant shortage of high GWP " +
                        "HFCs supply because the manufacturers will prefer import HFCs with lower GWP.o For example, given the same " +
                        "quota, the manufacturer can sell 2.15kg of R407F instead of 1kg of R404A.With that, the high GWP HFCs like " +
                        "R404A will be naturally squeezed out of the market by Suppliers." +
                        "" +
                        " Service Ban on the use of HFCs with high GWP o HFCs with GWP > 2500 will be banned from 1st Jan 2020.o " +
                        "Affected HFCs are as follow  R - 404A(GWP = 3922)  R - 507(GWP = 3985)  R - 422D(GWP = 2729)" +
                        "" +
                        " Refrigerant Leakage Control o Increased need for leak checks, leak detection systems and consumption record." +
                        "The F - gas Regulation will help to reduce emissions from industry to 70 per cent below 1990 levels by 2030. " +
                        "It aims to decrease the EU's emissions of fluorinated greenhouse gases (F-gases) by 70 million tonnes (mt) of " +
                        "CO2 equivalent, to 35 mt of CO2 equivalent by 2030. ";

            return message;
        }
    }
}
