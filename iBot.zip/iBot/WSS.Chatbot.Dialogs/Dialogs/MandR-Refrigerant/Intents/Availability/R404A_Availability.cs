﻿using WSS.ChatBot.Infrastructure;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    public class R404A_Availability : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "1. We have R404A and R507 available worldwide. However, in EU, we may have limited supply of R404A and R507 in some ports. \n\n" +
            //                       "2. Customers who operate globally are encouraged to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants.";
            //}
            //else
            //{
                message = "1. We have R404A and R507 available worldwide. However, in EU, we may have limited supply of R404A and R507 in some ports. \n\n" +
                                 "2. Customers who operate globally are encouraged to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants.";

            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "We have R404A and R507 available worldwide. However, in EU, we may have limited supply of R404A and R507 in some ports.Customers who operate globally are encouraged to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants";

            return message;
        }
    }
}