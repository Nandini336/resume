﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    public class R422D_Availability : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message =  "1. We have R-422D available worldwide. However, in EU, we may have limited supply of R - 422D in some ports.\n\n" +
            //                "2. Customers who operate globally are encouraged to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants with high GWP.\n\n" +
            //                "3. Starting from 1st Jan 2020, it will be illegal to supply new R- 422D to ships with EU flag.";

            //}
            //else
            //{
                message = "1. We have R-422D available worldwide. However, in EU, we may have limited supply of R - 422D in some ports.\n\n " +
                            "2. Customers who operate globally are encouraged to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants with high GWP.\n\n " +
                            "3. Starting from 1st Jan 2020, it will be illegal to supply new R- 422D to ships with EU flag.";


            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "We have R422D available worldwide. However, in EU, we may have limited supply of R422D in some ports.\n\n " +
                            "Customers who operate globally are encouraged to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants with high GWP.\n\n " +
                            "Starting from 1st Jan 2020, it will be illegal to supply new R422D to ships with EU flag.";


            return message;
        }
    }
}