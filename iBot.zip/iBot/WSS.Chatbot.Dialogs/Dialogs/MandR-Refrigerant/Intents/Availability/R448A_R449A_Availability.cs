﻿using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Common.Helper;
using WSS.ChatBot.Infrastructure;

// This class is calling from the Root Dialog M&R method
namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    [Serializable]
    public class R448A_R449A_Availability : IPostData, IDialog<object>
    {

        public string Intent { get; set; }
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public R448A_R449A_Availability(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        public async Task DoPostData(List<CreateDbData> listCreateDbData, IDialogContext context, IAwaitable<IMessageActivity> activity, string intent, string botReplyMessage, string speakMessage)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.R448A_R449A_Availability;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.R448A_R449A_Availability);

            string replyMessage = string.Empty;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMessage = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.Replenish +
                $"2. " + ConversationalOptions.Replace +
                $"3. " + ConversationalOptions.Nooption;

            }
            else
            {
                replyMessage = ConversationalOptions.CommonMessage +
                 ConversationalOptions.Replenish +
                 ConversationalOptions.Replace +
                 ConversationalOptions.Nooption;
            }
            MailContent.ChatDataForUserandBot(context, replyMessage);

            CosmosDbData.BotResponse(replyMessage, context, ConstIntents.R448A_R449A_Availability, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, AfterMenuSelection,
                    replyMessage);
            }
            else
            {
                PromptDialog.Choice(context, this.AfterMenuSelection,
                 ConversationalOptions.R448A_R449A_AvailabilityModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }


        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;
            switch (message.ToString())
            {
                case ConversationalOptions.Replenish:
                case "1":

                    prompt = $"It is not in our standard product range.";
                    break;
                case ConversationalOptions.Replace:
                case "2":

                    prompt = $"Many low GWP alternatives have been developed to replace R-404A e.g. R448A, R449A, R449B, R442A. However, they are all not fully compatible with the existing R404A system. WSS recommend Unicool R-407F as the drop-in replacement for R-404A in existing system, after extensive testing of the available options.";
                    break;
                case ConversationalOptions.Nooption:
                case "3":

                    prompt = "Please contact the local WSS support team";
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.AfterMenuSelection, prompt);
                    return;
            }

            var chatbody = MailContent.ChatDataForUserandBot(context, prompt);

            CreateDbData.Instance.BotResponse = prompt;

            string botResponse2Message = prompt + " \n\n  " + WSS.ChatBot.Common.Common.HeaderMessage;

            string resolvePrompt = botResponse2Message + " \n\n Yes / No";

            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse2 = WSS.ChatBot.Common.Common.HeaderMessage;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = "";
            ListCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            MailContent.ChatDataForBot(context, WSS.ChatBot.Common.Common.HeaderMessage + " \n\n Yes / No");

            var selection =
                new EndOfConversation(MailContent, ListCreateDbData)
                { Intent = ConstIntents.R448A_R449A_Availability };

            MailContent.Intent = selection.Intent;
            context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var activity = await result;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                await botResponses.YesNoCard(context, botResponse2Message);
            }
            else
            {
                await context.PostAsync(resolvePrompt);
            }
        }

        Task IDialog<object>.StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }


        ////Must follow the same structure if there is only one level of conversation
        //private void AddBotResponseMessages(List<CreateDbData> listCreateDbData, IDialogContext context, string replyMessage)
        //    {

        //        CosmosDbData.CosmosBotResponse(replyMessage);

        //        CosmosDbData.CosmosSaveData(context: context, listCreateDbData: listCreateDbData); 

        //        BotResponses.Message1 = "It is not in our standard product range.";
        //        BotResponses.Message2 = "Many low GWP alternatives have been developed to replace R-404A e.g. R448A, R449A, R449B, R442A. However, they are all not fully compatible with the existing R404A system. WSS recommend Unicool R-407F as the drop-in replacement for R-404A in existing system, after extensive testing of the available options.";
        //        BotResponses.Message3 = "Please contact the local WSS support team";
        //        BotResponses.Message4 = "";
        //        BotResponses.Message5 = "";
        //        BotResponses.ElseMessage = "You have selected an invalid option. Please select valid option.";
        //        BotResponses.FinalMessage ="Was I able to help resolve your query?" + "\n\n Yes / No";

        //        BotResponses botResponses = new BotResponses(listCreateDbData);
        //        botResponses.MailContent = MailContent;
        //    }
    }
}