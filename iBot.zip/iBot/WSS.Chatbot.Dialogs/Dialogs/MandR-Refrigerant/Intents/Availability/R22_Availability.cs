﻿using WSS.ChatBot.Infrastructure;
using JSONUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    public class R22_Availability : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "Yes, WSS has R-22 in our standard cylinders (57kg and 12.5kg) available in our network. However, please note of the following: \n\n" +
            //                        "   1.  For ships with EU flag, it is illegal to top up R-22 (new or reclaim) to the system. So, WSS is unable to provide R-22 to ships with EU flag. \n\n" +
            //                        "   2.  For Non-article 5 countries under Montreal Protocol (e.g. US, Japan, Australia), R-22 will be banned after 1st Jan 2020.  So, R-22 will continue be available until 31st Dec 2019. </ br>" +
            //                        "   3. For Article 5 countries (e.g. China, India, Singapore), the current phase out date is 1st Jan 2030. WSS will continue supply R-22 until 31st Dec 2029. </ br>" +
            //                        "<b>Note :</b>  WSS can still supply R-22 from EU port to non-EU ships until 31st Dec 2019. R-22 will not be available from EU port after 2020 regardless of the country flags.";
            //}
            //else
            //{
                message = "Yes, WSS has R-22 in our standard cylinders (57kg and 12.5kg) available in our network. However, please note of the following: \n\n" +
                                  "   1. For ships with EU flag, it is illegal to top up R-22 (new or reclaim) to the system. So, WSS is unable to provide R-22 to ships with EU flag. \n\n" +
                                  "   2. For Non-article 5 countries under Montreal Protocol (e.g. US, Japan, Australia), R-22 will be banned after 1st Jan 2020.  So, R-22 will continue be available until 31st Dec 2019. \n\n" +
                                  "   3. For Article 5 countries (e.g. China, India, Singapore), the current phase out date is 1st Jan 2030. WSS will continue supply R-22 until 31st Dec 2029.\n\n" +
                                  " **Note :** WSS can still supply R-22 from EU port to non - EU ships until 31st Dec 2019.R - 22 will not be available from EU port after 2020 regardless of the country flags.";


           // }
            return message;


        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "Yes, WSS has R-22 in our standard cylinders 57kg and 12.5kg available in our network. However, please note of the following: For ships with EU flag, it is illegal to top up R-22 new or reclaim to the system. So, WSS is unable to provide R-22 to ships with EU flag.For Non-article 5 countries under Montreal Protocol example US, Japan, Australia, R-22 will be banned after 1st Jan 2020.  So, R-22 will continue be available until 31st Dec 2019.For Article 5 countries example China, India, Singapore, the current phase out date is 1st Jan 2030. WSS will continue supply R-22 until 31st Dec 2029.Note : WSS can still supply R-22 from EU port to non - EU ships until 31st Dec 2019.R - 22 will not be available from EU port after 2020 regardless of the country flags.";

            return message;
        }
    }
}