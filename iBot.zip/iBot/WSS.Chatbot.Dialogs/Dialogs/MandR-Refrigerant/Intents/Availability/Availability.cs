﻿using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;


namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.Availability
{
    [Serializable]
    public class Availability : IPostData
    {
        

        public async Task DoPostData(List<CreateDbData> listCreateDbData, IDialogContext context, IAwaitable<IMessageActivity> activity, string intent, string botReplyMessage,  string speakMessage)
        {
            var r448A_R449A_Availability = new R448A_R449A_Availability(listCreateDbData);
            await r448A_R449A_Availability.DoPostData(listCreateDbData, context, activity, intent, botReplyMessage, speakMessage);
        }

        
    }
}