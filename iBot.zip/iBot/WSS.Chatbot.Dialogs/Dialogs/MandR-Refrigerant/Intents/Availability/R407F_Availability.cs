﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    public class R407F_Availability : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "WSS has Unicool R-407F available globally in both large (56L) and small cylinders (12L).\n\n" +
            //                        "There is no restriction or phase out date for R - 407F worldwide.";
            //}
            //else
            //{
                message = "WSS has Unicool R-407F available globally in both large (56L) and small cylinders (12L).\n\n " +
                                   "There is no restriction or phase out date for R - 407F worldwide.";
            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "WSS has Unicool R407F available globally in both large which is 56 litres and small cylinders which is 12 litres." +
                                    "There is no restriction or phase out date for R407F worldwide.";
            return message;
        }
    }
}