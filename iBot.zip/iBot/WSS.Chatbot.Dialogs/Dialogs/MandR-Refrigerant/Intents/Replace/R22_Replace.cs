﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Threading.Tasks;
using ChatBot.Common;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.Replace
{
     

    [Serializable]
    public class R22: IPostData, IDialog<object>
    {
       
        public string Intent { get; set; }
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public R22(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        public async Task DoPostData(List<CreateDbData> listCreateDbData, IDialogContext context, IAwaitable<IMessageActivity> activity, string intent, string botReplyMessage, string speakMessage)
        {
            var msgactivity = await activity;

            CreateDbData.Instance.UserReply = msgactivity != null ? msgactivity.Text : ConstIntents.R22_Replace;
            CosmosDbData.UserReplyWithIntent(context, msgactivity.Text, ConstIntents.R22_Replace);

            string replyMessage = string.Empty;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMessage = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.EUFlag +
                $"2. " + ConversationalOptions.NonArticle +
                $"3. " + ConversationalOptions.Article;

            }
            else
            {
                replyMessage = ConversationalOptions.CommonMessage +
                 ConversationalOptions.EUFlag +
                 ConversationalOptions.NonArticle +
                 ConversationalOptions.Article;
            }
            MailContent.ChatDataForUserandBot(context, replyMessage);

            CosmosDbData.BotResponse(replyMessage, context, ConstIntents.R22_Replace, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, AfterMenuSelection,
                    replyMessage);
            }
            else
            {
                PromptDialog.Choice(context, this.AfterMenuSelection,
                 ConversationalOptions.R22_ReplaceModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;

            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;
            switch (message.ToString())
            {
                case ConversationalOptions.EUFlag:
                case "1":

                    prompt = $"Ship owner should engage contractor to retrofit the existing R-22 system to low GWP refrigerants e.g. R-407F or even upgrade the whole system with new refrigeration equipment.";
                    break;
                case ConversationalOptions.NonArticle:
                case "2":

                    prompt = $"R-22 will be banned after 1st Jan 2020. Ship owner should consider retrofit the system to low GWP refrigerants e.g. R-417A. It is the fastest and cheapest way to replace R-22 while maintaining sufficient performance.";
                    break;
                case ConversationalOptions.Article:
                case "3":

                    prompt = "R-22 will only be banned after 1st Jan 2030. Ship owner may want to continue with R-22 because it is still widely available at relatively low  price compare to its replacements.";
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.AfterMenuSelection, prompt);
                    return;
            }

            var chatbody = MailContent.ChatDataForUserandBot(context, prompt);

            CreateDbData.Instance.BotResponse = prompt;

            string botResponse2Message = prompt +  WSS.ChatBot.Common.Common.HeaderMessage;

            string resolvePrompt = botResponse2Message + " \n\n Yes / No";

            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse2 = WSS.ChatBot.Common.Common.HeaderMessage;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = "";
            ListCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            MailContent.ChatDataForBot(context, WSS.ChatBot.Common.Common.HeaderMessage + " \n\n Yes / No");

            var selection =
                new EndOfConversation(MailContent, ListCreateDbData)
                { Intent = ConstIntents.R22_Replace };

            MailContent.Intent = selection.Intent;
            context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var activity = await result;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                await botResponses.YesNoCard(context, botResponse2Message);
            }
            else
            {
                await context.PostAsync(resolvePrompt);
            }
        }

        Task IDialog<object>.StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }

    }
    
}
