﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.Replace
{
    public class R407F_R507_R407F_Replace : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "Many low GWP alternatives have been developed to replace R-507 e.g. R-448A, R-449A, R-449B, R-442A, R-454A, etc. However, the problems with newly development refrigerants on existing R-404A system are \n\n" +
            //                        "- Not widely used &Untested in marine application.\n\n" +
            //                        "-Require retrofitting / system upgrade.\n\n" +
            //                        "- Some of the refrigerants are flammable\n\n" +
            //                        "- Not easily available in all ports around the world.\n\n" + " \n\n\u200C <br/> \n\n\u200C <br/> " +
            //                        "In WSS, we recommend Unicool R - 407F as the drop -in replacement for R - 507 in existing system, after extensive testing of the available options.\n\n" +
            //                        "-	Firstly, R407F is fully complied with the current regulations. It has a much lower GWP at 1824 which is less than half of R507’s GWP.\n\n" +
            //                        "-	Secondly, there is no requirement for any technical upgrade or retrofitting works as R407F is fully compatible with existing R507 system.\n\n" +
            //                        "-	Thirdly, there will be no performance drop as R407F performs similarly to R404A in both low temperature and normal AC applications.\n\n";
            //}
            //else
            //{
                message = "Many low GWP alternatives have been developed to replace R-507 e.g. R-448A, R-449A, R-449B, R-442A, R-454A, etc. However, the problems with newly development refrigerants on existing R-404A system are \n\n" +
                                   "- Not widely used &Untested in marine application.\n\n" +
                                   "- Require retrofitting / system upgrade.\n\n" +
                                   "- Some of the refrigerants are flammable\n\n" +
                                   "- Not easily available in all ports around the world.\n\n" +
                                   "In WSS, we recommend Unicool R - 407F as the drop -in replacement for R - 507 in existing system, after extensive testing of the available options.\n\n" +
                                   "-	Firstly, R407F is fully complied with the current regulations. It has a much lower GWP at 1824 which is less than half of R507’s GWP.\n\n" +
                                   "-	Secondly, there is no requirement for any technical upgrade or retrofitting works as R407F is fully compatible with existing R507 system.\n\n" +
                                   "-	Thirdly, there will be no performance drop as R407F performs similarly to R404A in both low temperature and normal AC applications.\n\n";

            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "Many low GWP alternatives have been developed to replace R507 e.g. R448A, R449A, R449B, R442A, R454A, etc. However, the problems with newly development refrigerants on existing R507 system are" +
                                    "Not widely used & Untested in marine application. " +
                                    "Require retrofitting or system upgrade. " +
                                    " Some of the refrigerants are flammable. " +
                                    "Not easily available in all ports around the world. " +
                                    "In WSS, we recommend Unicool R407F as the drop in replacement for R507 in existing system, after extensive testing of the available options. " +
                                    "Firstly, R407F is fully complied with the current regulations. It has a much lower GWP at 1824 which is less than half of R507’s GWP. " +
                                    "Secondly, there is no requirement for any technical upgrade or retrofitting works as R407F is fully compatible with existing R507 system. " +
                                    "Thirdly, there will be no performance drop as R407F performs similarly to R404A in both low temperature and normal AC applications. ";
            ;
            return message;
        }
    }

    public class R507_R407F_Replace : R407F_R507_R407F_Replace
    {
    }

    public class R407F_R507_Replace : R407F_R507_R407F_Replace
    {
    }
}