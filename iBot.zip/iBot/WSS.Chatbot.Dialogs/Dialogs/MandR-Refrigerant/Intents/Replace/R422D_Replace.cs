﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    public class R422D_Replace : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "Currently, there is no drop-in replacement developed for R-422D. " +
                           "For ships carrying EU flag, we encourage the owners to start planning for system upgrade to refrigerants with lower GWPs.";

            }
            else
            {
                message = "Currently, there is no drop-in replacement developed for R-422D. " +
                           "For ships carrying EU flag, we encourage the owners to start planning for system upgrade to refrigerants with lower GWPs.";


            }
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "Currently, there is no drop-in replacement developed for R422D. " +
                                   "For ships carrying EU flag, we encourage the owners to start planning for system upgrade to refrigerants with lower GWPs.";


            return message;
        }
    }
}