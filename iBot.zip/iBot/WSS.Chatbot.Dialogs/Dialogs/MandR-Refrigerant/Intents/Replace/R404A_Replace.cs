﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.Replace
{
    public class R404A_Replace : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            const string message = "Many low GWP alternatives have been developed to replace R-404A e.g. R448A, R449A, R449B, R442A. " + "\n\n However, they are all not fully compatible with the existing R404A system. WSS recommends Unicool R-407F as the drop-in replacement for R-404A in existing system, after extensive testing of the available options.";
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "Many low GWP alternatives have been developed to replace R-404A example R448A, R449A, R449B, R442A.However, they are all not fully compatible with the existing R404A system. WSS recommends Unicool R-407F as the drop-in replacement for R-404A in existing system, after extensive testing of the available options.";
            return message;
        }
    }
}