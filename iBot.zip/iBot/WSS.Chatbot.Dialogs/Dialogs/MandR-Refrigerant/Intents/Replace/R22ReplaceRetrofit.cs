﻿using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.Replace
{
    [Serializable]
    public class R22ReplaceRetrofit : IPostData
    {
        
        public async Task DoPostData(List<CreateDbData> listCreateDbData, IDialogContext context, IAwaitable<IMessageActivity> activity, string intent, string botReplyMessage,  string speakMessage)
        {
            var r22 = new R22(listCreateDbData);
            await r22.DoPostData(listCreateDbData, context, activity, intent, botReplyMessage, speakMessage);
        }
    }
}