﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.Retrofit
{
    public class R407F_R507_R407F_Retrofit : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = " <b>R407F</b> is fully compatible with the exitsting R507 system with similar performance.";
            //}
            //else
            //{
                message = " **R407F** is fully compatible with the exitsting R507 system with similar performance.";
            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "R407F is fully compatible with the exitsting R507 system with similar performance.";
            return message;
        }
    }
    public class R507_R407F_Retrofit : R407F_R507_R407F_Retrofit
    {
    }
    public class R407F_R507_Retrofit : R407F_R507_R407F_Retrofit
    {
    }
    public class R507A_R407F_Retrofit : R407F_R507_R407F_Retrofit
    {
    }
    public class R407F_R507A_Retrofit : R407F_R507_R407F_Retrofit
    {
    }

}