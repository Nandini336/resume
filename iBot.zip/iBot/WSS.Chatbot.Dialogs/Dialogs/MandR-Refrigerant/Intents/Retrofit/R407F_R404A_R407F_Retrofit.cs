﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.Retrofit
{
    public class R407F_R404A_R407F_Retrofit : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = " <b>R407F</b> is fully compatible with R404A systems and the system does not need any retrofits.";
            //}
            //else
            //{
                message = " **R407F** is fully compatible with R404A systems and the system does not need any retrofits.";
            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = " R407F is fully compatible with R404A systems and the system does not need any retrofits.";
            return message;
        }
    }

    public class R404A_R407F_Retrofit : R407F_R404A_R407F_Retrofit
    {
    }

    public class R407F_R404A_Retrofit : R407F_R404A_R407F_Retrofit
    {
    }


}