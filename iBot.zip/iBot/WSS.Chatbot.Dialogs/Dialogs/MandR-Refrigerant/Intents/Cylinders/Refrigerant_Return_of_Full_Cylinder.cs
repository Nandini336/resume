﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace WSS.Chatbot.Dialogs.Dialogs.MandR_Refrigerant.Intents.Cylinders
{
    [Serializable]
    public class Refrigerant_Return_of_Full_Cylinder : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "Only Full refrigerant cylinders delivered less than 4 years ago and for which the seal is intact, the filling weight indicates a full cylinder and the cylinder is in a good condition, can be accepted for refund.</br>" +
            //            "Full refrigerant cylinders shall always be subject to a re-stocking fee or a reduced refund. Note that Refrigerants are subject to import restrictions in many places (note : return from a foreign flag vessel is considered as an import).</br> " +
            //            " Returns cannot be agreed with Customer unless Supply Coordination at the receiving place has authorized the return.</br>" +
            //            "Restocking fee is to be set to a minimum 15 % of the original sales price. Credit is always based on the original sales price at the moment the cylinder was delivered.</br>" +
            //            "Full refrigerant cylinders delivered more than 4 year ago can only be returned after approval of Product Management.</br>" +
            //            "Note: the recovery cylinder is sold to customer and it is not part of the cylinder exchange program.";
            //}
            //else
            //{
                message = "Only Full refrigerant cylinders delivered less than 4 years ago and for which the seal is intact, the filling weight indicates a full cylinder and the cylinder is in a good condition, can be accepted for refund.\n\n " +
                        "Full refrigerant cylinders shall always be subject to a re-stocking fee or a reduced refund. Note that Refrigerants are subject to import restrictions in many places (note : return from a foreign flag vessel is considered as an import).\n\n " +
                        " Returns cannot be agreed with Customer unless Supply Coordination at the receiving place has authorized the return.\n\n " +
                        "Restocking fee is to be set to a minimum 15 % of the original sales price. Credit is always based on the original sales price at the moment the cylinder was delivered.\n\n " +
                        "Full refrigerant cylinders delivered more than 4 year ago can only be returned after approval of Product Management.\n\n " +
                        "Note: the recovery cylinder is sold to customer and it is not part of the cylinder exchange program.";

          //  }
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "Only Full refrigerant cylinders delivered less than 4 years ago and for which the seal is intact, the filling weight indicates a full cylinder and the cylinder is in a good condition, can be accepted for refund." +
                        "Full refrigerant cylinders shall always be subject to a re-stocking fee or a reduced refund. Note that Refrigerants are subject to import restrictions in many places (note : return from a foreign flag vessel is considered as an import)" +
                        " Returns cannot be agreed with Customer unless Supply Coordination at the receiving place has authorized the return." +
                        "Restocking fee is to be set to a minimum 15 % of the original sales price. Credit is always based on the original sales price at the moment the cylinder was delivered." +
                        "Full refrigerant cylinders delivered more than 4 year ago can only be returned after approval of Product Management." +
                        "Note: the recovery cylinder is sold to customer and it is not part of the cylinder exchange program.";
            return message;
        }
    }
}
