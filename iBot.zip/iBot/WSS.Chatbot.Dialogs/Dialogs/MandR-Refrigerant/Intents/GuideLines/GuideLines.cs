﻿using WSS.ChatBot.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents.GuideLines
{
    public class GuideLines : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message ="";

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "Please refer to the guidelines on R-407F top up with R404A system. For more information please <a href = 'https://intranet.wilhelmsen.com/businesstools/wss/2market/marineproducts/refridgeration/Documents/Guidelines%20on%20R407F%20top%20up.pdf'>click here</a>";
            }
            else
            {

                message = "Please refer to the guidelines on R-407F top up with R404A system. For more information please <a href = 'https://intranet.wilhelmsen.com/businesstools/wss/2market/marineproducts/refridgeration/Documents/Guidelines%20on%20R407F%20top%20up.pdf'>click here</a>";
            }

            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "Please refer to the guidelines on R-407F top up with R404A system.";
            return message;
        }
    }

    public class R407F_GuideLines : GuideLines
    {

    }
    public class R407F_R404A_GuideLines : GuideLines
    {

    }

}