﻿using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    public class Price :  IMandRIntentStrategy
    {
        public string DoAlgorithm()
        { string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "The recent regulatory change in the refrigerant market has put tremendous volatility on refrigerant price and its availability. The price of Fluorspar, a key raw material for all refrigerants (e.g. R134a, R404A, R407C, R410A, R417A, etc) has hit a 4-year high this year.\n\n" +
            //                        "Strict enforcement of government regulations, license renewals, and plant shut down in China have also affected the supply of HFC components, which in turn impacted global refrigerant pricing.\n\n " +
            //                        "Furthermore, the phasedown of HFC and import quota system in EU have put further uncertainty to the refrigerant price. Currently, the refrigerant price is driven by these external factors and it varies from time to time. " +
            //                        "So, putting refrigerants price on request will allow customer to get a fair price offer based on the market situation. \n\n " +
            //                        "Please contact your local Wilhelmsen representative for the refrigerant price.";
            //}
            //else
            //{
                message = "The recent regulatory change in the refrigerant market has put tremendous volatility on refrigerant price and its availability. The price of Fluorspar, a key raw material for all refrigerants (e.g. R134a, R404A, R407C, R410A, R417A, etc) has hit a 4-year high this year.\n\n " +
                                    "Strict enforcement of government regulations, license renewals, and plant shut down in China have also affected the supply of HFC components, which in turn impacted global refrigerant pricing.\n\n " +
                                    "Furthermore, the phasedown of HFC and import quota system in EU have put further uncertainty to the refrigerant price. Currently, the refrigerant price is driven by these external factors and it varies from time to time. \n\n " +
                                    "So, putting refrigerants price on request will allow customer to get a fair price offer based on the market situation. \n\n " +
                                    "Please contact your local Wilhelmsen representative for the refrigerant price.";
            //}
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "The recent regulatory change in the refrigerant market has put tremendous volatility on refrigerant price and its availability. The price of Fluorspar, a key raw material for all refrigerants (like R134a, R404A, R407C, R410A, R417A, etc) has hit a 4-year high this year" +
                                    "Strict enforcement of government regulations, license renewals, and plant shut down in China have also affected the supply of HFC components, which in turn impacted global refrigerant pricing." +
                                    "Furthermore, the phasedown of HFC and import quota system in EU have put further uncertainty to the refrigerant price. Currently, the refrigerant price is driven by these external factors and it varies from time to time." +
                                    "So, putting refrigerants price on request will allow customer to get a fair price offer based on the market situation." +
                                    "Please contact your local Wilhelmsen representative for the refrigerant price.";
            return message;
        }
    }
    public class R404A_Price : Price
    {
    }

    public class R407F_Price : Price
    {
    }
}