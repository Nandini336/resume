﻿using WSS.ChatBot.Infrastructure;
using JSONUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace ChatBot.Dialogs.MandR_Refrigerant.Intents
{
    public class Refrigerant_GWP_and_Filling_Weight : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            //if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            //{
            //    message = "The refrigerant GWPs(IPCC 4AR) and filling weights in WSS refillable cylinders are as follow: \n\n"+
            //                "1)	R - 22 \n\n "+
            //                "- Filling weight = 57kg(56L cylinder) & 12.5kg(12.3L cylinder)\n\n" +
            //                "- GWP = 1810(Note: R - 22 has ODP of 0.05)\n\n" +
            //                "2)	R - 134a\n\n" +
            //                "- Filling weight = 57kg(56L cylinder) & 12.5kg(12.3L cylinder)\n\n" +
            //                "- GWP = 1430\n\n" +
            //                "3)	R - 404A\n\n" +
            //                "- Filling weight = 45kg(56L cylinder) & 9.5kg(12.3L cylinder)\n\n" +
            //                "- GWP = 3922\n\n" +
            //                "4)	R - 407C\n\n" +
            //                "- Filling weight = 52kg(56L cylinder) & 11kg(12.3L cylinder)\n\n" +
            //                "- GWP = 1774\n\n" +
            //                "5)	R - 407F\n\n" +
            //                "- Filling weight = 51kg(56L cylinder) & 11kg(12.3L cylinder)\n\n" +
            //                "- GWP = 1824\n\n" +
            //                "6)	R - 410A\n\n" +
            //                "- Filling weight = 45kg(56L cylinder) & 9.5kg(12.3L cylinder)\n\n" +
            //                "- GWP = 2090\n\n" +
            //                "7)	R - 417A\n\n" +
            //                "- Filling weight = 51kg(56L cylinder) & 11kg(12.3L cylinder)\n\n" +
            //                "- GWP = 2346\n\n" +
            //                "8)	R - 422D\n\n" +
            //                "- Filling weight = 52kg(56L cylinder)\n\n" +
            //                "- GWP = 2729\n\n" +
            //                "9)	R - 427A\n\n" +
            //                "- Filling weight = 53kg(56L cylinder)\n\n" +
            //                "- GWP = 2138\n\n" +
            //                "10)	R - 507\n\n" +
            //                "- Filling weight = 45kg(56L cylinder) & 9.5kg(12.3L cylinder)\n\n" +
            //                "- GWP = 3985";
            //}
            //else
            //{
                message = "The refrigerant GWPs(IPCC 4AR) and filling weights in WSS refillable cylinders are as follow: \n\n " +
                            "1)	R - 22 \n\n " +
                            "- Filling weight = 57kg(56L cylinder) & 12.5kg(12.3L cylinder)\n\n " +
                            "- GWP = 1810(Note: R - 22 has ODP of 0.05)\n\n " +
                            "2)	R - 134a\n\n " +
                            "- Filling weight = 57kg(56L cylinder) & 12.5kg(12.3L cylinder)\n\n " +
                            "- GWP = 1430\n\n " +
                            "3)	R - 404A\n\n " +
                            "- Filling weight = 45kg(56L cylinder) & 9.5kg(12.3L cylinder)\n\n " +
                            "- GWP = 3922\n\n " +
                            "4)	R - 407C\n\n " +
                            "- Filling weight = 52kg(56L cylinder) & 11kg(12.3L cylinder)\n\n " +
                            "- GWP = 1774\n\n " +
                            "5)	R - 407F\n\n " +
                            "- Filling weight = 51kg(56L cylinder) & 11kg(12.3L cylinder)\n\n " +
                            "- GWP = 1824\n\n " +
                            "6)	R - 410A\n\n " +
                            "- Filling weight = 45kg(56L cylinder) & 9.5kg(12.3L cylinder)\n\n " +
                            "- GWP = 2090\n\n " +
                            "7)	R - 417A\n\n " +
                            "- Filling weight = 51kg(56L cylinder) & 11kg(12.3L cylinder)\n\n " +
                            "- GWP = 2346\n\n " +
                            "8)	R - 422D\n\n " +
                            "- Filling weight = 52kg(56L cylinder)\n\n " +
                            "- GWP = 2729\n\n " +
                            "9)	R - 427A\n\n " +
                            "- Filling weight = 53kg(56L cylinder)\n\n " +
                            "- GWP = 2138\n\n " +
                            "10) R - 507\n\n " +
                            "- Filling weight = 45kg(56L cylinder) & 9.5kg(12.3L cylinder)\n\n " +
                            "- GWP = 3985";

            //}
            return message;


        }
        public string DoAlgorithmForSpeak()
        {
            const string message = "The refrigerant GWPs (IPCC 4AR) and filling weights in WSS refillable cylinders are as follow: " +
                            "R22 " +
                            " Filling weight = 57kg (56 litre cylinder) and 12.5kg (12.3 litre cylinder" +
                            " GWP = 1810 (Note: R22 has ODP of 0.05)" +
                            "R134a" +
                            "Filling weight = 57kg (56 litre cylinder) and 12.5kg (12.3 litre cylinder)" +
                            " GWP = 1430" +
                            "R404A" +
                            "Filling weight = 45kg (56 litre cylinder) and 9.5kg (12.3 litre cylinder)" +
                            " GWP = 3922" +
                            "R407C" +
                            "Filling weight = 52kg (56 litre cylinder) and 11kg (12.3 litre cylinder)" +
                            " GWP = 1774" +
                            "R407F" +
                            "Filling weight = 51kg (56 litre cylinder) and 11kg (12.3 litre cylinder)" +
                            " GWP = 1824" +
                            "R410A" +
                            " Filling weight = 45kg (56 litre cylinder) and 9.5kg (12.3 litre cylinder)" +
                            "GWP = 2090 " +
                            "R 417A" +
                            "Filling weight = 51kg (56 litre cylinder)  and 11kg (12.3 litre cylinder)" +
                            "GWP = 2346" +
                            "R422D" +
                            "Filling weight = 52kg (56 litre cylinder)" +
                            "GWP = 2729" +
                            "R427A" +
                            "Filling weight = 53kg (56 litre cylinder)" +
                            "GWP = 2138" +
                            "R507" +
                            "Filling weight = 45kg (56 litre cylinder) and 9.5kg (12.3 litre cylinder)" +
                            "GWP = 3985";

            return message;
        }
    }
}