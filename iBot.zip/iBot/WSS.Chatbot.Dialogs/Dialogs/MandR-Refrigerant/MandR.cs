﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;

/// <summary>
/// Class to display bot response for MandR app intents
/// </summary>

namespace ChatBot.Dialogs.Refrigerant
{
    [Serializable]
    public class MandR
    {

        public string Intent { get; set; }

        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        

        public MandR(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        private string _prompt = string.Empty;
        public string R404A_Availability(IDialogContext context)
        {
            //Prompt = "Due to global phase down of HFCs and HFC quota system, availability of refrigerant with high GWP such as R404A  (GWP = 3922) are very limited in some regions.Furthermore, R404A will be phased out in EU by 1st Jan 2020.";
            //Commented old answer
            // Prompt = "Due to global phase down of HFCs and HFC quota system, availability of refrigerant with high GWP such as R404A (GWP = 3922) are very limited in some regions. Furthermore, R404A will be phased out in EU by 1st Jan 2020";
            _prompt = "1. We have R404A and R507 available worldwide. However, in EU, we may have limited supply of R404A and R507 in some ports. \n\n"+
                     "2. Customers who operate globally are encouraged to start planning to pick up their refrigerants outside EU ports because the EU area is where the import quotas is implemented, and the ports in EU are already experiencing a shortage of refrigerants.";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;
        }

        public async Task ResolveQueryM_RMessage(IDialogContext context, IAwaitable<IMessageActivity> activity)
        {
            var selection = new EndOfConversation(MailContent, ListCreateDbData);
            var message = await activity;
            //Prompt = "Is your query resolved?" + "\n\n Yes / No";\
          //  Prompt = "Do you have a follow up question? " + "\n\n Yes / No";
            _prompt = "Was I able to help resolve your query?" + "\n\n Yes / No";
            //mailContent.ChatDataForBot(context, Prompt);

            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse2 = _prompt;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            ListCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            selection.Intent = Intent;

            await context.PostAsync(_prompt);

            var chatbody = MailContent.ChatDataForUserandBot(context, _prompt);

            MailContent.Intent = Intent;

            context.ConversationData.SetValue("mail", chatbody);

            MailContent.ChatDataForBot(context, _prompt);

            //await mailContent.SendingEmail(chatbody, context.Activity.From.Name);

            // PromptDialog.Text(context, selection.YesOrNoSelectionMandR, Prompt);
        }

        public string R404A_Price(IDialogContext context)
        {
            _prompt = "For price requests / quotations, we kindly ask you to contact your local Wilhelmsen representative whom will help you answer your request. Thank you";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;

        }
        public string R404A_Replace(IDialogContext context)
        {
            _prompt = "Many low GWP alternatives have been developed to replace R-404A e.g. R448A, R449A, R449B, R442A. " + "\n\n However, they are all not fully compatible with the existing R404A system. WSS recommends Unicool R-407F as the drop-in replacement for R-404A in existing system, after extensive testing of the available options.";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;

        }
        public string R404A_Supply(IDialogContext context)
        {
            return "Option"; //Dont implement 
        }

        //R407F           
        public string R407F_Replace_R404A(IDialogContext context)
        {
            _prompt = "Yes. **R407F** is fully compatible with the exitsting R404A system with similar performance.";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;

        }
        public string R407F_Replace_R507(IDialogContext context)
        {
            _prompt = "Yes. **R407F** is fully compatible with the exitsting R507 system with similar performance.";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;
        }
        public string R407F_Retrofit_R404A(IDialogContext context)
        {
            _prompt = "**R407F** is fully compatible with R404A systems and the system does not need any retrofits.";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;
        }
        public string R407F_Retrofit_R507(IDialogContext context)
        {
            _prompt = "**R407F** is fully compatible with the exitsting R507 system with similar performance.";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;
        }

        public string R407F_Topup_R404A(IDialogContext context)
        {
            _prompt = "The option of mixing R404A and **R407F** has been tested with satisfactory results. To date, more than 100 ship owners have benefted (zero downtime and zero retrofitting cost) from the option of mixing R-404A and R - 407F." +
                        "\n\n However, please note that the option of mixing refrigerant is not applicable for ships carrying the US flag.";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;

        }
        public string R407F_Topup_R507(IDialogContext context)
        {
            _prompt = "Yes, both R507 and **R407F** are fully compatible with similar performance." + "\n\n  However, if you current system is using flooded type evaporator, the option of mixing is not recommended.";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;


        }
        public string R407F_GuideLines(IDialogContext context)
        {
            _prompt = "Please contact your dedicated WSS Account Manager / Customer service for technical help and we will ensure that replacement is carried out smoothly ";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;

        }
        public string R407F_Availability(IDialogContext context)
        {
            _prompt = "WSS has Unicool R-407F available globally in both large (56L) and small cylinders (12L).";
            MailContent.ChatDataForUserandBot(context.Activity.From.Name, context.Activity.Recipient.Name, context.Activity.AsMessageActivity().Text, _prompt);
            return _prompt;

        }
        public async Task Options_R404A(IDialogContext context, IAwaitable<IMessageActivity> activity)
        {
            var msgactivity = await activity;

            CreateDbData.Instance.User = context.Activity.From.Name;
            CreateDbData.Instance.UserReply = msgactivity.Text;
            CreateDbData.Instance.UserRequestDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = ConstIntents.R404A_Supply; 

            var ReplyMsg = $"Please choose one of the below options : " +
                              "\n\n 1. Replenish " +
                              "\n\n 2. Replace " +
                              "\n\n 3. No option";
            MailContent.ChatDataForUserandBot(context, ReplyMsg);

            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse = ReplyMsg;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            ListCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            PromptDialog.Text(context, AfterMenuSelection, ReplyMsg);
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<object> result)
        {

            var message = await result;

            CreateDbData.Instance.User = context.Activity.From.Name;
            CreateDbData.Instance.UserReply = message.ToString();
            CreateDbData.Instance.UserRequestDatetime = DateTime.Now;

            var prompt = "";

            if ((message.ToString().Trim().Replace("&#160;", "").Trim() == "1") || (message.ToString().ToLower().Trim().Replace("&#160;", "").Trim().Contains("replenish")))
            {
                //Prompt = "I would recommend using Fuel Power Catalyst which contains fuel conditioning components. It also acts as a catalyst to help stabilise the fuel and improves combustion of fuel." + "\n\n The reason is :" + "\n\n Poor quality fuel can lead to deposit on your fuel system or engine componentscausing fouling. If combustion is irregular, it can cause flame impingement.";
                prompt = "It is not in our standard product range.";
            }
            else if (message.ToString().Trim().Replace("&#160;", "").Trim() == "2" || (message.ToString().ToLower().Trim().Replace("&#160;", "").Trim().Contains("replace")))
            {
                prompt = $"Many low GWP alternatives have been developed to replace R-404A e.g. R448A, R449A, R449B, R442A. However, they are all not fully compatible with the existing R404A system. WSS recommend Unicool R-407F as the drop-in replacement for R-404A in existing system, after extensive testing of the available options.";
            }
            else if (message.ToString().Trim().Replace("&#160;", "").Trim() == "3" || (message.ToString().ToLower().Trim().Replace("&#160;", "").Trim().Contains("no")))
            {
                prompt = "Please contact the local WSS support team";
            }
            else
            {
                prompt = "You have selected an invalid option. Please select valid option.";
                MailContent.ChatDataForUserandBot(context, prompt);

                CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
                CreateDbData.Instance.BotResponse = prompt;
                CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
                ListCreateDbData.Add(CreateDbData.Instance);
                context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

                PromptDialog.Text(context, this.AfterMenuSelection, prompt);
                return;
            }

            MailContent.ChatDataForUserandBot(context, prompt);
            CreateDbData.Instance.BotResponse = prompt;
            await context.PostAsync(prompt);
            prompt = "Was I able to help resolve your query?" + "\n\n Yes / No";

            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse2 = prompt;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            ListCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);

            MailContent.ChatDataForBot(context, prompt);
            EndOfConversation selection = new EndOfConversation(MailContent, ListCreateDbData);
            //PromptDialog.Text(context, selection.Confirmation, Prompt);
            await context.PostAsync(prompt);

        }


    }
}