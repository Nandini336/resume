﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_MessengerLine : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_MessengerLine(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "A messenger line is a light line attached to the end of a main mooring line and used to assist in heaving the mooring to the shore or to another ship. It is stored loose on deck.  \n\n" +
                              "Our equivalent to a messenger line is Timm Master 8 40mm 220m with product number 410051.";

            const string speakMessage = "A messenger line is a light line attached to the end of a main mooring line and used to assist in heaving the mooring to the shore or to another ship. It is stored loose on deck." +
                              "Our equivalent to a messenger line is Timm Master 8 40mm 220m with product number 410051.";
            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_MessengerLine);
        }
    }
}