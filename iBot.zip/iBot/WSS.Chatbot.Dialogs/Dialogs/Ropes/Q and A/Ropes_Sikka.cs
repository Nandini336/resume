﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_Sikka : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_Sikka(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "We recommend using Timm Master 8 68mm 220m with product number 410099 for vessels with DWT above 50 000 tonnes going to Sikka port in India. " +
                         "For other vessels going to same port, we recommend using Timm Master 8 52mm 220m with product number 410067.";

            const string speakMessage = "We recommend using Timm Master 8 68mm 220m with product number 410099 for vessels with DWT above 50 000 tonnes going to Sikka port in India." +
                "For other vessels going to same port, we recommend using Timm Master 8 52mm 220m with product number 410067.";
               
            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_Sikka);
        }
    }
}