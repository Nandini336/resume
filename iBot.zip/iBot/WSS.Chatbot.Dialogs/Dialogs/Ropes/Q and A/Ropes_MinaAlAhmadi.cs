﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_MinaAlAhmadi : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_MinaAlAhmadi(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Port of Mina Al Ahmadi is a tanker terminal in Kuwait, with mooring rope restrictions. This port only accepts vessels with HMPE ropes onboard, and they have a list of prioritized fiber suppliers." + " \n\n" +
                "The Acera fiber is not on this list, but Wilhelmsen Ships Service can request a factory statement from Timm Slovakia which is accepted by Mina Al Ahmadi for tanker vessels using Timm Acera ropes.";

            const string speakMessage = "Port of Mina Al Ahmadi is a tanker terminal in Kuwait, with mooring rope restrictions. This port only accepts vessels with HMPE ropes onboard, and they have a list of prioritized fiber suppliers." +
                "The Acera fiber is not on this list, but Wilhelmsen Ships Service can request a factory statement from Timm Slovakia which is accepted by Mina Al Ahmadi for tanker vessels using Timm Acera ropes.";
            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_MinaAlAhmadi);
        }
    }
}