﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_Cutter : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_Cutter(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "No, Wilhelmsen Ships Service do not offer rope cutter.";

            const string speakMessage = "No, Wilhelmsen Ships Service do not offer rope cutter.";
            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_Cutter);
        }
    }
}