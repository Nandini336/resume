﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_SmartRope : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_SmartRope(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "The Smart Ropes system is still in early development and helps eliminate the age-old problems associated with mooring ropes. " +
                "Constructed using the Timm Acera rope range, an embedded load sensor provides real time information on tension, along with logging usage and longevity, " +
                "relaying data to a base station located on deck. Giving an overview of rope tension via the Digital Mooring Assistant, Smart Ropes enables crew to moor their vessels safely, accurately and efficiently.";

            const string speakMessage = "The Smart Ropes system is still in early development and helps eliminate the age-old problems associated with mooring ropes." +
                            "Constructed using the Timm Acera rope range, an embedded load sensor provides real time information on tension, along with logging usage and longevity, relaying data to a base station located on deck. " +
                            "Giving an overview of rope tension via the Digital Mooring Assistant, Smart Ropes enables crew to moor their vessels safely, accurately and efficiently.";

            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_SmartRope);
        }
    }
}