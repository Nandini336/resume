﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_StockPoints : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_StockPoints(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Our current stock points for ropes are:  \n\n" +
                              "Houston, New York, Vancouver, Panama, Rotterdam, Algeciras, Durban, Dubai/ Fujairah, Piraeus, Istanbul, Singapore, Pusan, Shanghai & Fremantle.  \n\n\n\n" +
                              "Our 14 key ports means easy rope management, easy replacement, reduced logistics costs, and quick uptime if the unexpected happens.  \n\n\n\n" +
                              "Please be aware that the preferred minimum notice to Wilhelmsen Ships Service is 8 weeks for large orders over 10 coils, in order to guarantee the quantity on stock.Only when we have received a confirmed PO from the customer, and have provided the customer with our order confirmation, the customer is guaranteed delivery.";

            const string speakMessage = "Our current stock points for ropes are:" +
                              "Houston, New York, Vancouver, Panama, Rotterdam, Algeciras, Durban, Dubai/ Fujairah, Piraeus, Istanbul, Singapore, Pusan, Shanghai & Fremantle." +
                              "Our 14 key ports means easy rope management, easy replacement, reduced logistics costs, and quick uptime if the unexpected happens." +
                              "Please be aware that the preferred minimum notice to Wilhelmsen Ships Service is 8 weeks for large orders over 10 coils, in order to guarantee the quantity on stock.Only when we have received a confirmed PO from the customer, and have provided the customer with our order confirmation, the customer is guaranteed delivery.";

            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_StockPoints);
        }
    }
}