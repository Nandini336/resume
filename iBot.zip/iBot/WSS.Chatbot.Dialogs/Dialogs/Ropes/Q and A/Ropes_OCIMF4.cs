﻿    using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_OCIMF4 : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_OCIMF4(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                 message = "OCIMF Mooring Equipment Guideline 4 will be available in Q4 2018. This mooring guideline is primary used for tankers, but also used for other vessel types and terminals.  \n\n" +
                             "More information regarding the changes in MEG4 is available on the OCIMF MEG4 webpage,[click here](https://www.ocimf.org/meg4.aspx)";
            }
            else
            {
                 message = "OCIMF Mooring Equipment Guideline 4 will be available in Q4 2018. This mooring guideline is primary used for tankers, but also used for other vessel types and terminals.  \n\n" +
                             "More information regarding the changes in MEG4 is available on the OCIMF MEG4 webpage, <a href = 'https://www.ocimf.org/meg4.aspx'>click here.</a>";
            }
            const string speakMessage = "OCIMF Mooring Equipment Guideline 4 will be available in Q4 2018. This mooring guideline is primary used for tankers, but also used for other vessel types and terminals.";
            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_OCIMF4);
        }
    }
}