﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_Spliced : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_Spliced(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Timm certificates contain both the MBL Spliced and MBL Unspliced.  \n\n\n\n" +
                              "The ISO standard 2307:2010 is the standard used for testing and its mentioned that all ropes lose 10 % when any end connection is made on the linear rope. The ISO standard is in other words using the MBL Unspliced as standard.  \n\n" +
                              "Our certificates are based in ISO 2307:2010, also stating the MBL Spliced, which is 10 % lower than MBL Unspliced.  \n\n\n\n" +
                              "The new OCIMF Mooring Guideline Edition 4 will base the MBL on MBL Spliced, described as the Line Design Break Force, LDBF. When selecting lines, the LDBF of a mooring rope shall be 100 %–105 % of the ship design MBL. More information regarding this can be found on OCIMF MEG4 webpage.";

            const string speakMessage = "Timm certificates contain both the MBL Spliced and MBL Unspliced." +
                            "The ISO standard 2307:2010 is the standard used for testing and its mentioned that all ropes lose 10 % when any end connection is made on the linear rope. The ISO standard is in other words using the MBL Unspliced as standard." +
                            "Our certificates are based in ISO 2307:2010, also stating the MBL Spliced, which is 10 % lower than MBL Unspliced.The new OCIMF Mooring Guideline Edition 4 will base the MBL on MBL Spliced, described as the Line Design Break Force, LDBF. " +
                            "When selecting lines, the LDBF of a mooring rope shall be 100 %–105 % of the ship design MBL. More information regarding this can be found on OCIMF MEG4 webpage.";

            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_Spliced);
        }
    }
}