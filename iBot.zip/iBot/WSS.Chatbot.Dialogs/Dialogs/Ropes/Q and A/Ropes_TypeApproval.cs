﻿using ChatBot.Common;
using ChatBot.Dialogs.Fuel;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes
{
    public class Ropes_TypeApproval : IPostDataForFuel, IDialog<object>
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Ropes_TypeApproval(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = $"Our Timm and Acera ropes have the DNV GL Type Approval." +
                $" We are also able to produce other class certificates on request." +
                $" We have NK class certificate on Timm Master 8 produced in Korea.";


            const string speakMessage = "Our Timm and Acera ropes have the DNV GL Type Approval." +
                "We are also able to produce other class certificates on request." +
                "We have NK class certificate on Timm Master 8 produced in Korea.";

            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_TypeApproval);
        }

        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }

        //public static implicit operator Ropes_TypeApproval(Ropes_Conditions v)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
