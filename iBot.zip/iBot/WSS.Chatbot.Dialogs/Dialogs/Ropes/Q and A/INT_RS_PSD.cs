﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
   public class INT_RS_PSD : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public INT_RS_PSD(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "The non-standard product must be approved by the TSM. The regional PSD, responsible for the applicable site, will take care of the sourcing and purchase order to the supplier.";
            const string speakMessage = "The non-standard product must be approved by the TSM. The regional PSD, responsible for the applicable site, will take care of the sourcing and purchase order to the supplier.";
            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.INT_RS_PSD);
        }
    }
}