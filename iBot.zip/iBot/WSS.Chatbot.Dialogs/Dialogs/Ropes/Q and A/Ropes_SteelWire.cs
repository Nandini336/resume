﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_SteelWire : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_SteelWire(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "Wilhelmsen do not offer steel wire mooring ropes. If you are looking for certificates for previously sold steel wires from Timm, please contact your Wilhelmsen Customer Service.  \n\n\n\n"+ 
                              "Please contact us if you are looking for changing from steel wire mooring ropes to HMPE ropes. Changing the mooring wires to the HMPE ropes with 1 / 7th of the weight of steel wire but same strength, the vessel can save costs on maintenance such as greasing and fuel costs due to the time savings of mooring with light weight HMPE.";

            const string speakMessage = "Wilhelmsen do not offer steel wire mooring ropes. If you are looking for certificates for previously sold steel wires from Timm, please contact your Wilhelmsen Customer Service." +
                           "Please contact us if you are looking for changing from steel wire mooring ropes to HMPE ropes. Changing the mooring wires to the HMPE ropes with 1 / 7th of the weight of steel wire but same strength, the vessel can save costs on maintenance such as greasing and fuel costs due to the time savings of mooring with light weight HMPE.";
                          
            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_SteelWire);
        }
    }
}