﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{
    public class Ropes_Lines 
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_Lines(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "On a vessel, you will typically have spring lines working in two different directions, in addition to stern breast lines and head breast lines. In addition to this, some vessels have stern lines and head lines.  \n\n\n\n" + 
                             "These different positions are keeping the vessel steady, working in the directions of the different forces working on the vessel.";

            const string speakMessage = "On a vessel, you will typically have spring lines working in two different directions, in addition to stern breast lines and head breast lines. In addition to this, some vessels have stern lines and head lines." +
                             "These different positions are keeping the vessel steady, working in the directions of the different forces working on the vessel.";
            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_Lines);
        }
    }
}