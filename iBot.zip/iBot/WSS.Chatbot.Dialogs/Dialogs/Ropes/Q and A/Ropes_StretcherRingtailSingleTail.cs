﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using WSS.ChatBot.Common;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Q_and_A
{    
    public class Ropes_StretcherRingtailSingleTail :  IPostDataForFuel , IDialog<object>
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_StretcherRingtailSingleTail(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            await activity;

            var message = "A continuous loop or ringtail is a stretcher manufactured as a loop of rope, with one splice. Single tail is a stretcher with two spliced eyes, while the ringtail has only one splice, not having spliced eyes.  \n\n\n\n"+ 
                                    "Some vessels are using ringtails due to the need of having a requirement of high MBL, but the size of the single tail does not fit the mooring shackle or the equipment they are using for mooring.  \n\n\n\n" ;


            const string speakMessage = "A continuous loop or ringtail is a stretcher manufactured as a loop of rope, with one splice. Single tail is a stretcher with two spliced eyes, while the ringtail has only one splice, not having spliced eyes." +
                                    "Some vessels are using ringtails due to the need of having a requirement of high MBL, but the size of the single tail does not fit the mooring shackle or the equipment they are using for mooring.";
            var qandA = new QandA(this.ListCreateDbData);
            qandA.IsSpeak = true;
            qandA.speakMessage = speakMessage;
            await qandA.MainWithIntent(context, activity, message, ConstIntents.Ropes_StretcherRingtailSingleTail);
        }

        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    }
}