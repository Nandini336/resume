﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

/// <summary>
/// Class to implement level conversation for Ropes_Conventional
/// </summary>

namespace ChatBot.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_Conventional : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        public Ropes_Conventional(List<CreateDbData> _listcreateDbData)
        {
            this.MailContent = new MailContent(_listcreateDbData);
            this.ListCreateDbData = _listcreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.RopesConventional;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.RopesConventional);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = "What kind of vessel do you have?"+
                $"1. " + ConversationalOptions.Ropes_Conventional_1 +
                $"2. " + ConversationalOptions.Ropes_Conventional_2+
                $"3. " + ConversationalOptions.Ropes_Conventional_3+
                $"4. " + ConversationalOptions.Ropes_Conventional_4;

            }
            else
            {
                replyMsg = "What kind of vessel do you have?" +
                           ConversationalOptions.Ropes_Conventional_1 +
                           ConversationalOptions.Ropes_Conventional_2 +
                           ConversationalOptions.Ropes_Conventional_3 +
                           ConversationalOptions.Ropes_Conventional_4;
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);
            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.RopesConventional, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Ropes_ConventionalModelCollection(), "Please choose one of the below options: ", "Please choose a valid option from below !!", 3);
            }

        }
        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());
            string prompt;
            string prompt2;
            switch (message.ToString())
            {
                case ConversationalOptions.Ropes_Conventional_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommend [click here](https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true). Timm Master is a mixed composition rope of polyolefin and HT polyester, and can work in parallel with PP (polypropylene) ropes." +
                                 $" Please see our product catalog for more info and technical specifications.\n\n";


                        prompt2 = $"Are your vessel going to terminals with requirements for fiber mooring ropes?\n\n ";

                        PromptDialog.Choice(context, this.Level2_1, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"WSS recommend <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true'>Timm Master ropes</a>. Timm Master is a mixed composition rope of polyolefin and HT polyester, and can work in parallel with PP (polypropylene) ropes." +
                                 $" Please see our product catalog for more info and technical specifications. \n\n ";
                        MailContent.ChatDataForUserandBot(context, prompt);
                        prompt2 = $"Are your vessel going to terminals with requirements for fiber mooring ropes? \n\n  Yes / No";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2_1, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;
                case ConversationalOptions.Ropes_Conventional_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"We recommend [Timm Signal 12](https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-signal-12/timm-signal-12/?epieditmode=true) as conventional mooring ropes for cruise vessels." +
                              $" We do also offer blue HMPE ropes especially made for the cruise industry, in both [Acera Amundsen](https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen/acera-amundsen/?epieditmode=true)'>Acera Amundsen</a> " +
                              $"and [Acera Amundsen Lite](https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen-lite/acera-amundsen-lite/?epieditmode=true). Please see our product catalog for more info and technical specifications.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"We recommend <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-signal-12/timm-signal-12/?epieditmode=true'>Timm Signal 12</a> as conventional mooring ropes for cruise vessels." +
                              $" We do also offer blue HMPE ropes especially made for the cruise industry, in both <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen/acera-amundsen/?epieditmode=true'>Acera Amundsen</a> " +
                              $"and <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen-lite/acera-amundsen-lite/?epieditmode=true'>Acera Amundsen Lite</a>. Please see our product catalog for more info and technical specifications. \n\n ";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Conventional);
                    }
                    break;
                case ConversationalOptions.Ropes_Conventional_3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommend [Timm Master ropes](https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true)." +
                            $" Timm Master is a mixed composition rope of polyolefin and HT polyester, and can work in parallel with PP (polypropylene) ropes. Please see our product catalog for more info and technical specifications.\n\n";

                        prompt2 = $"Are your vessel looking for a better and easier mooring solution?\n\n ";

                        PromptDialog.Choice(context, this.Level2_3, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"WSS recommend <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true'>Timm Master ropes</a>." +
                            $" Timm Master is a mixed composition rope of polyolefin and HT polyester, and can work in parallel with PP (polypropylene) ropes. Please see our product catalog for more info and technical specifications. \n\n ";
                        MailContent.ChatDataForUserandBot(context, prompt);
                        prompt2 = $"Are your vessel looking for a better and easier mooring solution? \n\n  Yes / No";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2_3, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;
                case ConversationalOptions.Ropes_Conventional_4:
                case "4":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommend [Timm Master ropes](https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true). Timm Master is a mixed composition rope of polyolefin and HT polyester, and is made as according to OCIMF." +
                            $" For bigger tankers, we recommend using our [Acera HMPE ropes](https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen/acera-amundsen/?epieditmode=true)." +
                            $" Please see our product catalog for more info and technical specifications.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"WSS recommend <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true'>Timm Master ropes</a>. Timm Master is a mixed composition rope of polyolefin and HT polyester, and is made as according to OCIMF." +
                            $" For bigger tankers, we recommend using our <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen/acera-amundsen/?epieditmode=true'>Acera HMPE ropes</a>." +
                            $" Please see our product catalog for more info and technical specifications.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Conventional);
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }

        private async Task Level2_1(IDialogContext context, IAwaitable<object> result)
        {
            string prompt = string.Empty;
            var Options = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string chatbody = string.Empty;
            CosmosDbData.UserReplyWithoutIntent(context, Options.ToString());

            switch (Options.ToString())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"For the Panama Canal and Port Hedland, our Timm Master ropes will comply with the rope requirements. " +
                                $"For Vale terminals and Dalrymple Bay, we recommend our [Acera ropes](https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen/acera-amundsen/?epieditmode=true)." +
                                $" Please type in the specific terminal to see our recommended ropes.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"For the Panama Canal and Port Hedland, our Timm Master ropes will comply with the rope requirements. " +
                                $"For Vale terminals and Dalrymple Bay, we recommend our <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen/acera-amundsen/?epieditmode=true'>Acera ropes</a>." +
                                $" Please type in the specific terminal to see our recommended ropes.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventional);
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventional);

                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2_1, prompt);
                    return;
            }
        }

        private async Task Level2_3(IDialogContext context, IAwaitable<object> result)
        {
            string prompt = string.Empty;
            var Options = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string chatbody = string.Empty;
            CosmosDbData.UserReplyWithoutIntent(context, Options.ToString());

            switch (Options.ToString())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"For bigger vessels, we recommend looking at converting the ropes to HMPE ropes. " +
                            $"Our [Acera ropes](https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen/acera-amundsen/?epieditmode=true) have the same strength as steel wire, but 1/7th of the weight. " +
                            $"Please read more in our product catalog for more technical specifications.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"For bigger vessels, we recommend looking at converting the ropes to HMPE ropes. " +
                            $"Our <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/high-performance-mooring-rope/acera-amundsen/acera-amundsen/?epieditmode=true'>Acera ropes</a> have the same strength as steel wire, but 1/7th of the weight. " +
                            $"Please read more in our product catalog for more technical specifications.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventional);
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventional);

                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2_3, prompt);
                    return;
            }
        }
    }
}