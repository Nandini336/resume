﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;
using WSS.ChatBot.Common.Utils;
/// <summary>
/// Class to implement level conversation for Rope_Accessories
/// </summary>

namespace ChatBot.Dialogs.Ropes
{
    [Serializable]
    public class Rope_Accessories : IPostDataForFuel, IDialog<object>
    {
        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        // BotResponses botResponses = new BotResponses(ListCreateDbData);

        public Rope_Accessories(List<CreateDbData> _listcreateDbData)
        {
            this.MailContent = new MailContent(_listcreateDbData);
            this.ListCreateDbData = _listcreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.RopeAccessories;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.RopeAccessories);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage+
                $"1. " + ConversationalOptions.MooringShackle+
                $"2. " + ConversationalOptions.RopeProtection+
                $"3. " + ConversationalOptions.RopeRepairKit;

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.MooringShackle +
                           ConversationalOptions.RopeProtection +
                           ConversationalOptions.RopeRepairKit;
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);
            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.RopeAccessories, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Ropes_AccessoriesModelCollection(), "Please choose one of the below options: ", "Please choose a valid option from below !!", 3);
            }
        }
        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());
            string prompt;
            string prompt2;
            switch (message.ToString())
            {
                case ConversationalOptions.MooringShackle:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommends Timm Boss Link with or without roller as mooring connection for steel wire mooring rope and stretcher. Please read more in our product catalog.";
                        await botResponses.YesNoCard(context, prompt + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"WSS recommends Timm Boss Link with or without roller as mooring connection for steel wire mooring rope and stretcher. Please read more in our product catalog.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;

                case ConversationalOptions.RopeProtection:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "WSS recommend using Timm Chafe Guard as protection for all fiber ropes. Read more in our product catalog. \n\n";

                        prompt2 = $"Do you want to know more options about Timm Chafe Guard?\n\n ";

                        PromptDialog.Choice(context, this.Level2, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = $"WSS recommend using Timm Chafe Guard as protection for all fiber ropes. Read more in our product catalog.\n\n \n\n ";
                        MailContent.ChatDataForUserandBot(context, prompt);
                        prompt2 = $"Do you want to know more options about Timm Chafe Guard? \n\n  Yes / No";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

                case ConversationalOptions.RopeRepairKit:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "WSS recommends Timm Jacket Repair Kit to repair cover damages for ropes. This is an easy and quick repair without the use of a coating, and will increase the rope lifetime. Please read more in our product catalog." + "\n\n";

                        prompt2 = $"Do you want to know if this repair kit can be used to repair the cover of the eyes of the rope? \n\n ";

                        PromptDialog.Choice(context, this.Level2Option3Conversation, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = $"WSS recommend using Timm Chafe Guard as protection for all fiber ropes. Read more in our product catalog.\n\n \n\n ";
                        MailContent.ChatDataForUserandBot(context, prompt);
                        prompt2 = $"Do you want to know more options about Timm Chafe Guard? \n\n  Yes / No";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2Option3Conversation, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;

            }

        }

        private async Task Level2(IDialogContext context, IAwaitable<string> result)
        {
            var prompt = string.Empty;
            var options = await result;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString().ToLower().Trim().Replace("&#160;", "").Trim())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = ConversationalOptions.CommonMessage +
                           ConversationalOptions.RopeAccessories3_1 +
                           ConversationalOptions.RopeAccessories3_2 +
                           ConversationalOptions.RopeAccessories3_3 +
                           ConversationalOptions.RopeAccessories3_4;

                        PromptDialog.Choice(context, this.Level2Option2Conversation,
                        ConversationalOptions.Ropes_Accessories3ModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, "", context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = ConversationalOptions.CommonMessage +
                        $"1. " + ConversationalOptions.RopeAccessories3_1 +
                        $"2. " + ConversationalOptions.RopeAccessories3_2 +
                        $"3. " + ConversationalOptions.RopeAccessories3_3 +
                        $"4. " + ConversationalOptions.RopeAccessories3_4;

                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, "", context, ListCreateDbData);
                        PromptDialog.Text(context, Level2Option2Conversation, prompt, MailContent.ChatDataForUserandBot(context, prompt));
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;


                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2, prompt, MailContent.ChatDataForUserandBot(context, prompt));
                    return;
            }


        }

        private async Task Level2Option2Conversation(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            string prompt = string.Empty;
            string prompt2 = string.Empty;
            switch (message.ToString())
            {
                case ConversationalOptions.RopeAccessories3_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Timm Chafe Guard is made of HT Polyester. The heat resistant properties of PES will shield your rope from excessive frictional heat build-up." +
                    $" The Timm Chafe Guard is highly resistant to mineral acids, alkali, electrolytes, oxidising agents and remains stable in aqueous acids and non-polar solvents.";
                        await botResponses.YesNoCard(context, prompt + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Timm Chafe Guard is made of HT Polyester. The heat resistant properties of PES will shield your rope from excessive frictional heat build-up." +
                    $" The Timm Chafe Guard is highly resistant to mineral acids, alkali, electrolytes, oxidising agents and remains stable in aqueous acids and non-polar solvents.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;

                case ConversationalOptions.RopeAccessories3_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Timm Chafe Guard is manufactured at Timm Slovakia in Europe.";
                        await botResponses.YesNoCard(context, prompt + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Timm Chafe Guard is manufactured at Timm Slovakia in Europe.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;

                case ConversationalOptions.RopeAccessories3_3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Timm Chafe Guard is a vurable velcro lining with 1m fixing lines at each end and stiff eye grips." +
                    " It can be easily installed and can provide an instant defensive barrier against sharp surfaces and edges." +
                    " Poorly maintained fairleads and chocks can also severly harm the service life of your mooring lines. " +
                    "WSS suggest in such circumstances, applying a chafe guard to reduce destructive cutting."+"\n\n";

                        prompt2 = $"Do you want to know if Timm Chafe Guard can be used together with steel wire ropes?\n\n ";

                        PromptDialog.Choice(context, this.Level3Option3Conversation, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = "Timm Chafe Guard is a vurable velcro lining with 1m fixing lines at each end and stiff eye grips." +
                   " It can be easily installed and can provide an instant defensive barrier against sharp surfaces and edges." +
                   " Poorly maintained fairleads and chocks can also severly harm the service life of your mooring lines. " +
                   "WSS suggest in such circumstances, applying a chafe guard to reduce destructive cutting. \n\n";

                        MailContent.ChatDataForUserandBot(context, prompt);
                        prompt2 = $"Do you want to know if Timm Chafe Guard can be used together with steel wire ropes? \n\n Yes / No";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level3Option3Conversation, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

                case ConversationalOptions.RopeAccessories3_4:
                case "4":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Timm Chafe Guard is produced in a red eye-catching color. Timm Chafe Guard is also available in blue, especially made for the cruise industry.";
                        await botResponses.YesNoCard(context, prompt + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Timm Chafe Guard is produced in a red eye-catching color. Timm Chafe Guard is also available in blue, especially made for the cruise industry.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2Option2Conversation, prompt);
                    return;
            }
        }

        private async Task Level2Option3Conversation(IDialogContext context, IAwaitable<object> result)
        {
            string prompt = string.Empty;
            var Options = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string chatbody = string.Empty;
            CosmosDbData.UserReplyWithoutIntent(context, Options.ToString());

            switch (Options.ToString())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Timm Jacket Repair Kit can be used to repair both eyes and cover of a rope.";
                        await botResponses.YesNoCard(context, prompt + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Timm Jacket Repair Kit can be used to repair both eyes and cover of a rope.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);

                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2Option3Conversation, prompt);
                    return;
            }
        }

        private async Task Level3Option3Conversation(IDialogContext context, IAwaitable<object> result)
        {

            string prompt = string.Empty;
            var Options = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string chatbody = string.Empty;
            CosmosDbData.UserReplyWithoutIntent(context, Options.ToString());



            switch (Options.ToString())
            {

                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Timm Chafe Guard is a rope protection for fiber ropes and cannot be used together with steel wire ropes.";
                        await botResponses.YesNoCard(context, prompt + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Timm Chafe Guard is a rope protection for fiber ropes and cannot be used together with steel wire ropes.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context,WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);

                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level3Option3Conversation, prompt);
                    return;
            }

        }  


        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    }
}