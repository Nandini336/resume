﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using System.Configuration;
using WSS.ChatBot.Common.Helper;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Level_Conversations
{
    [Serializable]
    public class Ropes_MeasuringDiameter : IPostDataForFuel, IDialog<object>
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Ropes_MeasuringDiameter(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Ropes_MeasuringDiameter;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Ropes_MeasuringDiameter);

            string replyMsg = string.Empty;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                        $"1. " + ConversationalOptions.MeasuringDiameter1 +
                        $"2. " + ConversationalOptions.MeasuringDiameter2 +
                        $"3. " + ConversationalOptions.MeasuringDiameter3;
            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.MeasuringDiameter1 +
                           ConversationalOptions.MeasuringDiameter2 +
                           ConversationalOptions.MeasuringDiameter3;
            }


            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_MeasuringDiameter, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1, replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1, ConversationalOptions.MeasuringDiameterModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 3);
            }
        }


        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;

            switch (message.ToString())
            {
                case ConversationalOptions.MeasuringDiameter1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"To measure the diameter of a 8-strand rope, you need to take into consideration that there are 2 points where the diameter can be measured.: Maximum diameter on the thickest point, and minimum diameter on the thinnest point. Based on the construction of the rope, the measured diameter is much bigger than nominal diameter of the rope. The actual diameter of the rope is in most cases bigger than the nominal diameter." + "\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);


                        var Prompt1 = $"Do you want know about nominal diameter? \n\n ";

                        PromptDialog.Choice(context, this.Level2_1, ConversationalOptions.YesNo(), prompt + Prompt1, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt1 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"To measure the diameter of a 8-strand rope, you need to take into consideration that there are 2 points where the diameter can be measured.: Maximum diameter on the thickest point, and minimum diameter on the thinnest point. Based on the construction of the rope, the measured diameter is much bigger than nominal diameter of the rope. The actual diameter of the rope is in most cases bigger than the nominal diameter." + " \n\n  ";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt1 = $"Do you want know about nominal diameter? \n\n Yes / No";
                        MailContent.ChatDataForBot(context, Prompt1);

                        PromptDialog.Text(context, Level2_1, prompt + Prompt1);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt1, context, ListCreateDbData);
                        break;
                    }
                    break;

                case ConversationalOptions.MeasuringDiameter2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Braided 12-strand ropes, have slightly bigger measured diameter than nominal diameter. Coating of the yarns can increase measured diameter." + "\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);


                        var Prompt1 = $"Do you want know about nominal diameter? \n\n ";

                        PromptDialog.Choice(context, this.Level2_1, ConversationalOptions.YesNo(), prompt + Prompt1, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt1 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Braided 12-strand ropes, have slightly bigger measured diameter than nominal diameter. Coating of the yarns can increase measured diameter." + " \n\n " + " \n\n  ";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want know about nominal diameter? \n\n Yes / No";
                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level2_1, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;
                case ConversationalOptions.MeasuringDiameter3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"A cover will always increase the actual diameter of a rope. How much is dependent on the amount of used material in the cover, and how the cover is constructed. The calculation of breaking load for a rope is based on the nominal diameter of the core. We are therefore mentioning both the core and actual diameter for Acera daGama." + "\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);


                        var Prompt1 = $"Do you want know about nominal diameter? \n\n ";

                        PromptDialog.Choice(context, this.Level2_1, ConversationalOptions.YesNo(), prompt + Prompt1, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt1 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"A cover will always increase the actual diameter of a rope. How much is dependent on the amount of used material in the cover, and how the cover is constructed. The calculation of breaking load for a rope is based on the nominal diameter of the core. We are therefore mentioning both the core and actual diameter for Acera daGama." + " \n\n  ";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want know about nominal diameter? \n\n Yes / No";
                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level2_1, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }


        public async Task Level2_1(IDialogContext context, IAwaitable<object> result)
        {
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var options = await result;
            var prompt = string.Empty;
            var prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case ConversationalOptions.Yes:
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "Nominal sizes are s designation that has been determined by the measurement of another property. For ropes, diameter is considered a nominal property and is based upon the measurement of the linear density of the rope in accordance with some standard. Nominal diameter can be considered to be the theoretical uniform diameter of the rope, based on the amount of fiber used to construct the rope.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "Nominal sizes are s designation that has been determined by the measurement of another property. For ropes, diameter is considered a nominal property and is based upon the measurement of the linear density of the rope in accordance with some standard. Nominal diameter can be considered to be the theoretical uniform diameter of the rope, based on the amount of fiber used to construct the rope.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_MeasuringDiameter);
                        break;
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_MeasuringDiameter);
                        break;
                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse2(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2_1, prompt);
                    return;
            }
        }

      

        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    }
}