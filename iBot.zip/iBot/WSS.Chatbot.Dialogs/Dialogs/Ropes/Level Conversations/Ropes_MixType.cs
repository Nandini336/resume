﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

/// <summary>
/// Class to implement level conversation for Ropes_MixType
/// </summary>

namespace ChatBot.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_MixType : IPostDataForFuel, IDialog<object>
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Ropes_MixType(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Ropes_MixType;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Ropes_MixType);

            string replyMsg = string.Empty;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                        $"1. " + ConversationalOptions.RopeMixType1 +
                        $"2. " + ConversationalOptions.RopeMixType2 +
                        $"3. " + ConversationalOptions.RopeMixType3;
            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.RopeMixType1 +
                           ConversationalOptions.RopeMixType2 +
                           ConversationalOptions.RopeMixType3;
            }


            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_MixType, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1, replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1, ConversationalOptions.RopeMixTypeModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 3);
            }
        }

        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.RopeMixType1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Yes, as long as the ropes are of the same material in the same positions. The important part is that the minimum breaking load (MBL) of the rope should be lower than the safe working load (SWL) of the mooring fittings onboard the vessel.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Yes, as long as the ropes are of the same material in the same positions. The important part is that the minimum breaking load (MBL) of the rope should be lower than the safe working load (SWL) of the mooring fittings onboard the vessel." + " \n\n  ";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_MixType);
                        break;
                    }
                    break;
                case ConversationalOptions.RopeMixType2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Yes, as long as the minimum breaking load (MBL) of the rope is lower than the safe working " +
                            $"load (SWL) of the mooring fittings onboard the vessel. In addition, we recommend using the same " +
                            $"material on all lines. However, it is possible to mix the type of material of the ropes, as long " +
                            $"as the ropes working on the same positions are of the same material. For example all breast lines " +
                            $"working in pairs should be of the same material." +
                          "\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Are you looking for What will happen if two lines of different material work in the same mooring position? \n\n ";
                        PromptDialog.Choice(context, this.Level2, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = $"Yes, as long as the minimum breaking load (MBL) of the rope is lower than the safe working " +
                           $"load (SWL) of the mooring fittings onboard the vessel. In addition, we recommend using the same " +
                           $"material on all lines. However, it is possible to mix the type of material of the ropes, as long " +
                           $"as the ropes working on the same positions are of the same material. For example all breast lines " +
                           $"working in pairs should be of the same material." +
                           " \n\n  " + " \n\n  ";

                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Are you looking for What will happen if two lines of different material work in the same mooring position? \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level2, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;
                case ConversationalOptions.RopeMixType3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "This depends on the elongation. Polypropylene ropes and Polyolefin/HT Polyester ropes have the same elongation properties, and these ropes can be mixed with each other. Nylon ropes compared to mixed composition/polypropylene ropes have different elongation. If two lines of different elasticity work at the same position, the rope with the least elongation will take all the load, assumed that the winch break is set. This happens due to the ropes needing to stretch equally the same, hence the stiffer line will take more of the load. owever, it is possible to mix the type of material of the ropes, as long as the ropes working on the same positions are of the same material. For example all breast lines working in pairs should be of the same material.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "This depends on the elongation. Polypropylene ropes and Polyolefin/HT Polyester ropes have the same elongation properties, and these ropes can be mixed with each other. Nylon ropes compared to mixed composition/polypropylene ropes have different elongation. If two lines of different elasticity work at the same position, the rope with the least elongation will take all the load, assumed that the winch break is set. This happens due to the ropes needing to stretch equally the same, hence the stiffer line will take more of the load. owever, it is possible to mix the type of material of the ropes, as long as the ropes working on the same positions are of the same material. For example all breast lines working in pairs should be of the same material.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_MixType);
                        break;
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }


        public async Task Level2(IDialogContext context, IAwaitable<object> result)
        {
            var options = await result;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string prompt = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case ConstIntents.Yes:
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "If two lines of different elasticity work at the same position, the rope with the least elongation will take all the load, assumed that the winch break is set. This happens due to the ropes needing to stretch equally the same, hence the stiffer line will take more of the load." + "\n\n";

                        MailContent.ChatDataForUserandBot(context, prompt);


                        var Prompt2 = $"Are you looking to change your nylon ropes to Timm Master 8?";

                        PromptDialog.Choice(context, this.Level3, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = "If two lines of different elasticity work at the same position, the rope with the least elongation will take all the load, assumed that the winch break is set. This happens due to the ropes needing to stretch equally the same, hence the stiffer line will take more of the load." + " \n\n  ";


                        MailContent.ChatDataForUserandBot(context, prompt);


                        var Prompt2 = $"Are you looking to change your nylon ropes to Timm Master 8? \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level3, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;
                case ConstIntents.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_MixType);
                        break;
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2, prompt);
                    return;
            }
        }


        public async Task Level3(IDialogContext context, IAwaitable<object> result)
        {
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var options = await result;
            var prompt = string.Empty;
            var prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case ConversationalOptions.Yes:
                case "yup":
                case "yes":
                case "yo":
                case "yeah":
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "Yes, to switch from 100% Nylon ropes over to mixed composition Polyolefin/Polyester ropes is not a problem. However it is most important that they are not mixed with each other. The difference in elongation will cause problems. They need to work in pair and on same lines. Nylon has an up to 40% elongation (new rope) while the mix comp has 18-19% to break as new. Mixing these elongations will mean that the Timm Master 8 ropes are doing all the work.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "Yes, to switch from 100% Nylon ropes over to mixed composition Polyolefin/Polyester ropes is not a problem. However it is most important that they are not mixed with each other. The difference in elongation will cause problems. They need to work in pair and on same lines. Nylon has an up to 40% elongation (new rope) while the mix comp has 18-19% to break as new. Mixing these elongations will mean that the Timm Master 8 ropes are doing all the work.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_MixType);
                        break;
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_MixType);
                        break;
                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse2(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level3, prompt);
                    return;
            }
        }



        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    }
}