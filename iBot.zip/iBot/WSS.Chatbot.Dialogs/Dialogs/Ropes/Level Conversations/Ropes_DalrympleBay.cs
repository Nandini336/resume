﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

namespace ChatBot.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_DalrympleBay : IPostDataForFuel, IDialog<object>
    {
        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        public Ropes_DalrympleBay(List<CreateDbData> _listcreateDbData)
        {
            this.MailContent = new MailContent(_listcreateDbData);
            this.ListCreateDbData = _listcreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Ropes_DalrympleBay;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Ropes_DalrympleBay);

            string replyMsg = string.Empty;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                        $"1. " + ConversationalOptions.RopesDalrympleBay1 +
                        $"2. " + ConversationalOptions.RopesDalrympleBay2 +
                        $"3. " + ConversationalOptions.RopesDalrympleBay3 +
                        $"4. " + ConversationalOptions.RopesDalrympleBay4 +
                        $"5. " + ConversationalOptions.RopesDalrympleBay5;
            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.RopesDalrympleBay1 +
                           ConversationalOptions.RopesDalrympleBay2 +
                           ConversationalOptions.RopesDalrympleBay3 +
                           ConversationalOptions.RopesDalrympleBay4 +
                           ConversationalOptions.RopesDalrympleBay5;
            }


            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_DalrympleBay, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1, replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1, ConversationalOptions.Ropes_DalrympleBay(), "Choose from below options:", "Please choose a valid option from below !!", 3);
            }
        }

        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.RopesDalrympleBay1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "The suitable rope package for this vessel going to DBCT would be: \n\n" +
                         "Product number: 410423 \n\n" +
                         "ACERA DAGAMA 24MM / 30MM 220M 470KN(SPLICED) / 520KN(UNSPLICED) WHITE PES COVER 2X1,8M SUPEREYE \n\n" +
                         "Product number: 410127 \n\n" +
                         "TIMM MASTER 8 TAIL 56MM 11M 611KN(SPLICED) WHITE 2X2,0M EYE \n\n" +
                         "In addition to this we recommend the Timm Chafe Guard 30 - 38mm as rope protection for Acera daGama against steel surfaces such as roller fairleads or mooring chocks." +
                        "\n\n";

                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Are you looking for What will happen if two lines of different material work in the same mooring position? \n\n ";
                        PromptDialog.Choice(context, this.Level2Conversation, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = "The suitable rope package for this vessel going to DBCT would be:.  \n\n\n\n" +
                             "Product number 410423:  \n\n" +
                             "ACERA DAGAMA 24MM / 30MM 220M 470KN(SPLICED) / 520KN(UNSPLICED) WHITE PES COVER 2X1,8M SUPEREYE  \n\n\n\n" +
                             "Product number 410127:  \n\n" +
                             "TIMM MASTER 8 TAIL 56MM 11M 611KN(SPLICED) WHITE 2X2,0M EYE  \n\n\n\n" +
                             "In addition to this we recommend the Timm Chafe Guard 30 - 38mm as rope protection for Acera daGama against steel surfaces such as roller fairleads or mooring chocks." +
                              " \n\n  ";

                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Are you looking for What will happen if two lines of different material work in the same mooring position? \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level2Conversation, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;
                case ConversationalOptions.RopesDalrympleBay2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "The suitable rope package for this vessel going to DBCT would be: \n\n" +
                          "Product number : 410828 \n\n" +
                          "ACERA DAGAMA 26MM / 32MM 220M 540KN(SPLICED) / 600KN(UNSPLICED) WHITE PES COVER 2X1,8M SUPEREYE\n\n" +
                          "Product number: 410135 \n\n" +
                          "TIMM MASTER 8 TAIL 60MM 11M 699KN(SPLICED) WHITE 2X2,0M EYE \n\n" +
                          "In addition to this we recommend the Timm Chafe Guard 30 - 38mm as rope protection for Acera " +
                          "daGama against steel surfaces such as roller fairleads or mooring chocks." +
                       "\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know When will the HMPE mooring ropes be mandatory for all vessels calling DBCT?  ";
                        PromptDialog.Choice(context, this.Level2Conversation, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = "The suitable rope package for this vessel going to DBCT would be:  \n\n" +
                          "Product number 410828:  \n\n" +
                          "ACERA DAGAMA 26MM / 32MM 220M 540KN(SPLICED) / 600KN(UNSPLICED) WHITE PES COVER 2X1,8M SUPEREYE  \n\n" +
                          "Product number: 410135  \n\n" +
                          "TIMM MASTER 8 TAIL 60MM 11M 699KN(SPLICED) WHITE 2X2,0M EYE  \n\n\n\n" +
                          "In addition to this we recommend the Timm Chafe Guard 30 - 38mm as rope protection for Acera " +
                          "daGama against steel surfaces such as roller fairleads or mooring chocks." +
                        " \n\n  ";

                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know When will the HMPE mooring ropes be mandatory for all vessels calling DBCT?  \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level2Conversation, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;
                case ConversationalOptions.RopesDalrympleBay3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "The suitable rope package for this vessel going to DBCT would be: \n\n" +
                            "Product number : 410271 \n\n" +
                            "ACERA AMUNDSEN 28MM 220M 610KN(SPLICED) / 680KN(UNSPLICED) PLATINUM 2X1,8M SUPEREYE \n\n" +
                            "Product number : 410139 \n\n" +
                            "TIMM MASTER 8 TAIL 64MM 11M 794KN(SPLICED) WHITE 2X2,0M EYE \n\n" +
                            "In addition to this we recommend the Timm Chafe Guard 20 - 28mm as rope protection for Acera Amundsen against steel surfaces such as roller fairleads or mooring chocks. \n\n" +
                            "Please be aware that if the vessel has only single drum winches, we recommend to use Acera daGama " +
                            "rope with product number 410427, or adjusting the winches onboard the vessel to split drum winches." +
                        "\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know When will the HMPE mooring ropes be mandatory for all vessels calling DBCT?  ";
                        PromptDialog.Choice(context, this.Level2Conversation, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = "The suitable rope package for this vessel going to DBCT would be:  \n\n" +
                            "Product number 410271:  \n\n" +
                            "ACERA AMUNDSEN 28MM 220M 610KN(SPLICED) / 680KN(UNSPLICED) PLATINUM 2X1,8M SUPEREYE  \n\n" +
                            "Product number 410139:  \n\n" +
                            "TIMM MASTER 8 TAIL 64MM 11M 794KN(SPLICED) WHITE 2X2,0M EYE  \n\n\n\n" +
                            "In addition to this we recommend the Timm Chafe Guard 20 - 28mm as rope protection for Acera Amundsen against steel surfaces such as roller fairleads or mooring chocks.  \n\n\n\n" +
                            "Please be aware that if the vessel has only single drum winches, we recommend to use Acera daGama " +
                            "rope with product number 410427, or adjusting the winches onboard the vessel to split drum winches." +
                        " \n\n  ";

                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know When will the HMPE mooring ropes be mandatory for all vessels calling DBCT?  \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level2Conversation, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;

                case ConversationalOptions.RopesDalrympleBay4:
                case "4":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "The suitable rope package for this vessel going to DBCT would be:  \n\n" +
                             "Product number : 410275 \n\n" +
                             "ACERA AMUNDSEN 30MM 220M 690KN(SPLICED) / 770KN(UNSPLICED) PLATINUM 2X1,8M SUPEREYE \n\n" +
                             "Product number : 410147 \n\n" +
                             "TIMM MASTER 8 TAIL 68MM 11M 894KN(SPLICED) WHITE 2X2,0M EYE \n\n" +
                             "In addition to this we recommend the Timm Chafe Guard 30 - 38mm as rope protection for Acera Amundsen against steel surfaces such as roller fairleads or mooring chocks. \n\n" +
                             "Please be aware that if the vessel has only single drum winches, we recommend to use Acera daGama " +
                             "rope with product number 410431, or adjusting the winches onboard the vessel to split drum winches." +
                            "\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know When will the HMPE mooring ropes be mandatory for all vessels calling DBCT? ";
                        PromptDialog.Choice(context, this.Level2Conversation, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = "The suitable rope package for this vessel going to DBCT would be:  \n\n" +
                            "Product number 410275:  \n\n" +
                            "ACERA AMUNDSEN 30MM 220M 690KN(SPLICED) / 770KN(UNSPLICED) PLATINUM 2X1,8M SUPEREYE  \n\n" +
                            "Product number 410147:  \n\n" +
                            "TIMM MASTER 8 TAIL 68MM 11M 894KN(SPLICED) WHITE 2X2,0M EYE  \n\n\n\n" +
                            "In addition to this we recommend the Timm Chafe Guard 30 - 38mm as rope protection for Acera Amundsen against steel surfaces such as roller fairleads or mooring chocks.  \n\n\n\n" +
                            "Please be aware that if the vessel has only single drum winches, we recommend to use Acera daGama " +
                            "rope with product number 410431, or adjusting the winches onboard the vessel to split drum winches." +
                            " \n\n  ";

                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know When will the HMPE mooring ropes be mandatory for all vessels calling DBCT?  \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level2Conversation, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;

                case ConversationalOptions.RopesDalrympleBay5:
                case "5":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "The suitable rope package for this vessel going to DBCT would be: \n\n" +
                        "Product number : 410287 \n\n" +
                        "ACERA AMUNDSEN 34MM 220M 860KN(SPLICED) / 960KN(UNSPLICED) PLATINUM 2X1,8M SUPEREYE \n\n" +
                        "Product number : 410167 \n\n" +
                        "TIMM MASTER 8 TAIL 76MM 11M 1113KN(SPLICED) WHITE 2X2,0M EYE \n\n" +
                        "In addition to this we recommend the Timm Chafe Guard 30 - 38mm as rope protection for Acera Amundsen against steel surfaces such as roller fairleads or mooring chocks. \n\n" +
                        "Please be aware that if the vessel has only single drum winches, we recommend to use Acera daGama " +
                        "rope with product number 410790, or adjusting the winches onboard the vessel to split drum winches." +
                        "\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know When will the HMPE mooring ropes be mandatory for all vessels calling DBCT?  ";
                        PromptDialog.Choice(context, this.Level2Conversation, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = "The suitable rope package for this vessel going to DBCT would be:  \n\n" +
                         "Product number  410287:  \n\n" +
                         "ACERA AMUNDSEN 34MM 220M 860KN(SPLICED) / 960KN(UNSPLICED) PLATINUM 2X1,8M SUPEREYE  \n\n" +
                         "Product number 410167:  \n\n" +
                         "TIMM MASTER 8 TAIL 76MM 11M 1113KN(SPLICED) WHITE 2X2,0M EYE  \n\n\n\n" +
                         "In addition to this we recommend the Timm Chafe Guard 30 - 38mm as rope protection for Acera Amundsen against steel surfaces such as roller fairleads or mooring chocks.  \n\n\n\n" +
                         "Please be aware that if the vessel has only single drum winches, we recommend to use Acera daGama " +
                         "rope with product number 410790, or adjusting the winches onboard the vessel to split drum winches." +
                         " \n\n  ";


                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know When will the HMPE mooring ropes be mandatory for all vessels calling DBCT?  \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level2Conversation, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }

        private async Task Level2Conversation(IDialogContext context, IAwaitable<object> result)
        {
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var options = await result;
            var prompt = string.Empty;
            var prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case ConstIntents.Yes:
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "HMPE type lines will be mandatory for all vessels calling at DBCT from 01st Jan 2019(Synthetic tails + 125 % main line strength).  \n\n\n\n" +
                            "However, vessels without HMPE lines may experience delayed berthing prospects depending on weather conditions.Basis feedback presented by industry stakeholders during a two - year consultation process, DBCT P / L acknowledges that for some vessels, it may be up to five years before newly fitted lines are scheduled for replacement.  \n\n" +
                            "For this reason, until January 2022, DBCT P / L will consider nominations on a case by case basis.With that said, vessels that present at DBCT with lines that are of poor type / condition will be expected to replace current lines with HMPE Lines prior to the next calling at DBCT.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "HMPE type lines will be mandatory for all vessels calling at DBCT from 01st Jan 2019(Synthetic tails + 125 % main line strength).  \n\n\n\n" +
                             "However, vessels without HMPE lines may experience delayed berthing prospects depending on weather conditions.Basis feedback presented by industry stakeholders during a two - year consultation process, DBCT P / L acknowledges that for some vessels, it may be up to five years before newly fitted lines are scheduled for replacement.  \n\n" +
                             "For this reason, until January 2022, DBCT P / L will consider nominations on a case by case basis.With that said, vessels that present at DBCT with lines that are of poor type / condition will be expected to replace current lines with HMPE Lines prior to the next calling at DBCT.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_DalrympleBay);
                        break;
                    }
                    break;
                case ConstIntents.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_DalrympleBay);
                        break;
                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse2(prompt);

                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2Conversation, prompt);
                    return;
            }
        }

        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    }
}