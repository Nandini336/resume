﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using System.Configuration;
using WSS.ChatBot.Common.Helper;
using WSS.ChatBot.Infrastructure;

/// <summary>
/// Class to implement level conversation for Ropes_Main
/// </summary>

namespace ChatBot.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_Main : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

       
        public Ropes_Main(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Ropes_Main;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Ropes_Main);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                        $"1. " + ConversationalOptions.RopesMain1 +
                        $"2. " + ConversationalOptions.RopesMain2 +
                        $"3. " + ConversationalOptions.RopesMain3 +
                        $"4. " + ConversationalOptions.RopesMain4;
            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.RopesMain1 +
                           ConversationalOptions.RopesMain2 +
                           ConversationalOptions.RopesMain3 +
                           ConversationalOptions.RopesMain4;
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_Main, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Ropes_MainModelCollection(), "Choose from below options:", "Please choose a valid option from below !!",3);
            }
        }
        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());
           
            string prompt;

            switch (message.ToString())
            {
                case ConversationalOptions.RopesMain1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommend Timm Master. We have this rope both in 8 strand and 12 strand. Please read more in our product catalog.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"WSS recommend Timm Master. We have this rope both in 8 strand and 12 strand. Please read more in our product catalog.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Main);
                    }
                    break;

                case ConversationalOptions.RopesMain2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommend Timm Winchline. Please read more in our product catalog.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"WSS recommend Timm Winchline. Please read more in our product catalog.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Main);

                    }
                    break;
                case ConversationalOptions.RopesMain3: 
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                         prompt = "WSS recommend Acera ropes. Acera ropes are made both with and without cover. Please read more in our product portfolio.";
                     
                        var prompt2 = ConversationalOptions.CommonMessage +
                            ConversationalOptions.RopesMain3_Option1 +
                            ConversationalOptions.RopesMain3_Option2 +
                            ConversationalOptions.RopesMain3_Option3 +
                            ConversationalOptions.RopesMain3_Option4;
                      
                       
                        PromptDialog.Choice(context, this.Level2,
                                            ConversationalOptions.RopesMain3ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage, 
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = "WSS recommend Acera ropes. Acera ropes are made both with and without cover. Please read more in our product portfolio.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.RopesMain3_Option1 +
                                $"2. " + ConversationalOptions.RopesMain3_Option2 +
                                $"3. " + ConversationalOptions.RopesMain3_Option3 +
                                $"4. " + ConversationalOptions.RopesMain3_Option4;

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;
                case ConversationalOptions.RopesMain4:
                case "4":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommend Timm Master Tail. In addition to mixed composition ropes, we can also offer nylon tails especially made for vessels going to exposed berths. Please read more in our product portfolio.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "WSS recommend Timm Master Tail. In addition to mixed composition ropes, we can also offer nylon tails especially made for vessels going to exposed berths. Please read more in our product portfolio.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Main);
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }

        }
        public async Task Level2(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());
            
            switch (message.ToString())
            {
                case ConversationalOptions.RopesMain3_Option1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Our Acera ropes are made of genuine HMPE fiber.";
                        var prompt2 = ConversationalOptions.CommonMessage +
                           ConversationalOptions.RopesMain3_Option1_1 +
                           ConversationalOptions.RopesMain3_Option1_2;                           
                        PromptDialog.Choice(context, this.Level3,
                                            ConversationalOptions.RopesMain3_Option1ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 3);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Our Acera ropes are made of genuine HMPE fiber.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                    $"1. " + ConversationalOptions.RopesMain3_Option1_1 +
                                    $"2. " + ConversationalOptions.RopesMain3_Option1_2;
                        MailContent.ChatDataForBot(context, prompt2);

                        PromptDialog.Text(context, Level3, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;

                case ConversationalOptions.RopesMain3_Option2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"The cover of Acera daGama is made of Polyester, but we can also manufacture Acera daGama with HMPE cover on request.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"The cover of Acera daGama is made of Polyester, but we can also manufacture Acera daGama with HMPE cover on request.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Main);
                    }
                    break;

                case ConversationalOptions.RopesMain3_Option3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Yes, we can produce Acera Lite on request, which is a HMPE composite rope with higher diameter. Please contact WSS Customer Service for more information.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Yes, we can produce Acera Lite on request, which is a HMPE composite rope with higher diameter. Please contact WSS Customer Service for more information.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Main);
                    }
                    break;
                case ConversationalOptions.RopesMain3_Option4:
                case "4":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Yes, our Acera ropes are made as according to ISO and with type approval from DNV GL, and recommended by OCIMF Mooring Guideline.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Yes, our Acera ropes are made as according to ISO and with type approval from DNV GL, and recommended by OCIMF Mooring Guideline.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Main);
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2, prompt);
                    return;
            }
        }
        public async Task Level3(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            
            switch (message.ToString())
            {
                case ConversationalOptions.RopesMain3_Option1_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"We produce our Acera ropes at our factory Timm Slovakia in Europe. We have our own R&D department and Quality department at the same factory, always doing improvements and new developments for Timm Ropes.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"We produce our Acera ropes at our factory Timm Slovakia in Europe. We have our own R&D department and Quality department at the same factory, always doing improvements and new developments for Timm Ropes.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Main);
                    }

                    break;
                case ConversationalOptions.RopesMain3_Option1_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Acera ropes are produced according to ISO 9554:2010 and tested according to ISO 2307:2010. Minimum Breaking Load (MBL) is according to ISO 10325:2009 and verified by DNV GL. All our ropes are Type Approved by DNV GL, and each rope is delivered with a unique certificate number and certificate.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Acera ropes are produced according to ISO 9554:2010 and tested according to ISO 2307:2010. Minimum Breaking Load (MBL) is according to ISO 10325:2009 and verified by DNV GL. All our ropes are Type Approved by DNV GL, and each rope is delivered with a unique certificate number and certificate.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Main);
                    }

                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level3, prompt);
                    return;
            }
        }
    }
}