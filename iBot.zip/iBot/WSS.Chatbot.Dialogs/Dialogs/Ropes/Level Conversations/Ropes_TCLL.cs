﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Level_Conversations
{
    [Serializable]
    public class Ropes_TCLL : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_TCLL(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {

            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Ropes_TCLL;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Ropes_TCLL);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.Ropes_TCLL_1 +
                $"2. " + ConversationalOptions.Ropes_TCLL_2;                

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.Ropes_TCLL_1 +
                           ConversationalOptions.Ropes_TCLL_2;
                           
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);
            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_TCLL, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Ropes_TCLLModelCollection(), "Please choose one of the below options: ", "Please choose a valid option from below !!", 3);
            }
        }


        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            string prompt2;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.Ropes_TCLL_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "A thousand cycle load limit test is a cyclical loading of tested rope using the following routine: 1000 cycles with 50% of BL 1000 cycles with 60% of BL 1000 cycles with 70% of BL 2000 cycles with 80% of BL A rope will normally break during 2000 cycles with 80% of breaking load." + "\n\n";

                        prompt2 = $"Do you want know whether TCLL testing is necessary? \n\n ";

                        PromptDialog.Choice(context, this.Level2_1, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"A thousand cycle load limit test is a cyclical loading of tested rope using the following routine: 1000 cycles with 50% of BL 1000 cycles with 60% of BL 1000 cycles with 70% of BL 2000 cycles with 80% of BL A rope will normally break during 2000 cycles with 80% of breaking load.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);                  

                     prompt2 = $"Do you want know whether TCLL testing is necessary? \n\n Yes / No";
                    MailContent.ChatDataForBot(context, prompt2);
                    PromptDialog.Text(context, Level2_1, prompt2);
                    CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

                case ConversationalOptions.Ropes_TCLL_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"The TCLL testing procedure starts with a test load of 50% of BL. As stated by OCIMF, this is the same value as the safe working load for ropes, also commonly expressed as working load limit WLL. When testing beyond 50% of BL, the load increases, conducting rope testing with constant overload. Such conditions would never be encouraged in real life, where a rope should be changed after being overloaded just once."+ "\n\n";

                        prompt2 = $"Are you looking for possibility to get at TCLL value of 100%? \n\n ";

                        PromptDialog.Choice(context, this.Level2_2, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                    }
                    else
                    {

                        prompt = $"The TCLL testing procedure starts with a test load of 50% of BL. As stated by OCIMF, this is the same value as the safe working load for ropes, also commonly expressed as working load limit WLL. When testing beyond 50% of BL, the load increases, conducting rope testing with constant overload. Such conditions would never be encouraged in real life, where a rope should be changed after being overloaded just once.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Are you looking for possibility to get at TCLL value of 100%? \n\n Yes / No";
                        MailContent.ChatDataForBot(context, Prompt2);
                        PromptDialog.Text(context, Level2_2, Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }

        public async Task Level2_1(IDialogContext context, IAwaitable<object> result)
        {
            var options = await result;
            string prompt = string.Empty;
            string prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "TCLL testing is sometimes used when comparing different ropes and predicting the lifetime of ropes. The method is controversial in the rope industry, often giving poor data to analyse. There are other methods for this kind of testing, which are more time and cost efficient. Wilhelmsen Ships Service use a cost efficient testing method which is verified by class societies. The TCLL testing method are often related to calculation of strength of the rope splice, and not the rope strength itself." + "\n\n";

                        prompt2 = $"Do you want to know why do some rope manufacturers use the TCLL method? \n\n ";

                        PromptDialog.Choice(context, this.Level3, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "TCLL testing is sometimes used when comparing different ropes and predicting the lifetime of ropes. The method is controversial in the rope industry, often giving poor data to analyse. There are other methods for this kind of testing, which are more time and cost efficient. Wilhelmsen Ships Service use a cost efficient testing method which is verified by class societies. The TCLL testing method are often related to calculation of strength of the rope splice, and not the rope strength itself.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        prompt2 = $"Do you want to know why do some rope manufacturers use the TCLL method? \n\n Yes / No";
                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level3, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_TCLL);
                    }
                    break;

                default:                  

                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2_1, prompt, MailContent.ChatDataForUserandBot(context, prompt));
                    return;
            }
        }
        
        public async Task Level2_2(IDialogContext context, IAwaitable<object> result)
        {
            var options = await result;
            string prompt = string.Empty;
            string prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Some rope manufacturers provide products with a TCLL value of 100%. A result of this value will give a product with eternal lifetime, giving an invalid product that do not exist. A value of 100% of TCLL is not an actual measurement of the TCLL result and should not be a decision value. There are no documented findings where the TCLL method gives any prediction of rope lifetime.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "Some rope manufacturers provide products with a TCLL value of 100%. A result of this value will give a product with eternal lifetime, giving an invalid product that do not exist. A value of 100% of TCLL is not an actual measurement of the TCLL result and should not be a decision value. There are no documented findings where the TCLL method gives any prediction of rope lifetime.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_TCLL);
                    }
                    break;
                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_TCLL);
                    }
                    break;

                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2_2, prompt, MailContent.ChatDataForUserandBot(context, prompt));
                    return;
            }
        }

        public async Task Level3(IDialogContext context, IAwaitable<object> result)
        {
            var options = await result;
            string prompt = string.Empty;
            string prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Operating in a highly competitive segment, one way of eliminating competition is to offer this test method as a state of the art testing method in the market. For the majority of the rope manufacturers, this method is not possible to reproduce, when ensuring an efficient production with a high level of operational availability for customers.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "Operating in a highly competitive segment, one way of eliminating competition is to offer this test method as a state of the art testing method in the market. For the majority of the rope manufacturers, this method is not possible to reproduce, when ensuring an efficient production with a high level of operational availability for customers.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_TCLL);
                    }
                    break;
                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_TCLL);
                    }
                    break;

                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse2(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level3, prompt);
                    return;
            }
        }

    }
}