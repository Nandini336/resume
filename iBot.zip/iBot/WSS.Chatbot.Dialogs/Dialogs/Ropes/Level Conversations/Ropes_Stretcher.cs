﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using System.Configuration;
using WSS.ChatBot.Common.Helper;
using WSS.ChatBot.Infrastructure;

/// <summary>
/// Class to implement level conversation for Ropes_Stretcher
/// </summary>

namespace ChatBot.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_Stretcher : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        public Ropes_Stretcher(List<CreateDbData> listcreateDbData)
        {
            this.MailContent = new MailContent(listcreateDbData);
            this.ListCreateDbData = listcreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Ropes_Stretcher;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Ropes_Stretcher);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                        $"1. " + ConversationalOptions.Ropes_Stretcher_1 +
                        $"2. " + ConversationalOptions.Ropes_Stretcher_2 +
                        $"3. " + ConversationalOptions.Ropes_Stretcher_3 +
                        $"4. " + ConversationalOptions.Ropes_Stretcher_4;
            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.Ropes_Stretcher_1 +
                           ConversationalOptions.Ropes_Stretcher_2 +
                           ConversationalOptions.Ropes_Stretcher_3 +
                           ConversationalOptions.Ropes_Stretcher_4;
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_Stretcher, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Ropes_StretcherModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 3);
            }
        }

        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            string prompt2;
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            switch (message.ToString())
            {
                case ConversationalOptions.Ropes_Stretcher_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "WSS recommend Timm Master 8 Tail. To choose the right rope for your ship please go into our product catalog." + "\n\n";

                        prompt2 = $"Do you want to know more options about stretcher rope? \n\n ";


                        PromptDialog.Choice(context, this.Level2Option1YesOrNo, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = $"WSS recommend Timm Master 8 Tail. To choose the right rope for your ship please go into our product catalog.\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        prompt2 = $"Do you want to know more options about stretcher rope? \n\n  Yes / No";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2Option1YesOrNo, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;
                case ConversationalOptions.Ropes_Stretcher_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommends Timm Signal 12 Ring. To choose the right rope for your ship, please read more in our product catalog.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    { 
                    prompt = $"WSS recommends Timm Signal 12 Ring. To choose the right rope for your ship, please read more in our product catalog.";
                    await context.PostAsync(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Stretcher);
                    }
                    break;
                case ConversationalOptions.Ropes_Stretcher_3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommend Timm Master 8 Tail. To choose the right rope for your ship, please read more in our product catalog. \n\n" +
                         "Benefits of our Timm Master Tail: \n\n" +
                         "- DNV GL approved product. \n\n" +
                         "- WSS Certificates matching full order details and with DNV GL logo / type approval. \n\n" +
                         "- High breaking strength compared to nominal diameter (stronger rope, lower diameter). \n\n" +
                         "- High abrasion resistance(greater product longevity).This is due to addition of polyester, but importantly the product remains floating, so will not sink and drift towards ship propellers. v" +
                         "- Easy re - supply from WSS global supply network. ";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "WSS recommend Timm Master 8 Tail. To choose the right rope for your ship, please read more in our product catalog.  \n\n\n\n" +
                         "Benefits of our Timm Master Tail:  \n\n" +
                         "- DNV GL approved product.  \n\n" +
                         "- WSS Certificates matching full order details and with DNV GL logo / type approval.  \n\n" +
                         "- High breaking strength compared to nominal diameter (stronger rope, lower diameter).  \n\n" +
                         "- High abrasion resistance(greater product longevity).This is due to addition of polyester, but importantly the product remains floating, so will not sink and drift towards ship propellers.  \n\n" +
                         "- Easy re - supply from WSS global supply network. ";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Stretcher);
                    }
                        
                    break;
                case ConversationalOptions.Ropes_Stretcher_4:
                case "4":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommend Timm Flex 8 Tail, which is especially good when going to exposed berths. To choose the right rope for your ship, please read more in our product catalog.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "WSS recommend Timm Flex 8 Tail, which is especially good when going to exposed berths. To choose the right rope for your ship, please read more in our product catalog.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Stretcher);
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }
        private async Task Level2Option1YesOrNo(IDialogContext context, IAwaitable<string> result)
        {
            string prompt = string.Empty;
            var options = await result;
            string chatbody = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString().ToLower().Trim().Replace("&#160;", "").Trim())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = ConversationalOptions.CommonMessage +
                            ConversationalOptions.Ropes_Stretcher_Option1 +
                            ConversationalOptions.Ropes_Stretcher_Option2 +
                            ConversationalOptions.Ropes_Stretcher_Option3;
                           

                        PromptDialog.Choice(context, this.Level2Option1Conversation,
                        ConversationalOptions.Ropes_Stretcher_Option1ModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, "", context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = ConversationalOptions.CommonMessage +
                       $"1. " + ConversationalOptions.Ropes_Stretcher_Option1 +
                       $"2. " + ConversationalOptions.Ropes_Stretcher_Option2 +
                       $"3. " + ConversationalOptions.Ropes_Stretcher_Option3;                       

                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, "", context, ListCreateDbData);
                        PromptDialog.Text(context, Level2Option1Conversation, prompt, MailContent.ChatDataForUserandBot(context, prompt));
                    }

                       
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_Stretcher);
                    }
                    //implemented email functionality
                    
                    break;

                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2Option1YesOrNo, prompt);
                    return;
            }
        }

        private async Task Level2Option1Conversation(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());
            switch (message.ToString())
            {

                case ConversationalOptions.Ropes_Stretcher_Option1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommend Timm Master 8 Tail. To choose the right rope for your ship please go into our product catalog.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"WSS recommend Timm Master 8 Tail. To choose the right rope for your ship please go into our product catalog.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;

                case ConversationalOptions.Ropes_Stretcher_Option2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"WSS recommends TIMM Flex 8 Tail.  To choose the right rope for your ship please go into our product catalog.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"WSS recommends TIMM Flex 8 Tail.  To choose the right rope for your ship please go into our product catalog.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;

                case ConversationalOptions.Ropes_Stretcher_Option3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"We offer ringtails for both Timm Master 8 and Timm Flex 8. We recommend to only use ringtails together with a shackle for mooring operations with steel wire mooring rope. Please find more information in our product catalog.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"We offer ringtails for both Timm Master 8 and Timm Flex 8. We recommend to only use ringtails together with a shackle for mooring operations with steel wire mooring rope. Please find more information in our product catalog.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2Option1Conversation, prompt);
                    return;
            }
          
        }
    }
}