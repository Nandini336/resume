﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

/// <summary>
/// Class to implement level conversation for RopesConventionalPolyPropylene
/// </summary>

namespace ChatBot.Dialogs.Ropes
{
    [Serializable]
    public class RopesConventionalPolyPropylene : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        public RopesConventionalPolyPropylene(List<CreateDbData> _listcreateDbData)
        {
            this.MailContent = new MailContent(_listcreateDbData);
            this.ListCreateDbData = _listcreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.RopesConventionalPolyPropylene;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.RopesConventionalPolyPropylene);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.RopesConventionalPolyPropylene_1 +
                $"2. " + ConversationalOptions.RopesConventionalPolyPropylene_2;

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.RopesConventionalPolyPropylene_1 +
                           ConversationalOptions.RopesConventionalPolyPropylene_2;
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);
            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.RopesConventionalPolyPropylene, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.RopesConventionalPolyPropyleneModelCollection(), "Please choose one of the below options: ", "Please choose a valid option from below !!", 3);
            }

        }

        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.RopesConventionalPolyPropylene_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Wilhelmsen Ships Service recommend using our mixed composition rope Timm Master 8. For more information, please read more in our product catalog [click here](https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true).";

                        var prompt2 = ConversationalOptions.CommonMessage +
                           ConversationalOptions.Ropes_Conventional_Polypropylene_Option1_1 +
                           ConversationalOptions.Ropes_Conventional_Polypropylene_Option1_2;


                        PromptDialog.Choice(context, this.Level2_1,
                                            ConversationalOptions.Ropes_Conventional_Polypropylene_Option1ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);


                    }
                    else
                    {
                        prompt = $"Wilhelmsen Ships Service recommend using our mixed composition rope Timm Master 8. For more information, please read more in our product catalog <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true'> click here</a> .";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.Ropes_Conventional_Polypropylene_Option1_1 +
                                $"2. " + ConversationalOptions.Ropes_Conventional_Polypropylene_Option1_2;

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2_1, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

                case ConversationalOptions.RopesConventionalPolyPropylene_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Wilhelmsen Ships Service recommend using our mixed composition rope Timm Master 8.For more information, please read more in our product catalog. [click here](https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true)";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Wilhelmsen Ships Service recommend using our mixed composition rope Timm Master 8.For more information, please read more in our product catalog. <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true'> click here</a>";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalPolyPropylene);
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }

        public async Task Level2_1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.Ropes_Conventional_Polypropylene_Option1_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"These are the benefits of our Timm Master rope compared to PP ropes: \n\n" +
                            $"- DNV GL approved product. - WSS Certificates matching full order details and with DNV GL logo / type approval. \n\n" +
                            $" - Higher breaking strength compared to nominal diameter (stronger rope, lower diameter). \n\n" +
                            $" - Higher abrasion resistance (greater product longevity).This is due to addition of polyester, but importantly the product remains floating, so will not sink and drift towards ship propellers. \n\n" +
                            $"- Smaller rope diameter (easier to handle). \n\n" +
                            $" - Easy re-supply from WSS global supply network.";

                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"These are the benefits of our Timm Master rope compared to PP ropes: \n\n" +
                            $"- DNV GL approved product. - WSS Certificates matching full order details and with DNV GL logo / type approval. \n\n" +
                            $" - Higher breaking strength compared to nominal diameter (stronger rope, lower diameter). \n\n" +
                            $" - Higher abrasion resistance (greater product longevity).This is due to addition of polyester, but importantly the product remains floating, so will not sink and drift towards ship propellers. \n\n" +
                            $"- Smaller rope diameter (easier to handle). \n\n" +
                            $" - Easy re-supply from WSS global supply network.";

                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalPolyPropylene);
                    }
                    break;

                case ConversationalOptions.Ropes_Conventional_Polypropylene_Option1_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Some cruise vessels prefer using blue mooring ropes. Our Timm Signal 12 [click here](https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-signal-12/timm-signal-12/?epieditmode=true) is a polypropylene rope with blue color - made especially for the cruise vessels.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Some cruise vessels prefer using blue mooring ropes. Our Timm Signal 12 <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-signal-12/timm-signal-12/?epieditmode=true '> click here</a> is a polypropylene rope with blue color - made especially for the cruise vessels.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalPolyPropylene);
                    }
                    break;



                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2_1, prompt);
                    return;
            }
        }
    }
}