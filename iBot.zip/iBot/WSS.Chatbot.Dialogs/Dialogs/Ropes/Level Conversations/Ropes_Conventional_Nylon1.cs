﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;
namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Level_Conversations
{
    [Serializable]
    public class Ropes_Conventional_Nylon : IPostDataForFuel, IDialog<object>
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }
        public Ropes_Conventional_Nylon(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.RopesConventionalNylon;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.RopesConventionalNylon);

            string replyMsg = string.Empty;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                        $"1. " + ConversationalOptions.nylonRopes +
                        $"2. " + ConversationalOptions.nylonStretchers;

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.nylonRopes +
                           ConversationalOptions.nylonStretchers;

            }


            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.RopesConventionalNylon, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1, replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1, ConversationalOptions.Ropes_Conventional_NylonModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 3);
            }
        }

        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.nylonRopes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "No, WSS do not offer nylon mooring ropes.";

                        var prompt2 = ConversationalOptions.CommonMessage +
                            ConversationalOptions.Ropes_Conventional_Nylon1_Option1 +
                            ConversationalOptions.Ropes_Conventional_Nylon1_Option2 +
                            ConversationalOptions.Ropes_Conventional_Nylon1_Option3;


                        PromptDialog.Choice(context, this.Level2_1,
                                            ConversationalOptions.Ropes_Conventional_Nylon1_OptionsModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 2);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = "No, WSS do not offer nylon mooring ropes.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                $"1. " + ConversationalOptions.Ropes_Conventional_Nylon1_Option1 +
                                $"2. " + ConversationalOptions.Ropes_Conventional_Nylon1_Option2 +
                                $"3. " + ConversationalOptions.Ropes_Conventional_Nylon1_Option3;

                        MailContent.ChatDataForBot(context, prompt2);
                        PromptDialog.Text(context, Level2_1, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;
                case ConversationalOptions.nylonStretchers:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Yes, WSS offer both single tails and ringtail of nylon. The product names are Timm Flex 8 Tail and Timm Flex 8 Ring. " +
                            $"Please read more about the strength and other specifications in our product catalog [click here](https://wilhelmsen.com/product-catalogue/search-results/?categoryId=-1&term=timm+flex)" +
                            $"\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know why should we use nylon stretchers for our HMPE or steel wire ropes? \n\n ";
                        PromptDialog.Choice(context, this.Level2_2, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = $"Yes, WSS offer both single tails and ringtail of nylon. The product names are Timm Flex 8 Tail and Timm Flex 8 Ring. " +
                            $"Please read more about the strength and other specifications in our product catalog <a href = 'https://wilhelmsen.com/product-catalogue/search-results/?categoryId=-1&term=timm+flex'> click here</a>" +
                            $" \n\n  " + " \n\n  ";

                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you want to know why should we use nylon stretchers for our HMPE or steel wire ropes? \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level2_2, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }


        public async Task Level2_1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            switch (message.ToString())
            {
                case ConversationalOptions.Ropes_Conventional_Nylon1_Option1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Nylon filaments are absorbing water. The result of this is that the nylon rope sinks, and it will also loose strength when it is wet. Having in mind that the elongation is very high, the potential snap-back effect is very dangerous. Having this in mind, we recommend using other rope fibers for mooring purposes." +
                            $"\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Are you looking for what about tankers going to exposed offshore terminals? \n\n ";
                        PromptDialog.Choice(context, this.Level3_1, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = $"Nylon filaments are absorbing water. The result of this is that the nylon rope sinks, and it will also loose strength when it is wet. Having in mind that the elongation is very high, the potential snap-back effect is very dangerous. Having this in mind, we recommend using other rope fibers for mooring purposes." +
                            $" \n\n  " + " \n\n  ";

                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Are you looking for what about tankers going to exposed offshore terminals? \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level3_1, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;

                case ConversationalOptions.Ropes_Conventional_Nylon1_Option2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"To switch from 100% Nylon rope over to a mixed composition Polyolefin/Polyester rope is not a problem. However, it is important that they are not mixed with each other." +
                            $" The difference in elongation will cause problems. They need to work in pair and on same lines.";

                        var prompt2 = ConversationalOptions.CommonMessage +
                                      ConversationalOptions.Ropes_Conventional_NylonOptions2_1 +
                                      ConversationalOptions.Ropes_Conventional_NylonOptions2_2;

                        PromptDialog.Choice(context, this.Level3_2,
                                            ConversationalOptions.Ropes_Conventional_NylonOptions2_ModelCollection(),
                                          prompt + "\n\n" + ConversationalOptions.CommonMessage,
                                            "Please choose a valid option from below !!", 3);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"To switch from 100% Nylon rope over to a mixed composition Polyolefin/Polyester rope is not a problem. However, it is important that they are not mixed with each other." +
                            $" The difference in elongation will cause problems. They need to work in pair and on same lines.";

                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var prompt2 = ConversationalOptions.CommonMessage +
                                    $"1. " + ConversationalOptions.Ropes_Conventional_NylonOptions2_1 +
                                    $"2. " + ConversationalOptions.Ropes_Conventional_NylonOptions2_2;
                        MailContent.ChatDataForBot(context, prompt2);

                        PromptDialog.Text(context, Level3_2, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;

                case ConversationalOptions.Ropes_Conventional_Nylon1_Option3:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"We recommend changing all nylon ropes to mixed composition rope Timm Master 8 [click here](https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true)" +
                            $" or change either all breast lines or all spring lines.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"We recommend changing all nylon ropes to mixed composition rope Timm Master 8 <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true'> click here</a> " +
                           $" or change either all breast lines or all spring lines.";

                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalNylon);
                    }
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level2_1, prompt);
                    return;
            }
        }

        public async Task Level2_2(IDialogContext context, IAwaitable<object> result)
        {
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var options = await result;
            var prompt = string.Empty;
            var prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case ConversationalOptions.Yes:
                case "yup":
                case "yes":
                case "yo":
                case "yeah":
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "We always recommend using our mixed composition stretchers for normal mooring operations, Timm Master 8 Tail or Ring [click here](https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-master-8-tail/timm-master-8-tail/?epieditmode=true). However, for tankers going to exposed berths, such as offshore terminals, the vessels can use the nylon tails to mitigate some of the swell forces and shock loads. Nylon will make the mooring solution more flexible, with 40% elongation at break. Please read more in our product catalog, [click here](https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-flex-8-tail/timm-flex-8-tail/?epieditmode=true)";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "We always recommend using our mixed composition stretchers for normal mooring operations, Timm Master 8 Tail or Ring <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-master-8-tail/timm-master-8-tail/?epieditmode=true'> click here</a>. However, for tankers going to exposed berths, such as offshore terminals, the vessels can use the nylon tails to mitigate some of the swell forces and shock loads. Nylon will make the mooring solution more flexible, with 40% elongation at break. Please read more in our product catalog,<a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-flex-8-tail/timm-flex-8-tail/?epieditmode=true'> click here</a>";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalNylon);
                        break;
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalNylon);
                        break;
                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse2(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2_2, prompt);
                    return;
            }
        }

        public async Task Level3_1(IDialogContext context, IAwaitable<object> result)
        {
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var options = await result;
            var prompt = string.Empty;
            var prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case ConversationalOptions.Yes:
                case "yup":
                case "yes":
                case "yo":
                case "yeah":
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "Tanker vessels going to exposed berths are usually using steel wires or HMPE as the mooring line. " +
                            "For these terminals, we recommend using nylon tails, Timm Flex Tail or Ring. [click here](https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-flex-8-tail/timm-flex-8-tail/?epieditmode=true) for more details . This will make the mooring solution more prepared for swell and shock load conditions.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "Tanker vessels going to exposed berths are usually using steel wires or HMPE as the mooring line. " +
                            "For these terminals, we recommend using nylon tails, Timm Flex Tail or Ring. <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-flex-8-tail/timm-flex-8-tail/?epieditmode=true'> Click here</a> for more details .This will make the mooring solution more prepared for swell and shock load conditions.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalNylon);
                        break;
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalNylon);
                        break;
                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse2(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level3_1, prompt);
                    return;
            }
        }

        public async Task Level3_2(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());


            switch (message.ToString())
            {
                case ConversationalOptions.Ropes_Conventional_NylonOptions2_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Nylon has an up to 40% elongation (new rope) while the mix composition rope has 18-19% to break as new. Mixing these elongations will mean that the Timm Master 8 ropes are doing all the work.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Nylon has an up to 40% elongation (new rope) while the mix composition rope has 18-19% to break as new. Mixing these elongations will mean that the Timm Master 8 ropes are doing all the work.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalNylon);
                    }

                    break;
                case ConversationalOptions.Ropes_Conventional_NylonOptions2_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"We recommend changing all nylon ropes to mixed composition rope Timm Master 8 [click here](https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true), or change either all breast lines or all spring lines.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"We recommend changing all nylon ropes to mixed composition rope Timm Master 8 <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/conventional-mooring-ropes/timm-master-8/timm-master-8/?epieditmode=true'> click here</a>, or change either all breast lines or all spring lines.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesConventionalNylon);
                    }

                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level3_2, prompt);
                    return;
            }
        }
        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    }
}