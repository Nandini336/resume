﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

namespace ChatBot.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_TimmMaster8 : IPostDataForFuel
    {
        public List<CreateDbData> ListCreateDbData { get; set; }

        public MailContent MailContent { get; set; }

        public Ropes_TimmMaster8(List<CreateDbData> _listcreateDbData)
        {
            this.MailContent = new MailContent(_listcreateDbData);
            this.ListCreateDbData = _listcreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Ropes_TimmMaster8;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Ropes_TimmMaster8);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.Ropes_TimmMaster8_1 +
                $"2. " + ConversationalOptions.Ropes_TimmMaster8_2;             

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.Ropes_TimmMaster8_1 +
                           ConversationalOptions.Ropes_TimmMaster8_2;                           
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);
            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_TimmMaster8, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1,
                 ConversationalOptions.Ropes_TimmMaster8ModelCollection(), "Please choose one of the below options: ", "Please choose a valid option from below !!", 3);
            }
        }

        private async Task Level1(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());
            string prompt;
            string prompt2;
            switch (message.ToString())
            {
                case ConversationalOptions.Ropes_TimmMaster8_1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "Timm Master 8 is made of polyolefin yarn and high tenacity polyester." + "\n\n";

                        prompt2 = $"Do you want to know if Timm Master 8 float?  \n\n";

                        PromptDialog.Choice(context, this.Level2CoversationforOption1, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = "Timm Master 8 is made of polyolefin yarn and high tenacity polyester.";
                        await context.PostAsync(prompt);

                        MailContent.ChatDataForUserandBot(context, prompt);
                        prompt2 = "Do you want to know if Timm Master 8 float?  \n\n  Yes / No";
                        MailContent.ChatDataForBot(context, prompt2);

                        PromptDialog.Text(context, Level2CoversationforOption1, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;

                case ConversationalOptions.Ropes_TimmMaster8_2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "Timm Master 8 are sold with two eyes as a standard, with polyester eye protection." + "\n\n";

                        prompt2 = $"Do you want to know what size do the standard eyes have?  \n\n ";

                        PromptDialog.Choice(context, this.Level2CoversationforOption2, ConversationalOptions.YesNo(), prompt + prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = "Timm Master 8 are sold with two eyes as a standard, with polyester eye protection.";
                        await context.PostAsync(prompt);

                        MailContent.ChatDataForUserandBot(context, prompt);
                        prompt2 = "Do you want to know what size do the standard eyes have?  \n\n  Yes / No";
                        MailContent.ChatDataForBot(context, prompt2);

                        PromptDialog.Text(context, Level2CoversationforOption2, prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, prompt2, context, ListCreateDbData);
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                MailContent.ChatDataForUserandBot(context, prompt);
                CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                PromptDialog.Text(context, this.Level1, prompt);
                return;
            }
        }

        private async Task Level2CoversationforOption1(IDialogContext context, IAwaitable<string> result)
        {
            string prompt = string.Empty;
            var Options = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string chatbody = string.Empty;
            CosmosDbData.UserReplyWithoutIntent(context, Options.ToString());

            switch (Options.ToString())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Yes, Timm Master 8 floats, and has water absorption lower than 1%.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "Yes, Timm Master 8 floats, and has water absorption lower than 1%.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_TimmMaster8);
                    }
                    break;
                case ConversationalOptions.No:
                case "2":
                case "no":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context,WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);

                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2CoversationforOption1, prompt);
                    return;
            }
        }

        private async Task Level2CoversationforOption2(IDialogContext context, IAwaitable<string> result)
        {
            string prompt = string.Empty;
            var Options = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            string chatbody = string.Empty;
            CosmosDbData.UserReplyWithoutIntent(context, Options.ToString());

            switch (Options.ToString())
            {
                case "yes":
                case "yup":
                case "yo":
                case "yeah":
                case ConversationalOptions.Yes:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Each eye is 1.8-meter long.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "Each eye is 1.8-meter long.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_TimmMaster8);
                    }

                    break;
                case ConversationalOptions.No:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                    }
                    else
                    {
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopeAccessories);

                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2CoversationforOption2, prompt);
                    return;
            }
        }       
    }
}