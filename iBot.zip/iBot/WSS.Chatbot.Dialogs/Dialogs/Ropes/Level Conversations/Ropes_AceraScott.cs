﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using WSS.ChatBot.Common.Helper;
using System.Configuration;


namespace WSS.Chatbot.Dialogs.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_AceraScott : IPostDataForFuel, IDialog<object>
     
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_AceraScott(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }
        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> listCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Ropes_AceraScott;
            //CreateDbData.Instance.User = context.Activity.From.Name;
            //CreateDbData.Instance.UserRequestDatetime = DateTime.Now;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Ropes_AceraScott);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                  $"1. " + ConversationalOptions.AceraScottMadeOf +
                  $"2. " + ConversationalOptions.AceraScott +
                  $"3. " + ConversationalOptions.ApplicationAreas;

            }
            else
            {
                replyMsg =  ConversationalOptions.CommonMessage +
                        ConversationalOptions.AceraScottMadeOf +
                        ConversationalOptions.AceraScott +
                        ConversationalOptions.ApplicationAreas;
                    
            }
            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_AceraScott, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, AfterMenuSelection,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.AfterMenuSelection,
                 ConversationalOptions.RopesAcerascottModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());


            string prompt;
            switch (message.ToString())
            {
                case ConversationalOptions.AceraScottMadeOf:
                case "1":
                    prompt = "Acera Scott is constructed from 8-strand square plait (4x2), with a core of Acera yarns with less twist and 24 strand braided covers of polyester protecting each individual strand from wear and abrasion. \n\n ";
                    break;
                case ConversationalOptions.AceraScott:
                case "2":
                    prompt = "Acera Scott is a high performance HMPE rope from 8 strand with a core of Acera yarns protected with a 24 braided PES cover - A heavy duty rope made to withstand rugged conditions. Acera Scott has better elongation than conventional HMPE rope construction. The construction prevents the core and cover from moving independently. In addition, this product has a high strength-to-weight ratio.\n\n";
                    break;
                case ConversationalOptions.ApplicationAreas:
                case "3":
                    prompt = "The availability of polyester covers, extra high diameters and long lengths, make the ropes an attractive choice for several applications, especially mooring and towing.\n\n";
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.AfterMenuSelection, prompt);
                    return;
            }

            var chatbody = MailContent.ChatDataForUserandBot(context, prompt);
            CreateDbData.Instance.BotResponse = prompt;

            string botResponse2Message = prompt  + WSS.ChatBot.Common.Common.HeaderMessage;

            string resolvePrompt = botResponse2Message + " \n\n Yes / No";

            CosmosDbData.BotResponse(WSS.ChatBot.Common.Common.HeaderMessage + " \n\n Yes / No", context, "", ListCreateDbData);

            MailContent.ChatDataForBot(context, WSS.ChatBot.Common.Common.HeaderMessage + " \n\n Yes / No");

            var selection =
                new EndOfConversation(MailContent, ListCreateDbData)
                { Intent = ConstIntents.Ropes_AceraScott };

            MailContent.Intent = selection.Intent;
            //await context.PostAsync(prompt);
            context.PrivateConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, ListCreateDbData);
            // context.PrivateConversationData.SetValue("Intent", MailContent.Intent);

            BotResponses botResponses = new BotResponses(ListCreateDbData);

            var activity = await result;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                // PromptDialog.Confirm(context, botResponses.YesOrNoCard, resolvePrompt);
                List<CardAction> cardButtons = new List<CardAction>();
                List<CardAction> yesno = new List<CardAction> { new CardAction(ActionTypes.ImBack, title: ConstIntents.Yes, value: ConstIntents.Yes), new CardAction(ActionTypes.ImBack, ConstIntents.No, value: ConstIntents.No) };
                HeroCard card = new HeroCard { Text = botResponse2Message, Buttons = yesno };
                var makeMessage = context.MakeMessage();
                makeMessage.Attachments.Add(card.ToAttachment());
                await context.PostAsync(makeMessage);
            }
            else
            {
                await context.PostAsync(resolvePrompt);
            }
        }

        Task IDialog<object>.StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    


    }
}