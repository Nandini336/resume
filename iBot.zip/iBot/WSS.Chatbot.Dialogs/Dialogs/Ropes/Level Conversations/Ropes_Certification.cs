﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Infrastructure;
using WSS.ChatBot.Common.Helper;
using System.Configuration;
using WSS.ChatBot.Common.Utils;

/// <summary>
/// Class to implement level conversation for Ropes_Certification
/// </summary>

namespace ChatBot.Dialogs.Fuel
{
    [Serializable]
    public class Ropes_Certification : IPostDataForFuel, IDialog<object>
    {

        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_Certification(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> _ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.RopesCertification;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.RopesCertification);

            string replyMsg = string.Empty;

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                $"1. " + ConversationalOptions.RopeIdentificationNumber +
                $"2. " + ConversationalOptions.RopeOrderNumber +
                $"3. " + ConversationalOptions.RopeCertification;

            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.RopeIdentificationNumber +
                           ConversationalOptions.RopeOrderNumber +
                           ConversationalOptions.RopeCertification;
            }
            //  MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.RopesCertification, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, AfterMenuSelection,
                    replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.AfterMenuSelection,
                 ConversationalOptions.Ropes_CertificationModelCollection(), "Please choose one of the below options: ", "Please choose a valid option from below !!", 3);
            }
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;
            switch (message.ToString())
            {
                case ConversationalOptions.RopeIdentificationNumber:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {

                        prompt = $"You can retrieve your rope certificate on Onix.com, please have your WSS order number or rope serial number available. You can also contact your WSS Customer Service in order to retrieve your certificate, or to register a company user on Onix.com.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = $"You can retrieve your rope certificate on Onix.com, please have your WSS order number or rope serial number available. You can also contact your WSS Customer Service in order to retrieve your certificate, or to register a company user on Onix.com.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesCertification);
                    }
                    break;
                case ConversationalOptions.RopeOrderNumber:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {

                        prompt = $"You can retrieve your rope certificate on Onix.com, please have your WSS order number or rope serial number available. You can also contact your WSS Customer Service in order to retrieve your certificate, or to register a company user on Onix.com.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);

                    }
                    else
                    {
                        prompt = $"You can retrieve your rope certificate on Onix.com, please have your WSS order number or rope serial number available. You can also contact your WSS Customer Service in order to retrieve your certificate, or to register a company user on Onix.com.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesCertification);

                    }
                    break;
                case ConversationalOptions.RopeCertification:
                case "3":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Our ropes have Type Approval from DNV GL. The Type Approval for each product can be downloaded on DNV GL webpage, or you can contact your Customer Coordinator in WSS." +
                           $"\n\n";
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you have other class certificates?\n\n ";
                        PromptDialog.Choice(context, this.Level1, ConversationalOptions.YesNo(), prompt + Prompt2, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {

                        prompt = $"Our ropes have Type Approval from DNV GL. The Type Approval for each product can be downloaded on DNV GL webpage, or you can contact your Customer Coordinator in WSS." +
                            $" \n\n  " + " \n\n  ";

                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt2 = $"Do you have other class certificates? \n\n Yes / No";

                        MailContent.ChatDataForBot(context, Prompt2);

                        PromptDialog.Text(context, Level1, prompt + Prompt2);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt2, context, ListCreateDbData);
                        break;
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    //  MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.AfterMenuSelection, prompt);

                    return;
            }

        }


        public async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var options = await result;
            var prompt = string.Empty;
            var prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case ConversationalOptions.Yes:
                case "yup":
                case "yes":
                case "yo":
                case "yeah":
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "We can do certification through other class societies on request. We also have ClassNK certificate for our Timm Master ropes.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "We can do certification through other class societies on request. We also have ClassNK certificate for our Timm Master ropes.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesCertification);
                        break;
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context, WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.RopesCertification);
                        break;
                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse2(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }
        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    }
}