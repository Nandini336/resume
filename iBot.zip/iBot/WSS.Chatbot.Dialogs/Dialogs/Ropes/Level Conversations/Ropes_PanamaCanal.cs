﻿using WSS.ChatBot.Common;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ChatBot.Common;
using WSS.ChatBot.Common.Utils;
using WSS.ChatBot.Infrastructure;
using System.Configuration;
using WSS.ChatBot.Common.Helper;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes.Level_Conversations
{
    [Serializable]
    public class Ropes_PanamaCanal : IPostDataForFuel, IDialog<object>
    {
        public List<CreateDbData> ListCreateDbData { get; set; }
        public MailContent MailContent { get; set; }

        public Ropes_PanamaCanal(List<CreateDbData> listCreateDbData)
        {
            this.MailContent = new MailContent(listCreateDbData);
            this.ListCreateDbData = listCreateDbData;
        }

        public async Task MainAsync(IDialogContext context, IAwaitable<IMessageActivity> activity, List<CreateDbData> ListCreateDbData)
        {
            var messageActivity = await activity;

            CreateDbData.Instance.UserReply = messageActivity != null ? messageActivity.Text : ConstIntents.Ropes_PanamaCanal;
            CosmosDbData.UserReplyWithIntent(context, messageActivity.Text, ConstIntents.Ropes_PanamaCanal);

            string replyMsg = string.Empty;
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                replyMsg = ConversationalOptions.CommonMessage +
                        $"1. " + ConversationalOptions.PanamaCanal1 +
                        $"2. " + ConversationalOptions.PanamaCanal2;
            }
            else
            {
                replyMsg = ConversationalOptions.CommonMessage +
                           ConversationalOptions.PanamaCanal1 +
                           ConversationalOptions.PanamaCanal2;
            }


            MailContent.ChatDataForUserandBot(context, replyMsg);

            CosmosDbData.BotResponse(replyMsg, context, ConstIntents.Ropes_PanamaCanal, ListCreateDbData);

            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.QBot)
            {
                PromptDialog.Text(context, Level1, replyMsg);
            }
            else
            {
                PromptDialog.Choice(context, this.Level1, ConversationalOptions.PanamaCanalModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);
            }
        }


        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

            string prompt;

            switch (message.ToString())
            {
                case ConversationalOptions.PanamaCanal1:
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"Wire ropes and ropes composed of both wire and fiber or filaments, are not acceptable for Canal operations and shall not be used. " + "\n\n";

                        var Prompt1 = $"Do you want know, what kind of ropes do you recommend using for the Panama Canal? \n\n ";

                        PromptDialog.Choice(context, this.Level2, ConversationalOptions.YesNo(), prompt + Prompt1, "Please choose a valid option from below !!", 3);
                        CosmosDbData.BotResponse2withBlankIntent(prompt , Prompt1 + ConstIntents.Yes + " / " + ConstIntents.No, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"Wire ropes and ropes composed of both wire and fiber or filaments, are not acceptable for Canal operations and shall not be used." + " \n\n  " ;
                        MailContent.ChatDataForUserandBot(context, prompt);

                        var Prompt1 = $"Do you want know, what kind of ropes do you recommend using for the Panama Canal? \n\n Yes / No";
                        MailContent.ChatDataForBot(context, Prompt1);
                        PromptDialog.Text(context, Level2, prompt + Prompt1);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, Prompt1, context, ListCreateDbData);
                        break;
                    }
                    break;

                case ConversationalOptions.PanamaCanal2:
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = $"They are stating: 'The fiber rope lines are required to be on deck prior to commencing transit and ready for immediate use. Each line shall be at least 75 meters(250 feet) in length and shall have an eye of at least 1.52 meters(5 feet) spliced in one end.If one of these lines is 152 meters(500 feet) or more in length with an eye in each end, it will qualify as two lines for the purpose of this requirement.They shall be in good condition.Non - compliance with this requirement could result in transit delay. ' All our fiber ropes comply with the Panama Canal requirements. Please contact our Customer Coordinator today, and we can help you choosing the best solution for your vessel.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = $"They are stating: 'The fiber rope lines are required to be on deck prior to commencing transit and ready for immediate use. Each line shall be at least 75 meters(250 feet) in length and shall have an eye of at least 1.52 meters(5 feet) spliced in one end.If one of these lines is 152 meters(500 feet) or more in length with an eye in each end, it will qualify as two lines for the purpose of this requirement.They shall be in good condition.Non - compliance with this requirement could result in transit delay. ' All our fiber ropes comply with the Panama Canal requirements. Please contact our Customer Coordinator today, and we can help you choosing the best solution for your vessel.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_PanamaCanal);
                        break;
                    }
                    break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    MailContent.ChatDataForUserandBot(context, prompt);
                    CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;
            }
        }

        public async Task Level2(IDialogContext context, IAwaitable<object> result)
        {
            BotResponses botResponses = new BotResponses(ListCreateDbData);
            var options = await result;
            var prompt = string.Empty;
            var prompt2 = string.Empty;
            FinalQuery finalQuery = new FinalQuery(ListCreateDbData);

            CosmosDbData.UserReplyWithoutIntent(context, options.ToString());

            switch (options.ToString())
            {
                case ConversationalOptions.Yes:
                case "yup":
                case "yo":
                case "yeah":
                case "yes":
                case "1":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        prompt = "We recommend our Timm Master ropes, or converting the vessel to Acera HMPE solution. If the vessel wants to keep on using steel wire ropes, but need extra ropes for the Panama Canal, we recommend the polyester rope Terraline.";
                        await botResponses.YesNoCard(context, prompt + "\n\n" + WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        prompt = "We recommend our Timm Master ropes, or converting the vessel to Acera HMPE solution. If the vessel wants to keep on using steel wire ropes, but need extra ropes for the Panama Canal, we recommend the polyester rope Terraline.";
                        await context.PostAsync(prompt);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_PanamaCanal);
                        break;
                    }
                    break;

                case ConversationalOptions.No:
                case "no":
                case "2":
                    if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
                    {
                        await botResponses.YesNoCard(context,  WSS.ChatBot.Common.Common.HeaderMessage);
                        MailContent.ChatDataForUserandBot(context, prompt);
                        CosmosDbData.BotResponse2withBlankIntent(prompt, WSS.ChatBot.Common.Common.HeaderMessage, context, ListCreateDbData);
                    }
                    else
                    {
                        await finalQuery.LogForFinalQuery(context, result, prompt, MailContent.ChatDataForUserandBot(context, prompt), ConstIntents.Ropes_PanamaCanal);
                        break;
                    }
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                    CosmosDbData.BotResponse2(prompt);
                    MailContent.ChatDataForUserandBot(context, prompt);
                    PromptDialog.Text(context, this.Level2, prompt);
                    return;
            }
        }

        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    }
}