﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_Acera_40MM : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "We recommend using <b>TIMM MASTER 8 TAIL 88MM 11M 1485KN (SPLICED)</b> as a tail for product <b>ACERA AMUNDSEN 40MM 220M 1130KN (SPLICED)/1260KN (UNSPLICED)</b> with product number <b>410187</b> </br>" +
                          "For more details please <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-master-8-tail/timm-master-8-tail/?epieditmode=true'> click here</a>";
            }
            else
            {
                message = "We recommend using **TIMM MASTER 8 TAIL 88MM 11M 1485KN (SPLICED)** as a tail for product **ACERA AMUNDSEN 40MM 220M 1130KN (SPLICED)/1260KN (UNSPLICED)** with product number **410187**\n\n" +
                          "For more details please <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-master-8-tail/timm-master-8-tail/?epieditmode=true'> click here</a>";
            }
            return message;
        }

        public string DoAlgorithmForSpeak()
        {
            string message = "We recommend using TIMM MASTER 8 TAIL 88MM 11M 1485KN SPLICED as a tail for product ACERA AMUNDSEN 40MM 220M 1130KN SPLICED or 1260KN UNSPLICED with product number 410187";
            return message;
        }
    }
}