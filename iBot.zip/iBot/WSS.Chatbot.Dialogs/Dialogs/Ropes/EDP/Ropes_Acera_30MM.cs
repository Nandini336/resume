﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_Acera_30MM : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "We recommend using <b>TIMM MASTER 8 TAIL 68MM 11M 894KN (SPLICED)</b>  as a tail for product <b>ACERA AMUNDSEN 30MM 220M 690KN (SPLICED)/770KN (UNSPLICED)</b>  with product number <b>410147</b> </br>" +
                         "For more details please <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-master-8-tail/timm-master-8-tail/?epieditmode=true'> click here</a>";
            }
            else
            {
                message = "We recommend using **TIMM MASTER 8 TAIL 68MM 11M 894KN (SPLICED)**  as a tail for product **ACERA AMUNDSEN 30MM 220M 690KN (SPLICED)/770KN (UNSPLICED)**  with product number **410147** \n\n" +
                          "For more details please <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-master-8-tail/timm-master-8-tail/?epieditmode=true'> click here</a>";
            }
            return message;
        }
        public string DoAlgorithmForSpeak()
        {
            string message = "We recommend using TIMM MASTER 8 TAIL 68MM 11M 894KN SPLICED as a tail ,for product ACERA AMUNDSEN 30MM 220M 690KN SPLICED or 770KN UNSPLICED with product number 410147";
            return message;
        }
    }
}