﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WSS.ChatBot.Infrastructure;

namespace WSS.Chatbot.Dialogs.Dialogs.Ropes
{
    [Serializable]
    public class Ropes_Acera_46MM : IMandRIntentStrategy
    {
        public string DoAlgorithm()
        {
            string message = "";
            if (ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source].ToString() == WSS.ChatBot.Common.Common.IBot)
            {
                message = "We recommend using <b>TIMM MASTER 8 RING 72MM 11M 1779KN (SPLICED)</b> as a tail for product <b>ACERA DAGAMA 46MM/52MM 220M 1422KN (SPLICED)/1580KN (UNSPLICED)</b> with product number <b>410163</b> </br>" +
                        "For more details please <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-master-8-tail/timm-master-8-tail/?epieditmode=true'> click here</a>";
            }
            else
            {
                message = "We recommend using **TIMM MASTER 8 RING 72MM 11M 1779KN (SPLICED)** as a tail for product **ACERA DAGAMA 46MM/52MM 220M 1422KN (SPLICED)/1580KN (UNSPLICED)** with product number **410163**\n\n" +
                          "For more details please <a href = 'https://wilhelmsen.com/product-catalogue/products/ropes/rope-stretchers/timm-master-8-tail/timm-master-8-tail/?epieditmode=true'> click here</a>";
            }
            return message;
        }

        public string DoAlgorithmForSpeak()
        {
            string message = "We recommend using TIMM MASTER 8 RING 72MM 11M 1779KN SPLICED as a tail for product ACERA DAGAMA 46MM/52MM 220M 1422KN SPLICED or 1580KN UNSPLICED with product number 410163";
            return message;
        }
    }
}
