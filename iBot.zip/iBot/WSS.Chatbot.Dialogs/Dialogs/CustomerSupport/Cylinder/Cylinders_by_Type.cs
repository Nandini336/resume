﻿using Entities;
using Helper;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace Dialogs.CustomerSupport.Cylinder
{
    [Serializable]
    public class Cylinders_by_Type : IDialog<object>
    {

        private const string CylindersByType = "Cylinders by Type";
        private const string CylinderByVessel = "Cylinders by Vessel";
        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);
            return Task.CompletedTask;
        }
        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            Charts charts = new Charts();
            HttpData httpData = new HttpData();
            string exceptionMessage = "Oops! I have encountered an issue. ";
            string errorMessage = "You have no cylinders allocated to you.";
            try
            {
                List<CylinderDetails> cylinderDetails = null;


                //var userID = 8100009115;

                Int64 userID = Convert.ToInt64(context.Activity.From.Id);


                string url = WebConfigurationManager.AppSettings["CylinderDetails"] + userID;
                cylinderDetails = httpData.GetDataFromHttpRequest<List<CylinderDetails>>(url);

                var option = await result;
                int count = cylinderDetails.Count;
                if (count > 0)
                {
                    string prompt = string.Empty;
                    var messageCylDetails = context.MakeMessage();
                    messageCylDetails.Attachments.Add(getBarChartCard(cylinderDetails));
                    await context.PostAsync(messageCylDetails);
                    context.EndConversation("End");
                }
                else
                {
                    //error card
                    var createMessage = context.MakeMessage();
                    createMessage.Attachments.Add(ErrorCard(errorMessage));
                    await context.PostAsync(errorMessage);
                    context.EndConversation("End");
                }

            }
            catch (Exception)
            {
                var createMessage = context.MakeMessage();
                createMessage.Attachments.Add(ErrorCard(exceptionMessage));
                await context.PostAsync(errorMessage);
                context.EndConversation("End");

            }

            context.Done<object>(null);
        }
        private Attachment getBarChartCard(List<CylinderDetails> lstCylinders)
        {
            Charts charts = new Charts();
            HttpData httpData = new HttpData();

            string img = "data:image/png; base64," + charts.getBinaryOfBarChart(lstCylinders);

            List<CardImage> cardImages = new List<CardImage>();

            cardImages.Add(new CardImage(url: img));

            var greetingCard = new HeroCard()
            {
                Title = "Cylinder Details",
                Text = "You have " + lstCylinders.Count + " cylinders allocated to you.",
                Images = cardImages

            };
            return greetingCard.ToAttachment();
        }

        private Attachment ErrorCard(string message)
        {
            var errorCard = new HeroCard()
            {
                Title = "Cylinder Details",
                Text = message,

            };
            return errorCard.ToAttachment();
        }
    }
}



