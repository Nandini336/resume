﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Dialogs.CustomerSupport.Cylinder
{
    [Serializable]
    public class Cylinders_Details : IDialog<object>
    {

        private const string CylindersByType = "Cylinders by Type";
        private const string CylinderByVessel = "Cylinders by Vessel";
        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);
            return Task.CompletedTask;
        }
        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var activity = await result as Activity;
            List<CardAction> cardButtons = new List<CardAction>();
            List<CardAction> cylinders = new List<CardAction> { new CardAction(ActionTypes.ImBack, title: CylindersByType, value: CylindersByType), new CardAction(ActionTypes.ImBack, CylinderByVessel, value: CylinderByVessel)};
            HeroCard card = new HeroCard { Title = "Please choose from below options:", Buttons = cylinders };
            var message = context.MakeMessage();
            message.Attachments.Add(card.ToAttachment());
            await context.PostAsync(message);
            context.Done<object>(null);
        }
    }

}

