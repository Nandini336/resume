﻿using Entities;
using Helper;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace Dialogs.CustomerSupport.Cylinder
{
    [Serializable]
    public class Cylinders_by_Vessel : IDialog<object>
    {

        private const string CylindersByType = "Cylinders by Type";
        private const string CylinderByVessel = "Cylinders by Vessel";
        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);
            return Task.CompletedTask;
        }
        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            Charts charts = new Charts();
            HttpData httpData = new HttpData();

            List<CylinderDetails> cylinderDetails = null;
            string exceptionMessage = "Oops! I have encountered an issue. ";
            string errorMessage = "You have no cylinders allocated to you.";

            try
            {

                //var userID = 8100009115;

                Int64 userID = Convert.ToInt64(context.Activity.From.Id);


                string url = WebConfigurationManager.AppSettings["CylinderDetails"] + userID;
                cylinderDetails = httpData.GetDataFromHttpRequest<List<CylinderDetails>>(url);

                var option = await result;
                int count = cylinderDetails.Count;
                if (count > 0)
                {
                    var messageCylDetailsPie = context.MakeMessage();
                    messageCylDetailsPie.Attachments.Add(getPieChartCard(cylinderDetails));
                    await context.PostAsync(messageCylDetailsPie);
                    context.EndConversation("End");
                }
                else
                {
                    //error card
                    var createMessage = context.MakeMessage();
                    createMessage.Attachments.Add(ErrorCard(errorMessage));
                    await context.PostAsync(errorMessage);
                    context.EndConversation("End");
                }
            }
            catch (Exception e)
            {

                var createMessage = context.MakeMessage();
                createMessage.Attachments.Add(ErrorCard(exceptionMessage));
                await context.PostAsync(errorMessage);
                context.EndConversation("End");
            }

            context.Done<object>(null);
        }

        private Attachment ErrorCard(string message)
        {
            var errorCard = new HeroCard()
            {
                Title = "Cylinder Details",
                Text = message

            };
            return errorCard.ToAttachment();
        }

        private Attachment getPieChartCard(List<CylinderDetails> lstCylinders)
        {
            Charts charts = new Charts();
            HttpData httpData = new HttpData();

            string img = "data:image/png; base64," + charts.getBinaryOfPieChart(lstCylinders);

            List<CardImage> cardImages = new List<CardImage>();

            cardImages.Add(new CardImage(url: img));

            var greetingCard = new HeroCard()
            {
                Title = "Cylinder Details",
                Text = "You have " + lstCylinders.Count + " cylinders allocated to you.",
                Images = cardImages

            };
            return greetingCard.ToAttachment();
        }

    }
}



