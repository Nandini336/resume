﻿using Dialogs.Luis;
using Entities;
using Helper;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace Dialogs.CustomerSupport.Orders
{
    [Serializable]
    public class OrderCount : IDialog<object>
    {
        public Task StartAsync(IDialogContext context)
        {

            try
            {
                //int userID = 318;
                 Int64 userID = Convert.ToInt64(context.Activity.From.Id);
                string request = WebConfigurationManager.AppSettings["OrderCount"] + userID;

                HttpData httpData = new HttpData();
                dynamic orderCount = httpData.GetSingleDataFromHttpRequest<OrderCountModel>(request);

                var message = context.MakeMessage();
                HeroCard heroCard = CreateCard(orderCount.orders_count.ToString());
                message.Attachments.Add(heroCard.ToAttachment());
                context.PostAsync(message);
            }
            catch (Exception)
            {

                var message = context.MakeMessage();
                HeroCard heroCard = CreateCard("0".ToString());
                message.Attachments.Add(heroCard.ToAttachment());
                context.PostAsync(message);
            }
                   
            return Task.CompletedTask;
        }

        private HeroCard CreateCard(string count)
        {
            HeroCard heroCard = new HeroCard
            {
                //Text = count,
                Title = "Your order count is: " + count,                
            };
            return heroCard;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;
        }
    }
}