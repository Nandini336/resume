﻿using AdaptiveCards;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using Entities;
using Helper;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace Dialogs.CustomerSupport.Orders
{
    public class All_Orders : IDialog<object>
    {
        Errors errors = new Errors();
        public Task StartAsync(IDialogContext context)
        {
            List<AllOrdersResponse> objAllOrders = null;
            Int64 userID = -1;
            string errorMessage = "You do not have any orders.";
            string exceptionMessage = "Oops! I have encountered an issue. ";

            try
            {

                //userID = 97;
                userID = Convert.ToInt64(context.Activity.From.Id);
                //string month = "/" + DateTime.Now.Month.ToString();
                string year = "/" + DateTime.Now.Year.ToString();
                string url = WebConfigurationManager.AppSettings["AllOrders"] + userID + "/null" + year;
                HttpData httpData = new HttpData();
                objAllOrders = httpData.GetDataFromHttpRequest<List<AllOrdersResponse>>(url);
                if (objAllOrders != null)
                {
                    if (objAllOrders.Count > 0)
                    {
                        AdaptiveCard card = CreateCard(objAllOrders);

                        var attachment = new Attachment()
                        {
                            Content = card,
                            ContentType = AdaptiveCard.ContentType
                        };
                        var message = context.MakeMessage();
                        message.Attachments.Add(attachment);
                        context.PostAsync(message);
                    }
                    else
                    {

                        errors.ErrorMessage(context, errorMessage);
                    }
                }
                else
                {
                    errors.ErrorMessage(context, errorMessage);
                }
                
            }
            catch (Exception)
            {
                errors.ErrorMessage(context, exceptionMessage);
                //throw;
            }
            return Task.CompletedTask;
        }
       
        private AdaptiveCard CreateCard(List<AllOrdersResponse> resp)
        {
            int i = 0;
            var card = new AdaptiveCard();
            var headerColumnSet = new AdaptiveColumnSet() { Separator = true};
            
            var column1 = new AdaptiveColumn() { Spacing= AdaptiveSpacing.Medium };
            var column2 = new AdaptiveColumn() { Spacing = AdaptiveSpacing.Medium };
            var column3 = new AdaptiveColumn() { Spacing = AdaptiveSpacing.Medium };
            var column4 = new AdaptiveColumn() { Spacing = AdaptiveSpacing.Medium };
            foreach (var item in resp)
            {
                if (i == 0)
                {
                    column1.Items.Add(new AdaptiveTextBlock()
                    {
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Left,
                        Text = "Order Number",
                        Size = AdaptiveTextSize.Default,
                        Weight = AdaptiveTextWeight.Bolder,
                        Spacing = AdaptiveSpacing.ExtraLarge,
                        Separator = true
                    });
                    column2.Items.Add(new AdaptiveTextBlock(item.PortName)
                    {
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center,
                        Text = "Port Name",
                        Size = AdaptiveTextSize.Default,
                        Weight = AdaptiveTextWeight.Bolder,
                        Separator = true
                    });
                    column3.Items.Add(new AdaptiveTextBlock(item.VesselName)
                    {
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center,
                        Text = "Vessel Name",
                        Size = AdaptiveTextSize.Default,
                        Weight = AdaptiveTextWeight.Bolder,
                        Spacing = AdaptiveSpacing.ExtraLarge,

                        Separator = true
                    });
                    column4.Items.Add(new AdaptiveTextBlock(item.OrderStatus)
                    {
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Right,
                        Text = "Order Status",
                        Size = AdaptiveTextSize.Default,
                        Weight = AdaptiveTextWeight.Bolder,
                        Spacing = AdaptiveSpacing.ExtraLarge,
                        Separator = true
                    });
                    column1.Items.Add(new AdaptiveTextBlock(item.OrderNo) { HorizontalAlignment = AdaptiveHorizontalAlignment.Left, Separator = true });
                    column2.Items.Add(new AdaptiveTextBlock(item.PortName) { HorizontalAlignment = AdaptiveHorizontalAlignment.Left, Separator = true });
                    column3.Items.Add(new AdaptiveTextBlock(item.VesselName) { HorizontalAlignment = AdaptiveHorizontalAlignment.Left, Separator = true });
                    column4.Items.Add(new AdaptiveTextBlock(item.OrderStatus) { HorizontalAlignment = AdaptiveHorizontalAlignment.Right, Separator = true });

                }
                else
                {
                    column1.Items.Add(new AdaptiveTextBlock(item.OrderNo) { HorizontalAlignment = AdaptiveHorizontalAlignment.Left, Separator = true });
                    column2.Items.Add(new AdaptiveTextBlock(item.PortName) { HorizontalAlignment = AdaptiveHorizontalAlignment.Left, Separator = true });
                    column3.Items.Add(new AdaptiveTextBlock(item.VesselName) { HorizontalAlignment = AdaptiveHorizontalAlignment.Left, Separator = true });
                    column4.Items.Add(new AdaptiveTextBlock(item.OrderStatus) { HorizontalAlignment = AdaptiveHorizontalAlignment.Right, Separator = true });
                }
                i++;
            }
            
            headerColumnSet.Columns.Add(column1);
            headerColumnSet.Columns.Add(column2);
            headerColumnSet.Columns.Add(column3);
            headerColumnSet.Columns.Add(column4);

            card.Body.Add(headerColumnSet);

            return card;
        }
      
    }
}