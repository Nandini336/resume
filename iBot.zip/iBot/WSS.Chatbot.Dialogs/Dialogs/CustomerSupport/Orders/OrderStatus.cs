﻿using AdaptiveCards;
using Dialogs.Luis;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using Entities;
using Helper;
using System;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace Dialogs.CustomerSupport.Orders
{
    [Serializable]
    public class Order_Status : IDialog<object>
    {
        
        private string order_Number;
        public Order_Status(string order_Number)
        {
            this.order_Number = order_Number;           
        }

        public async Task StartAsync(IDialogContext context)
        {
            OrderStatusResponse objOrderStatus = null;
            string url = WebConfigurationManager.AppSettings["OrderStatus"] + order_Number;
            HttpData httpData = new HttpData();
            objOrderStatus = httpData.GetSingleDataFromHttpRequest<OrderStatusResponse>(url);

            if (objOrderStatus != null)
            {
                var message = context.MakeMessage();
                AdaptiveCard heroCard = CreateCard(objOrderStatus);
                var attachment = new Attachment()
                {
                    Content = heroCard,
                    ContentType = AdaptiveCard.ContentType
                };
                message.Speak = "I could not get the details for your order number.Please try again!";
                message.InputHint = InputHints.AcceptingInput;

                message.Attachments.Add(attachment);
               await context.PostAsync(message);
            }
            else
            {
                var message = context.MakeMessage();
                HeroCard heroCard = BuildErrorCard();
                message.Attachments.Add(heroCard.ToAttachment());
               await context.PostAsync(message);

            }

        }

        private HeroCard BuildErrorCard()
        {
            HeroCard heroCard = new HeroCard
            {
                Title = "Status for Order number : " + order_Number,
                Text = "I could not get the details for your order number. Please try again!"
            };
            return heroCard;
        }
        private AdaptiveCard CreateCard(OrderStatusResponse resp)
        {
            string promptStatus = string.Empty;
            string promptDeliveryDate = string.Empty;

            promptStatus =  OrderStatus(resp);
            promptDeliveryDate = DeliveryDate(resp);

            AdaptiveCard adaptiveCard = new AdaptiveCard();
            adaptiveCard.Body.Add(new AdaptiveTextBlock()
            {
                Text = "Status for Order number : " + resp.OrderNo,
                Size = AdaptiveTextSize.Large,
                Weight = AdaptiveTextWeight.Bolder
            });
            adaptiveCard.Body.Add(new AdaptiveTextBlock()
            {
                Text = promptStatus + promptDeliveryDate,
                Size = AdaptiveTextSize.Default,
                Weight = AdaptiveTextWeight.Default,
                Wrap = true
            });

            return adaptiveCard;

        }

        private string OrderStatus(OrderStatusResponse resp)
        {
            string promptStatus = string.Empty;
            if ((resp.OrderStatus == null) || (resp.OrderStatus.Trim().Length < 1))
            {
                promptStatus = "Your order Status is not defined";
            }
            else
            {
                promptStatus = "Your order Status is: " + "**"+ resp.OrderStatus +"**";
            }

            return promptStatus;

        }

        private string  DeliveryDate(OrderStatusResponse resp)
        {
            string promptDeliveryDate = string.Empty;
            if (resp.DeliveryDate == null)
            {
                promptDeliveryDate = " and the expected delivery date is not defined";
            }
            else
            {
                promptDeliveryDate = " and the expected delivery date is " + resp.DeliveryDate;
            }
            return promptDeliveryDate;
        }


    }
}