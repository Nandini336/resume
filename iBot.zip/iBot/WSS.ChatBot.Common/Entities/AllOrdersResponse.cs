﻿using System;

namespace Entities
{
    public class AllOrdersResponse
    {
        public string OrderStatus { get; set; }
        public string OrderNo { get; set; }
        public string PortName { get; set; }
        public string VesselName { get; set; }
            
    }
}