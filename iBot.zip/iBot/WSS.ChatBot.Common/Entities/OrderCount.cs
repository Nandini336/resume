﻿using System;

namespace Entities
{
    public class OrderCountModel
    {

        public object ropes_count { get; set; }
        public int cylinder_count { get; set; }
        public int orders_count { get; set; }
        public int alerts_Count { get; set; }


    }

}