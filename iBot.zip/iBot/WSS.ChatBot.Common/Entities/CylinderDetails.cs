﻿using System;

namespace Entities
{
    public class CylinderDetails
    {
        public string Cylinder_ID { get; set; }
        public string IFS_ORDER_NO { get; set; }
        public string VESSEL_ID { get; set; }
        public string CYLINDER_NAME { get; set; }
        public string Serial_No { get; set; }
        public DateTime Date_OF_Delivery { get; set; }
        public string Port_Of_Delivery { get; set; }
        public bool DELETED { get; set; }
        public string CREATEDBY { get; set; }
        public DateTime CREATEDDATE { get; set; }
        public string MODIFIEDBY { get; set; }
        public DateTime MODIFIEDDATE { get; set; }
        public string PartNum { get; set; }
        public string Vessel_Name { get; set; }
        public string Port_Id { get; set; }
        public string Last_Cust_Id { get; set; }
        public string Site { get; set; }
        public string CUSTOMER_PO_NO { get; set; }
        public int ID { get; set; }
        public object Cylinder_type { get; set; }
        public object Cust_Id { get; set; }
        public object Asset_ID { get; set; }
        public int DaysonBoard { get; set; }
    }
}