﻿using System;

namespace Entities
{
    public class OrderStatusResponse
    {
      
        public int ID { get; set; }
        public string OrderNo { get; set; }
        public string CustomerID { get; set; }
        public string OrderStatus { get; set; }

        public DateTime DeliveryDate { get; set; }


    }

}