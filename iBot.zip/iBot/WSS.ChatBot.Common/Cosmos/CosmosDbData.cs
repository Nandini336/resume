﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;

/// <summary>
/// Common class for capturing user and bot responses (cosmos db data)
/// </summary>

namespace WSS.ChatBot.Common
{
    public class CosmosDbData
    {
        public static void BotResponse(string replyMsg, IDialogContext context, string intent, List<CreateDbData> listCreateDbData)
        {
            CreateDbData.Instance.Bot = Common.Bot;
            CreateDbData.Instance.BotResponse = replyMsg;
            CreateDbData.Instance.BotResponse2 = string.Empty;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            if (intent == "")
            {
                CreateDbData.Instance.Intent = "";
                
            }

            CosmosSaveData(context, listCreateDbData);

        }

        public static void BotResponsewithQueryResolvedStatus(string prompt, string botResponse2, IDialogContext context, List<CreateDbData> listCreateDbData,string isUserQueryResolved)
        {
            CreateDbData.Instance.BotResponse = prompt;
            CreateDbData.Instance.Bot = Common.Bot;
            CreateDbData.Instance.BotResponse2 = botResponse2;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = "";
            CreateDbData.Instance.IsUserQueryResolved = isUserQueryResolved;
            CosmosSaveData(context, listCreateDbData);
        }


        public static void BotResponse2withBlankIntent(string prompt, string finalPrompt, IDialogContext context, List<CreateDbData> listCreateDbData)
        {
            if (string.IsNullOrEmpty(prompt))
            {
                CreateDbData.Instance.BotResponse = prompt;
                CreateDbData.Instance.Bot = string.Empty;
                CreateDbData.Instance.BotResponse2 = finalPrompt;
                CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
                CreateDbData.Instance.Intent = "";
                CosmosSaveData(context, listCreateDbData);
            }
            else
            {
                CreateDbData.Instance.BotResponse = prompt;
                CreateDbData.Instance.Bot = Common.Bot;
                CreateDbData.Instance.BotResponse2 = finalPrompt;
                CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
                CreateDbData.Instance.Intent = "";
                CosmosSaveData(context, listCreateDbData);
            }              
        }

        public static void BotResponse2withSaveDbData(string replyMsg, IDialogContext context, List<CreateDbData> listCreateDbData)
        {
            BotResponse2(replyMsg: replyMsg);

            CosmosSaveData(context, listCreateDbData);
        }

        public static void BotResponse2(string replyMsg)
        {
            CreateDbData.Instance.BotResponse2 = replyMsg;
            CosmosSetBotDateTime();
        }

        public static void SaveConversationToDB(IDialogContext context, List<CreateDbData> listCreateDbData)
        {
            CosmosSaveData(context: context, listCreateDbData: listCreateDbData);
        }


        public static void UserReplyWithoutIntent(IDialogContext context, string messageActivity)
        {
            CosmosUserReplyData(context: context, message: messageActivity);
        }

        public static void UserReplyWithIntent(IDialogContext context, string messageActivity, string intent)
        {
            CosmosUserReplyData(context: context, message: messageActivity);
            CosmosDbAddIntent(intent: intent);
        }

        public static void CosmosAddToListData(List<CreateDbData> listCreateDbData)
        {
            listCreateDbData.Add(CreateDbData.Instance);
        }

        public static void CosmosSaveData(IDialogContext context, List<CreateDbData> listCreateDbData)
        {
            CosmosAddToListData(listCreateDbData: listCreateDbData);//Collection of Cosmos Data
            context.ConversationData.SetValue(Common.Conversation, listCreateDbData);//Save Data in Cosmos DB
        }

        public static void CosmosDbAddIntent(string intent)
        {
            CreateDbData.Instance.Intent = intent;
        }

        public static void CosmosPromptMessage(string prompt)
        {
            CreateDbData.Instance.BotResponse = prompt;
        }

        public static void CosmosBotResponse(string prompt)
        {
            CreateDbData.Instance.BotResponse = prompt;
            CosmosSetBotDateTime();
        }

        public static void LogCreation(IDialogContext context, string replyMsg, string intent, IMessageActivity msgActivity, List<CreateDbData> listCreateDbData)
        {

            CreateDbData.Instance.User = context.Activity.From.Name;
            CreateDbData.Instance.Source = ConfigurationManager.AppSettings[WSS.ChatBot.Common.Common.Source];
            
            if (msgActivity != null)
            {
                CreateDbData.Instance.UserReply = msgActivity.Text;
            }
            CreateDbData.Instance.UserRequestDatetime = DateTime.Now;
            CreateDbData.Instance.Intent = intent;
            CreateDbData.Instance.BotResponse = replyMsg;
            CreateDbData.Instance.Bot = WSS.ChatBot.Common.Common.Bot;
            CreateDbData.Instance.BotResponse2 = WSS.ChatBot.Common.Common.YesOrNoSelection;
            CreateDbData.Instance.BotResponseDatetime = DateTime.Now;
            CreateDbData.Instance.IsUserQueryResolved = string.Empty;           
            listCreateDbData.Add(CreateDbData.Instance);
            context.ConversationData.SetValue(WSS.ChatBot.Common.Common.Conversation, listCreateDbData);
            
        }

        private static void CosmosSetBotDateTime()
        {
            //CreateDbData.Instance.User = Common.Bot;
            CreateDbData.Instance.Bot = Common.Bot;
            CreateDbData.Instance.UserRequestDatetime = DateTime.Now;
        }

        private static void CosmosSetUserDateTime(IDialogContext context)
        {
            CreateDbData.Instance.User = context.Activity.From.Name;
            CreateDbData.Instance.UserRequestDatetime = DateTime.Now;
        }
        private static void CosmosUserReplyData(IDialogContext context, string message)
        {
            CreateDbData.Instance.UserReply = message.ToString();
            CosmosSetUserDateTime(context: context);
        }
    }
}