﻿using System;

/// <summary>
/// Class holding the properties of cosmos db
/// </summary>

namespace WSS.ChatBot.Common
{
    [Serializable]
    public class CreateDbData
    {
        private static CreateDbData _instance;
         
        private CreateDbData() { }

        public static CreateDbData Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new CreateDbData();

                return _instance;
            }
        }

        // Your properties can then be whatever you want
        public  string User { get; set; }

        public  string UserReply { get; set; }

        public  DateTime UserRequestDatetime { get; set; }

        public  string Bot { get; set; }

        public  string BotResponse { get; set; }

        public string BotResponse2 { get; set; }

        public  DateTime BotResponseDatetime { get; set; }

        public string Intent { get; set; }

        public string IsUserQueryResolved { get; set; }

        public string Source { get; set; }

        public void Reset()
        {
            _instance = null;
        }

    }
    


}