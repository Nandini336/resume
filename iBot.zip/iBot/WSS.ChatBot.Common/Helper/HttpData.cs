﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ChatBot.Common;
using Dialogs.Luis;
using EasyHttp.Http;
using Entities;
using JSONUtils;
using Microsoft.Bot.Builder.Luis.Models;
using Newtonsoft.Json;

namespace Helper
{
    public class WebConfigurationManagerForBot : IWebConfigurationManagerForBot
    {
        public string LuisUrlPath { get; set; }
        public string LuisSearchParam { get; set; }
        public string LuisSubscriptionId { get; set; }
        public string AzureSubscriptionId { get; set; }

    }
    public class HttpData
    {
      
        public T GetDataFromHttpRequest<T>(string request)
        {
            dynamic bindDatatoProperty = null;
            //try
            //{
            var http = new HttpClient();
            http.Request.Accept = HttpContentTypes.ApplicationJson;

            var httpResponse = http.Get(request);
            if (httpResponse.StatusCode.ToString() != Constants.InternalServerError)
            {
                var httpResponseType = httpResponse.RawText;
                    //   httpResponseType = httpResponseType.Replace("[", "").Replace("]", "");
                    //var json = JsonConvert.SerializeObject(httpResponseType);

                    bindDatatoProperty = JsonConvert.DeserializeObject<T>(httpResponseType);
                    return bindDatatoProperty;               

            }
            else
            {
                return bindDatatoProperty;
            }
            //}
            //catch (Exception e)
            //{

            //    throw;
            //}
//return bindDatatoProperty;
        }

        public T GetSingleDataFromHttpRequest<T>(string request)
        {
            dynamic bindDatatoProperty = null;
            try
            {
                var http = new HttpClient();
                http.Request.Accept = HttpContentTypes.ApplicationJson;

                var httpResponse = http.Get(request);
                if (httpResponse.StatusCode.ToString() != Constants.InternalServerError)
                {
                    var httpResponseType = httpResponse.RawText;
                       httpResponseType = httpResponseType.Replace("[", "").Replace("]", "");
                    //var json = JsonConvert.SerializeObject(httpResponseType);

                    bindDatatoProperty = JsonConvert.DeserializeObject<T>(httpResponseType);
                    return bindDatatoProperty;

                }
                else
                {
                    return bindDatatoProperty;
                }
            }
            catch (Exception e)
            {

                throw;
            }
            //return bindDatatoProperty;
        }


        public static async Task<LUIS> GetLuisResult(LUIS luisResult, string luisQuery, WebConfigurationManagerForBot webConfigurationManagerForBot)
        {
            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Get key values from the web.config
                var luisUrl = webConfigurationManagerForBot.LuisUrlPath + "/" +
                    webConfigurationManagerForBot.LuisSubscriptionId + "?subscription-key=" +
                    webConfigurationManagerForBot.AzureSubscriptionId +
                    webConfigurationManagerForBot.LuisSearchParam;

                var requestUri = $"{luisUrl}q={luisQuery}";

                var msg = await client.GetAsync(requestUri);

                if (!msg.IsSuccessStatusCode)
                    return luisResult;

                var jsonDataResponse = await msg.Content.ReadAsStringAsync();

                luisResult = JsonConvert.DeserializeObject<LUIS>(jsonDataResponse);
            }

            return luisResult;
        }

        public static LUIS WithoutHttpCall(LuisResult result, IList<EntityRecommendation> entities)
        {
            LUIS lUIS = new LUIS();
            Intent intent = new Intent();
            intent.intent = result.Intents[0].Intent;
            IList<Intent> intents = new List<Intent>();
            IList<JSONUtils.Entity> lstEntity = new List<JSONUtils.Entity>();

            intents.Add(intent);

            foreach (var entity in entities)
            {
                JSONUtils.Entity jEntity = new JSONUtils.Entity();
                jEntity.entity = entity.Entity.ToString();
                lstEntity.Add(jEntity);
            }
            lUIS.intents = intents;
            lUIS.entities = lstEntity;

            return lUIS;
        }
    }   
}