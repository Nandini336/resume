﻿namespace Dialogs.Luis
{
    public static class Constants
    {
        public const string InternalServerError = "InternalServerError";
        public const string Yes = "Yes";
        public const string No = "No";
        public const string EmailYes = "Yes";
        public const string EmailNo = "No";
    }

    public partial class Luis
    {
        //public const string TestModelId = "ac687bf8-2977-429c-8292-08e61f466390";     
        //public const string TestSubscriptionId = "eac3571084c44c42aeca0c58eb07e14d";
        //public const string ProductionModelId = "68806d5a-dd61-42d6-a0f3-0f51807019f0";
        // public const string ProductionSubscriptionId = "d98fd0f03f2548229585d92994f4ebec";
        //public const string Domain = "southeastasia.api.cognitive.microsoft.com";

        public const string TestModelId = "5b32a666-1208-4210-93b9-ebcdcb940035";

        public const string ProductionModelId = "68806d5a-dd61-42d6-a0f3-0f51807019f0";

        public const string TestSubscriptionId = "0f14503ddf8448689cbe568edf1f89b3";

        public const string ProductionSubscriptionId = "d98fd0f03f2548229585d92994f4ebec";

        public const string Domain = "southeastasia.api.cognitive.microsoft.com";
    }

    public class Intents
    {
        public const string None = "None";
        public const string Greetings = "Greetings";
        public const string LearningStage = "LearningStage";
        public const string Bye = "Bye";
        public const string Order_Count = "Order_Count";
        public const string All_Orders = "All_Orders";
        public const string Order_Status = "Order_Status";
        public const string Heavy_Sludge = "Heavy_Sludge";
        public const string Show_Cylinders = "Show_Cylinders";
        public const string Cylinders_by_Vessel = "Cylinders_by_Vessel";
        public const string Cylinders_by_Type = "Cylinders_by_Type";
        public const string Refrigerants_F_gas = "Refrigerants_F-gas";
        public const string R404A_Price = "R404A_Price";
        public const string EasyClean_Window_And_Mirror = "EasyClean_Window_And_Mirror";
        public const string Easyclean_Oven_And_Grill = "Easyclean_Oven_And_Grill";
    }
}