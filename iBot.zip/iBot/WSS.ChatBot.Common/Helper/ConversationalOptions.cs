﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WSS.ChatBot.Common.Helper
{
    public static class ConversationalOptions
    {
        public const string Yes = "Yes";
        public const string No = "No";

        public static List<string> YesNo()
        {
            List<string> listYesNo = new List<string>();
            listYesNo.Add(Yes);
            listYesNo.Add(No);
            return listYesNo;
        }

        public const string CommonMessage = "Please choose one of the below options:\n\n ";

        //Heavy_Sludge options
        public const string IncompatibleFuel = "Incompatible fuels\n\n ";
        public const string HighWater = "High water content\n\n ";
        public const string Both = "Unstable asphaltenes\n\n ";
        public const string None = "Any other reason\n\n ";

        //Ropes Acerascott
        public const string AceraScottMadeOf = " What is Acera Scott made of?\n\n ";
        public const string AceraScott = " What is Acera Scott?\n\n ";
        public const string ApplicationAreas = "What kind of application areas has Acera Scott?\n\n ";

        public static List<string> RopesAcerascottModelCollection()
        {
            List<string> listAcerascottModel = new List<string>();
            listAcerascottModel.Add(AceraScottMadeOf);
            listAcerascottModel.Add(AceraScott);
            listAcerascottModel.Add(ApplicationAreas);
             return listAcerascottModel;
        }

        public static List<string> HeavySludgeModelCollection()
        {
            List<string> listHeavySludgeModel = new List<string>();
            listHeavySludgeModel.Add(IncompatibleFuel);
            listHeavySludgeModel.Add(HighWater);
            listHeavySludgeModel.Add(Both);
            listHeavySludgeModel.Add(None);
            return listHeavySludgeModel;
        }

        //Ropes_Certification options
        public const string RopeIdentificationNumber = "Do you have the rope identification number from the rope tag available?\n\n ";
        public const string RopeOrderNumber = "Do you have your WSS order number available?\n\n ";
        public const string RopeCertification = "Are you looking for more information about our ropes certificates?\n\n ";

        public static List<string> Ropes_CertificationModelCollection()
        {
            List<string> listRopes_Certification = new List<string>();
            listRopes_Certification.Add(RopeIdentificationNumber);
            listRopes_Certification.Add(RopeOrderNumber);
            listRopes_Certification.Add(RopeCertification);
            
            return listRopes_Certification;
        }

        //Rope_Accessories
        public const string MooringShackle = "Are you looking for Mooring Shackle?\n\n ";
        public const string RopeProtection = "Are you looking for Rope Protection?\n\n";
        public const string RopeRepairKit = "Are you looking for Rope Repair Kit?";


        public static List<string> Ropes_AccessoriesModelCollection()
        {
            List<string> listRopes_Accessories = new List<string>();
            listRopes_Accessories.Add(MooringShackle);
            listRopes_Accessories.Add(RopeRepairKit);
            listRopes_Accessories.Add(RopeProtection);
            return listRopes_Accessories;
        }

        public const string RopeAccessories3_1 = "What is Timm Chafe Guard made of?\n\n ";
        public const string RopeAccessories3_2 = "Where is Timm Chafe Guard produced?\n\n";
        public const string RopeAccessories3_3 = "How does the Timm Chafe Guard work?\n\n ";
        public const string RopeAccessories3_4 = "What color has Timm Chafe Guard?\n\n ";

        public static List<string> Ropes_Accessories3ModelCollection()
        {
            List<string> listRopes_Accessories3 = new List<string>();
            listRopes_Accessories3.Add(RopeAccessories3_1);
            listRopes_Accessories3.Add(RopeAccessories3_2);
            listRopes_Accessories3.Add(RopeAccessories3_3);
            listRopes_Accessories3.Add(RopeAccessories3_4);
            return listRopes_Accessories3;
        }

        //Ropes_Conventional_Nylon
        public const string nylonRopes = "Do you offer nylon mooring ropes?\n\n ";
        public const string nylonStretchers = "Do you offer nylon mooring stretchers?\n\n";
       

        public static List<string> Ropes_Conventional_NylonModelCollection()
        {
            List<string> listRopes_Nylon = new List<string>();
            listRopes_Nylon.Add(nylonRopes);
            listRopes_Nylon.Add(nylonStretchers);           
            return listRopes_Nylon;
        }

        public const string Ropes_Conventional_Nylon1_Option1 = "What is the reason for not having nylon mooring ropes?\n\n ";
        public const string Ropes_Conventional_Nylon1_Option2 = "Can we use Timm Master 8 onboard our vessel?\n\n";
        public const string Ropes_Conventional_Nylon1_Option3 = "How do we do a changeover from nylon to Timm Master 8?\n\n ";
       

        public static List<string> Ropes_Conventional_Nylon1_OptionsModelCollection()
        {
            List<string> Ropes_Conventional_Nylon1_Option = new List<string>();
            Ropes_Conventional_Nylon1_Option.Add(Ropes_Conventional_Nylon1_Option1);
            Ropes_Conventional_Nylon1_Option.Add(Ropes_Conventional_Nylon1_Option2);
            Ropes_Conventional_Nylon1_Option.Add(Ropes_Conventional_Nylon1_Option3);
            
            return Ropes_Conventional_Nylon1_Option;
        }

        public const string Ropes_Conventional_NylonOptions2_1 = "Why is there a problem in mixing nylon with Timm Master 8?\n\n ";
        public const string Ropes_Conventional_NylonOptions2_2 = "How do we do a changeover from nylon to Timm Master 8?\n\n";


        public static List<string> Ropes_Conventional_NylonOptions2_ModelCollection()
        {
            List<string> Ropes_Conventional_NylonOptions2 = new List<string>();
            Ropes_Conventional_NylonOptions2.Add(Ropes_Conventional_NylonOptions2_1);
            Ropes_Conventional_NylonOptions2.Add(Ropes_Conventional_NylonOptions2_2);
            return Ropes_Conventional_NylonOptions2;
        }

        //Ropes_Main
        public const string RopesMain1 = "Are you looking for conventional mooring ropes?\n\n ";
        public const string RopesMain2 = "Are you looking for advanced mooring ropes with double braided construction?\n\n";
        public const string RopesMain3 = "Are you looking for high performance ropes, with the same strength as steel wire, but 1/7th of the weight?\n\n";
        public const string RopesMain4 = "Are you looking for mooring stretchers, to be used together with high performance ropes or steel wire ropes?\n\n ";

        public static List<string> Ropes_MainModelCollection()
        {
            List<string> listRopes_Main = new List<string>();
            listRopes_Main.Add(RopesMain1);
            listRopes_Main.Add(RopesMain2);
            listRopes_Main.Add(RopesMain3);
            listRopes_Main.Add(RopesMain4);
            return listRopes_Main;
        }


        public const string RopesMain3_Option1 = "What are the Acera ropes made of?\n\n ";
        public const string RopesMain3_Option2 = "What is the cover of Acera daGama made of?\n\n";
        public const string RopesMain3_Option3 = "The crew feels uncomfortable to use so small diameter on the mooring rope. Do you offer HMPE ropes with bigger diameter, but same strength as lower diameters?\n\n ";
        public const string RopesMain3_Option4 = "Can we use Acera ropes in terminals with HMPE requirements.";

        public static List<string> RopesMain3ModelCollection()
        {
            List<string> listRopes_Main3 = new List<string>();
            listRopes_Main3.Add(RopesMain3_Option1);
            listRopes_Main3.Add(RopesMain3_Option2);
            listRopes_Main3.Add(RopesMain3_Option3);
            listRopes_Main3.Add(RopesMain3_Option4);
            return listRopes_Main3;
        }

        public const string RopesMain3_Option1_1 = "Where do you produce the Acera HMPE ropes?\n\n ";
        public const string RopesMain3_Option1_2 = "What certification do you have for your Acera HMPE ropes?";
        public static List<string> RopesMain3_Option1ModelCollection()
        {
            List<string> listRopes_Main3_Option1 = new List<string>();
            listRopes_Main3_Option1.Add(RopesMain3_Option1_1);
            listRopes_Main3_Option1.Add(RopesMain3_Option1_2);            
            return listRopes_Main3_Option1;
        }

        //Ropes_PanamCanal
        public const string PanamaCanal1 = "What kind of ropes are not accepted when passing the Panama Canal?\n\n ";
        public const string PanamaCanal2 = "What specific fiber rope requirement is stated in the Vessel Requirement from Panama Canal?\n\n";

        public static List<string> PanamaCanalModelCollection()
        {
            List<string> listPanamaCanal = new List<string>();
            listPanamaCanal.Add(PanamaCanal1);
            listPanamaCanal.Add(PanamaCanal2);
            return listPanamaCanal;
        }
        //Ropes_Stretcher
        public const string Ropes_Stretcher_1 = "Are you looking for a stretcher for steel wire or HMPE rope?\n\n ";
        public const string Ropes_Stretcher_2 = "Are you looking for blue stretchers for a cruise vessel?\n\n ";
        public const string Ropes_Stretcher_3 = "Are you looking for a polypropylene (PP) stretcher?\n\n";
        public const string Ropes_Stretcher_4 = "Are you looking for a nylon stretcher?\n\n";

        // MeasuringDiameter 
        public const string MeasuringDiameter1 = "How to measure diameter of 8 strand rope?\n\n ";
        public const string MeasuringDiameter2 = "How to measure diameter of 12 strand rope?\n\n";
        public const string MeasuringDiameter3 = "How to measure diameter of double braided ropes?";
        public static List<string> MeasuringDiameterModelCollection()
        {
            List<string> listMeasuringDiameter = new List<string>();
            listMeasuringDiameter.Add(MeasuringDiameter1);
            listMeasuringDiameter.Add(MeasuringDiameter2);
            listMeasuringDiameter.Add(MeasuringDiameter3);
            return listMeasuringDiameter;
        }
        public static List<string> Ropes_StretcherModelCollection()
        {
            List<string> Ropes_Stretcher = new List<string>();
            Ropes_Stretcher.Add(Ropes_Stretcher_1);
            Ropes_Stretcher.Add(Ropes_Stretcher_2);
            Ropes_Stretcher.Add(Ropes_Stretcher_3);
            Ropes_Stretcher.Add(Ropes_Stretcher_4);
            return Ropes_Stretcher;
        }

        public const string Ropes_Stretcher_Option1 = "Are you looking for a mixed composition or polypropylene (PP) tail?\n\n ";
        public const string Ropes_Stretcher_Option2 = "Are you looking for a nylon tail?\n\n";
        public const string Ropes_Stretcher_Option3 = "Are you looking for a ringtail or endless loop";

        public static List<string> Ropes_Stretcher_Option1ModelCollection()
        {
            List<string> Ropes_Stretcher_1 = new List<string>();
            Ropes_Stretcher_1.Add(Ropes_Stretcher_Option1);
            Ropes_Stretcher_1.Add(Ropes_Stretcher_Option2);
            Ropes_Stretcher_1.Add(Ropes_Stretcher_Option3);
           
            return Ropes_Stretcher_1;
        }

        //Ropes_TCLL

        public const string Ropes_TCLL_1 = "What is TCLL testing?\n\n ";
        public const string Ropes_TCLL_2 = "What is wrong with TCLL testing?";

        public static List<string> Ropes_TCLLModelCollection()
        {
            List<string> Ropes_TCLL = new List<string>();
            Ropes_TCLL.Add(Ropes_TCLL_1);
            Ropes_TCLL.Add(Ropes_TCLL_2);        

            return Ropes_TCLL;
        }

        //Ropes_TimmMaster8
        public const string Ropes_TimmMaster8_1 = "What is Timm Master 8 made of?\n\n ";
        public const string Ropes_TimmMaster8_2 = "What are the eye specifications for this rope ?";

        public static List<string> Ropes_TimmMaster8ModelCollection()
        {
            List<string> Ropes_TimmMaster8 = new List<string>();
            Ropes_TimmMaster8.Add(Ropes_TimmMaster8_1);
            Ropes_TimmMaster8.Add(Ropes_TimmMaster8_2);

            return Ropes_TimmMaster8;
        }

        //Ropes_DalrympleBay
        public const string RopesDalrympleBay1 = "Vessel DWT : 40 - 65 000 tonnes\n\n ";
        public const string RopesDalrympleBay2 = "Vessel DWT : 65 - 95 000 tonnes\n\n";
        public const string RopesDalrympleBay3 = "Vessel DWT : 95 - 125 000 tonnes\n\n";
        public const string RopesDalrympleBay4 = "Vessel DWT : 125 - 155 000 tonnes\n\n";
        public const string RopesDalrympleBay5 = "Vessel DWT : 155 - 220 00 tonnes";

        public static List<string> Ropes_DalrympleBay()
        {
            List<string> list = new List<string>();
            list.Add(RopesDalrympleBay1);
            list.Add(RopesDalrympleBay2);
            list.Add(RopesDalrympleBay3);
            list.Add(RopesDalrympleBay4);
            list.Add(RopesDalrympleBay5);
            return list;
        }

        //Ropes_Conventional
        public const string Ropes_Conventional_1 = "Bulk vessel\n\n ";
        public const string Ropes_Conventional_2 = "Cruise vessel \n\n ";
        public const string Ropes_Conventional_3 = "Container vessel\n\n ";
        public const string Ropes_Conventional_4 = "Tanker vessel\n\n ";
        public static List<string> Ropes_ConventionalModelCollection()
        {
            List<string> Ropes_Conventional = new List<string>();
            Ropes_Conventional.Add(Ropes_Conventional_1);
            Ropes_Conventional.Add(Ropes_Conventional_2);
            Ropes_Conventional.Add(Ropes_Conventional_3);
            Ropes_Conventional.Add(Ropes_Conventional_4);

            return Ropes_Conventional;
        }
        //RopeMixType
        public const string RopeMixType1 = "Can we use different diameters on the mooring ropes onboard a vessel?\n\n ";
        public const string RopeMixType2 = "Can we use different MBLs on the mooring ropes onboard a vessel?\n\n";
        public const string RopeMixType3 = "Can I use ropes of different material on the mooring ropes onboard a vessel?";
        public static List<string> RopeMixTypeModelCollection()
        {
            List<string> list = new List<string>();
            list.Add(RopeMixType1);
            list.Add(RopeMixType2);
            list.Add(RopeMixType3);
            return list;
        }

        //RopesConventionalPolyPropylene
        public const string RopesConventionalPolyPropylene_1 = "Are you currently using polypropyelene (PP) ropes?\n\n ";
        public const string RopesConventionalPolyPropylene_2 = "Are you looking for conventional mooring ropes?";
        public static List<string> RopesConventionalPolyPropyleneModelCollection()
        {
            List<string> RopesConventionalPolyPropylene = new List<string>();
            RopesConventionalPolyPropylene.Add(RopesConventionalPolyPropylene_1);
            RopesConventionalPolyPropylene.Add(RopesConventionalPolyPropylene_2);

            return RopesConventionalPolyPropylene;
        }

        public const string Ropes_Conventional_Polypropylene_Option1_1 = "What are the benefits of changing from PP ropes to TImm Master ropes?\n\n ";
        public const string Ropes_Conventional_Polypropylene_Option1_2 = "Are you using the ropes on a cruise vessel?";
        public static List<string> Ropes_Conventional_Polypropylene_Option1ModelCollection()
        {
            List<string> Ropes_Conventional_Polypropylene_Option1 = new List<string>();
            Ropes_Conventional_Polypropylene_Option1.Add(Ropes_Conventional_Polypropylene_Option1_1);
            Ropes_Conventional_Polypropylene_Option1.Add(Ropes_Conventional_Polypropylene_Option1_2);

            return Ropes_Conventional_Polypropylene_Option1;
        }


        //R448A_R449A_Availability
        public const string Replenish = " Replenish\n\n ";
        public const string Replace = " Replace\n\n";
        public const string Nooption = "No option";

        public static List<string> R448A_R449A_AvailabilityModelCollection()
        {
            List<string> listR448A_R449A_Availability = new List<string>();
            listR448A_R449A_Availability.Add(Replenish);
            listR448A_R449A_Availability.Add(Replace);
            listR448A_R449A_Availability.Add(Nooption);
            return listR448A_R449A_Availability;
        }

        //R22_Replace
        public const string EUFlag = "Is your ship carrying EU flag?\n\n ";
        public const string NonArticle = " Is your ship carrying flag of Non - Article 5 Countries(e.g.Japan, Australia, USA).\n\n";
        public const string Article = "Is your ship carrying flag of Article 5 Countries(e.g.China, Korea, Panama, Singapore)";

        public static List<string> R22_ReplaceModelCollection()
        {
            List<string> listR22_Replace = new List<string>();
            listR22_Replace.Add(EUFlag);
            listR22_Replace.Add(NonArticle);
            listR22_Replace.Add(Article);
            return listR22_Replace;
        }

        //Air_Hose 
        public const string Rubber = "Rubber reinforced hose .\n\n ";
        public const string PVC = "PVC reinforced hose .\n\n";
       
        public static List<string> Air_HoseModelCollection()
        {
            List<string> listAir_Hose = new List<string>();
            listAir_Hose.Add(Rubber);
            listAir_Hose.Add(PVC);
            
            return listAir_Hose;
        }

        //Air_Hose_Clamp
        public const string Hose = "Hose clamp\n\n ";
        public const string Ear = "Ear clamp\n\n";

        public static List<string> Air_Hose_ClampModelCollection()
        {
            List<string> listAir_Hose_Clamp = new List<string>();
            listAir_Hose_Clamp.Add(Hose);
            listAir_Hose_Clamp.Add(Ear);

            return listAir_Hose_Clamp;
        }

        //Air_Hose_Clamp
        public const string Deck_Scaler = "Deck scaler is ideally suited for thick coating removal and surface preparation on large areas of desk and tank floor cleaning.\n\n ";
        public const string Deck_Planner = "Deck planner is a rugged rotary planner unit suitable for rapidly removing scale,rust and paint.\n\n";

        public static List<string> Air_Deck_ScalerModelCollection()
        {
            List<string> listAir_Deck_Scaler = new List<string>();
            listAir_Deck_Scaler.Add(Deck_Scaler);
            listAir_Deck_Scaler.Add(Deck_Planner);

            return listAir_Deck_Scaler;
        }

        //Air_Angle_Grinder
        public const string Pneumatic = "Pneumatic series of angle grinder is designed to cope with daily task within the tough marine environment. Each unit is fully tested for reliability and endurance.\n\n ";
        public const string Cutting_grinding = "Cutting and grinding disc for Unitor angle grinder.\n\n";
        public const string MopDisk = "Mop disc for Unitor angle grinder.\n\n ";
        public const string SandingDisk = "Sanding disc for Unitor angle grinder.\n\n";
        public const string InoxCutting = "INOX cutting disc and grinding disc.\n\n ";
      
        public static List<string> Air_Angle_GrinderModelCollection()
        {
            List<string> listAir_Angle_Grinder = new List<string>();
            listAir_Angle_Grinder.Add(Pneumatic);
            listAir_Angle_Grinder.Add(Cutting_grinding);
            listAir_Angle_Grinder.Add(MopDisk);
            listAir_Angle_Grinder.Add(SandingDisk);
            listAir_Angle_Grinder.Add(InoxCutting);

            return listAir_Angle_Grinder;
        }

        //Welding_Wire
        public const string aluminium = "Wire welding of aluminium alloys.\n\n ";
        public const string structural_steels = "Wire welding of structural steels.\n\n";
        public const string stainless_steel = "Wire welding of stainless steel.\n\n ";
        public const string nickel_alloy = "Wire welding of copper nickel alloy (Cunifer) pipe.\n\n";
        public const string aluminium_alloy = "Wire welding of copper aluminium alloy (Yorcalbro) pipes.";

        public static List<string> Welding_WireModelCollection()
        {
            List<string> listWelding_Wire = new List<string>();
            listWelding_Wire.Add(aluminium);
            listWelding_Wire.Add(structural_steels);
            listWelding_Wire.Add(stainless_steel);
            listWelding_Wire.Add(nickel_alloy);
            listWelding_Wire.Add(aluminium_alloy);

            return listWelding_Wire;
        }

        //Welding_Cylinder_Trolley
        public const string a_40Cylinder = "Trolley for A-40/O-40 cylinders\n\n ";
        public const string oneCylinder = "Trolley for one cylinder SU-10\n\n";
        public const string a_5Cylinder = "Trolley for 5L cylinder model A-5/O-5.\n\n ";
       
        public static List<string> Welding_Cylinder_TrolleyModelCollection()
        {
            List<string> listWelding_Cylinder_Trolley = new List<string>();
            listWelding_Cylinder_Trolley.Add(a_40Cylinder);
            listWelding_Cylinder_Trolley.Add(oneCylinder);
            listWelding_Cylinder_Trolley.Add(a_5Cylinder);
           

            return listWelding_Cylinder_Trolley;
        }

        //Ropes_Conditions
        public const string towing = "Can we use mooring ropes for towing?\n\n ";
        public const string ropeCare = "What rope care instructions applies for mooring ropes in general?\n\n";
        
        public static List<string> Ropes_ConditionsModelCollection()
        {
            List<string> listRopes_Conditions = new List<string>();
            listRopes_Conditions.Add(towing);
            listRopes_Conditions.Add(ropeCare);
            

            return listRopes_Conditions;
        }

        //Air_tools_impact_wrench
        public const string AiImpactWrenchMessage= "Unitor impact wrench comes in 3 different sizes.\n\n\n\n" +
                 "Please choose one of the below option to know in detail  \n\n ";
        public const string M12 = "IW-PRO 1/2' well balance tool for bolt up to size M12 \n\n ";
        public const string M22 = "IW-PRO 3/4' well balance tool for bolt up to size M22 \n\n";
        public const string M30 = "IW-PRO 1/2' well balance tool for bolt up to size M30 \n\n";

        public static List<string> Air_tools_impact_wrenchModelCollection()
        {
            List<string> listAir_tools_impact_wrench = new List<string>();
            listAir_tools_impact_wrench.Add(M12);
            listAir_tools_impact_wrench.Add(M22);
            listAir_tools_impact_wrench.Add(M30);

            return listAir_tools_impact_wrench;
        }

        //Air_Distributor
        public const string FRLUnit = "Airline filter/regulator/lubricator unit\n\n ";
        public const string Mendusa = "Air distributor Mendusa\n\n";

        public static List<string> Air_DistributorModelCollection()
        {
            List<string> listAir_Distributor = new List<string>();
            listAir_Distributor.Add(FRLUnit);
            listAir_Distributor.Add(Mendusa);


            return listAir_Distributor;
        }

        //Air_tools_quick_coupling
        public const string socketSeries = "Stainless quick coupling Socket series.\n\n ";
        public const string plusSeries = "Stainless quick coupling Plus series.\n\n";

        public static List<string> Air_tools_quick_couplingModelCollection()
        {
            List<string> listAir_tools_quick_coupling = new List<string>();
            listAir_tools_quick_coupling.Add(socketSeries);
            listAir_tools_quick_coupling.Add(plusSeries);


            return listAir_tools_quick_coupling;
        }

        public const string USM_Option1 = "Stainless quick coupling Unitor Socket Male (USM)\n\n ";
        public const string USF_Option2 = "Stainless quick coupling Unitor Socket Female (USF)\n\n";
        public const string USH_Option3 = "Stainless quick coupling Unitor Socket Hose (USH)\n\n ";
       
        public static List<string> Air_tools_quick_coupling1ModelCollection()
        {
            List<string> listAir_tools_quick_coupling1 = new List<string>();
            listAir_tools_quick_coupling1.Add(USM_Option1);
            listAir_tools_quick_coupling1.Add(USF_Option2);
            listAir_tools_quick_coupling1.Add(USH_Option3);
           
            return listAir_tools_quick_coupling1;
        }

        public const string UPH_Option1 = "Stainless quick coupling Unitor Plug Hose (UPH)\n\n ";
        public const string UPM_Option2 = "Stainless quick coupling Unitor Plug Male (UPM)\n\n";
        public const string UPF_Option3 = "	Stainless quick coupling Unitor Plug Female (UPF)\n\n ";

        public static List<string> Air_tools_quick_coupling2ModelCollection()
        {
            List<string> listAir_tools_quick_coupling2 = new List<string>();
            listAir_tools_quick_coupling2.Add(UPH_Option1);
            listAir_tools_quick_coupling2.Add(UPM_Option2);
            listAir_tools_quick_coupling2.Add(UPF_Option3);

            return listAir_tools_quick_coupling2;
        }

        //Welding_Electrode_Competitor
        public const string AWS_E6013 = "General purpose electrodes for mild steel with AWS classification code E6013.\n\n ";
        public const string AWS_E7024 = "High recovery electrodes for mild steel with AWS classification code E7024.\n\n";
        
        public static List<string> Welding_Electrode_CompetitorModelCollection()
        {
            List<string> listWelding_Electrode_Competitor = new List<string>();
            listWelding_Electrode_Competitor.Add(AWS_E6013);
            listWelding_Electrode_Competitor.Add(AWS_E7024);
           
            return listWelding_Electrode_Competitor;
        }

        // Welding_Electrode_Competitor_1
        public const string AWS_E7018 = "Low hydrogen electrode for ship quality steel with AWS classification code E7018.\n\n ";
        public const string AWS_E7016 = "Double costed electrode for welding of mild steel and ship quality steel with AWS classification code E7016.\n\n";
        public const string AWS_E7028 = "High recovery low hydrogen electrode for ship quality steel with AWS classification code E7028.\n\n";
        public const string AWS_E8018_G = "Vertical down welding low hydrogen electrodes for ship quality steel with AWS classification code E8018-G.\n\n";
        public const string AWS_E8018_B2 = "Electrode for welding high temperature steel with AWS classification code E8018-B2\n\n";

     

        public static List<string> Welding_Electrode_Competitor_1ModelCollection()
        {
            List<string> listWelding_Electrode_Competitor1 = new List<string>();
            listWelding_Electrode_Competitor1.Add(AWS_E7018);
            listWelding_Electrode_Competitor1.Add(AWS_E7016);
            listWelding_Electrode_Competitor1.Add(AWS_E7028);
            listWelding_Electrode_Competitor1.Add(AWS_E8018_G);
            listWelding_Electrode_Competitor1.Add(AWS_E8018_B2);

            return listWelding_Electrode_Competitor1;
        }


        // Welding_Electrode_Competitor_2
        public const string AWS_E8018_C1 = "Electrode for welding low temperature steel with AWS classification code E8018-C1.\n\n ";
        public const string E8018_G = "Electrode for welding weathering steel with AWS classification code E8018-G.\n\n";
        public const string AWS_E312_17 = "Electrode for welding difficult to weld steel with AWS classification code E312-17.\n\n";
        public const string AWS_E20_UM_250_CRTZ = "Electrode for welding heat resistant overlays with AWS classification code E20-UM-250-CRTZ.\n\n";
        public const string AWS_E307_26 = "Electrode for welding wear resistant overlays with SAW classification code E307-26.\n\n";



        public static List<string> Welding_Electrode_Competitor_2ModelCollection()
        {
            List<string> listWelding_Electrode_Competitor2 = new List<string>();
            listWelding_Electrode_Competitor2.Add(AWS_E8018_C1);
            listWelding_Electrode_Competitor2.Add(E8018_G);
            listWelding_Electrode_Competitor2.Add(AWS_E312_17);
            listWelding_Electrode_Competitor2.Add(AWS_E20_UM_250_CRTZ);
            listWelding_Electrode_Competitor2.Add(AWS_E307_26);

            return listWelding_Electrode_Competitor2;
        }

        // Welding_Electrode_Competitor_3
        public const string AWS_E316L_17 = "Electrode for welding stainless steel with AWS classification E316L-17.\n\n ";
        public const string AWS_E309Mol_17 = "Electrode for welding stainless steel to mild steel with AWS classification E309Mol-17.\n\n";
        public const string AWS_E2209_17 = "Electrode for welding duplex steel with AWS classification E2209-17.\n\n";
        public const string pickingGelSteel = "Pickling gel for stainless steel.\n\n";
       
        public static List<string> Welding_Electrode_Competitor_3ModelCollection()
        {
            List<string> listWelding_Electrode_Competitor3 = new List<string>();
            listWelding_Electrode_Competitor3.Add(AWS_E316L_17);
            listWelding_Electrode_Competitor3.Add(AWS_E309Mol_17);
            listWelding_Electrode_Competitor3.Add(AWS_E2209_17);
            listWelding_Electrode_Competitor3.Add(pickingGelSteel);
            
            return listWelding_Electrode_Competitor3;
        }

        // Welding_Electrode_Competitor_4
        public const string oilyCastIron = "Electrode for welding oily cast iron.\n\n ";
        public const string diffCastIron = "Electrode for welding different type of cast iron example nodular iron, malleable cast irong and grey cast iron.\n\n";
       
        public static List<string> Welding_Electrode_Competitor_4ModelCollection()
        {
            List<string> listWelding_Electrode_Competitor4 = new List<string>();
            listWelding_Electrode_Competitor4.Add(oilyCastIron);
            listWelding_Electrode_Competitor4.Add(diffCastIron);
           
            return listWelding_Electrode_Competitor4;
        }

        // Welding_Electrode_Competitor_5
        public const string tinBronze = "Electrode for welding of tin bronze to brass as well as welding these material to steel and cast iron.\n\n ";
        public const string bronzeAlloy = "Electrode for welding of bronze alloy as well as welding these material to steel and cast iron.\n\n";
      
        public static List<string> Welding_Electrode_Competitor_5ModelCollection()
        {
            List<string> listWelding_Electrode_Competitor5 = new List<string>();
            listWelding_Electrode_Competitor5.Add(tinBronze);
            listWelding_Electrode_Competitor5.Add(bronzeAlloy);
           
            return listWelding_Electrode_Competitor5;
        }

        // Welding_Electrode_Competitor_6
        public const string weldingSeam = "Electrode for removing welding seam.\n\n ";
        public const string aluminiumMaterial = "Electrode for welding aluminium material.\n\n";
       
        public static List<string> Welding_Electrode_Competitor_6ModelCollection()
        {
            List<string> listWelding_Electrode_Competitor6 = new List<string>();
            listWelding_Electrode_Competitor6.Add(weldingSeam);
            listWelding_Electrode_Competitor6.Add(aluminiumMaterial);
            
            return listWelding_Electrode_Competitor6;
        }

        // Welding_Open_Circuit_Voltage
        public const string guideLineOCV = "Guide line for open circuit voltage.\n\n ";
        public const string unitorWeldingOCV = "Unitor welding machine open circuit voltage.\n\n";
        public const string OCV = "What is open circuit voltage.\n\n";

        public static List<string> Welding_Open_Circuit_VoltageModelCollection()
        {
            List<string> listWelding_Open_Circuit_Voltage = new List<string>();
            listWelding_Open_Circuit_Voltage.Add(guideLineOCV);
            listWelding_Open_Circuit_Voltage.Add(unitorWeldingOCV);
            listWelding_Open_Circuit_Voltage.Add(OCV);

            return listWelding_Open_Circuit_Voltage;
        }

        // Welding_Plasma_Machine
        public const string UPC_310ML = "Single phase plasma cutting machine UPC-310ML.	\n\n ";
        public const string UPC_1041TP = "Three phase plasma cutting machine UPC-1041TP.\n\n";
      
        public static List<string> Welding_Plasma_MachineModelCollection()
        {
            List<string> listWelding_Plasma_Machine = new List<string>();
            listWelding_Plasma_Machine.Add(UPC_310ML);
            listWelding_Plasma_Machine.Add(UPC_1041TP);
           
            return listWelding_Plasma_Machine;
        }

        // Welding_Plasma_Machine_1
        public const string Acc_UPC_310TP = "	Accessories for UPC-310TP\n\n ";
        public const string Acc_UPC_310ML = "	Accessories for UPC-310ML.\n\n";
        public const string Acc_UPC_1041 = "	Accessories for UPC-1041/UPC-1041TP.\n\n";
      

        public static List<string> Welding_Plasma_Machine_1ModelCollection()
        {
            List<string> listWelding_Plasma_Machine_1 = new List<string>();
            listWelding_Plasma_Machine_1.Add(Acc_UPC_310TP);
            listWelding_Plasma_Machine_1.Add(Acc_UPC_310ML);
            listWelding_Plasma_Machine_1.Add(Acc_UPC_1041);
           
            return listWelding_Plasma_Machine_1;
        }


        // Welding_Regulator_Oxygen_Acetylene
        public const string OxygenandAcetylene = "Regulator for oxygen and acetylene gas.\n\n ";
        public const string regFun = "Regulator function.\n\n";
        public const string regServicing = "Repair or servicing a regulator.\n\n";
        
        public static List<string> Welding_Regulator_Oxygen_AcetyleneModelCollection()
        {
            List<string> listWelding_Regulator_Oxygen_Acetylene = new List<string>();
            listWelding_Regulator_Oxygen_Acetylene.Add(OxygenandAcetylene);
            listWelding_Regulator_Oxygen_Acetylene.Add(regFun);
            listWelding_Regulator_Oxygen_Acetylene.Add(regServicing);
           
            return listWelding_Regulator_Oxygen_Acetylene;
        }

        public const string Welding_Regulator_Oxygen_Acetylene_3_1 = "Recommended replacement period for a regulator?\n\n ";
        public const string Welding_Regulator_Oxygen_Acetylene_3_2 = "Replacing working gauge and content gauge?\n\n";
        public const string Welding_Regulator_Oxygen_Acetylene_3_3 = "What are the differences in oxygen gauges and acetylene gauges?\n\n";

        public static List<string> Welding_Regulator_Oxygen_Acetylene_3ModelCollection()
        {
            List<string> listWelding_Regulator_Oxygen_Acetylene_3 = new List<string>();
            listWelding_Regulator_Oxygen_Acetylene_3.Add(Welding_Regulator_Oxygen_Acetylene_3_1);
            listWelding_Regulator_Oxygen_Acetylene_3.Add(Welding_Regulator_Oxygen_Acetylene_3_2);
            listWelding_Regulator_Oxygen_Acetylene_3.Add(Welding_Regulator_Oxygen_Acetylene_3_3);

            return listWelding_Regulator_Oxygen_Acetylene_3;
        }
        public const string Welding_Regulator_Oxygen_Acetylene_1_1 = "Regulator for stand along oxygen and acetylene cylinder.\n\n ";
        public const string Welding_Regulator_Oxygen_Acetylene_1_2 = "Regulator for use in gas outlet station.\n\n";
        public const string Welding_Regulator_Oxygen_Acetylene_1_3 = " Regulator for gas cylinder storage.\n\n";

        public static List<string> Welding_Regulator_Oxygen_Acetylene_1ModelCollection()
        {
            List<string> listWelding_Regulator_Oxygen_Acetylene_1 = new List<string>();
            listWelding_Regulator_Oxygen_Acetylene_1.Add(Welding_Regulator_Oxygen_Acetylene_1_1);
            listWelding_Regulator_Oxygen_Acetylene_1.Add(Welding_Regulator_Oxygen_Acetylene_1_2);
            listWelding_Regulator_Oxygen_Acetylene_1.Add(Welding_Regulator_Oxygen_Acetylene_1_3);

            return listWelding_Regulator_Oxygen_Acetylene_1;
        }

        //Welding_Flashback_Arrestor
        public const string Welding_Flashback_Arrestor_1 = "Unitor range of flashback arrestor.	\n\n ";
        public const string Welding_Flashback_Arrestor_2 = "Protection devices for Unitor flashback arrestor.\n\n";
        

        public static List<string> Welding_Flashback_ArrestorModelCollection()
        {
            List<string> listWelding_Flashback_Arrestor = new List<string>();
            listWelding_Flashback_Arrestor.Add(Welding_Flashback_Arrestor_1);
            listWelding_Flashback_Arrestor.Add(Welding_Flashback_Arrestor_2);           

            return listWelding_Flashback_Arrestor;
        }

        public const string Welding_Flashback_Arrestor_1_1 = "Which flashback arrestor should i use for outlet station?	\n\n ";
        public const string Welding_Flashback_Arrestor_1_2 = "Which flashback arrestor should i use for stationary gas cylinder?\n\n";
        public const string Welding_Flashback_Arrestor_1_3 = "Which flashback arrestor should i use for gas distribution system/cylinder storage central?\n\n";

        public static List<string> Welding_Flashback_Arrestor_1_1ModelCollection()
        {
            List<string> listWelding_Flashback_Arrestor_1 = new List<string>();
            listWelding_Flashback_Arrestor_1.Add(Welding_Flashback_Arrestor_1_1);
            listWelding_Flashback_Arrestor_1.Add(Welding_Flashback_Arrestor_1_2);
            listWelding_Flashback_Arrestor_1.Add(Welding_Flashback_Arrestor_1_3);

            return listWelding_Flashback_Arrestor_1;
        }

        public const string Welding_Flashback_Arrestor_2_1 = "What are the protection mechanism for FR-20 flashback arrestor?\n\n ";
        public const string Welding_Flashback_Arrestor_2_2 = "What are the protection mechanism for W-66 flashback arrestor?\n\n";
        public const string Welding_Flashback_Arrestor_2_3 = "What are the protection mechanism for S-55 flashback arrestor?\n\n";
        public const string Welding_Flashback_Arrestor_2_4 = "What are the protection mechanism for 85-10 flashback arrestor?\n\n";

        public static List<string> Welding_Flashback_Arrestor_2_1ModelCollection()
        {
            List<string> listWelding_Flashback_Arrestor_2 = new List<string>();
            listWelding_Flashback_Arrestor_2.Add(Welding_Flashback_Arrestor_2_1);
            listWelding_Flashback_Arrestor_2.Add(Welding_Flashback_Arrestor_2_2);
            listWelding_Flashback_Arrestor_2.Add(Welding_Flashback_Arrestor_2_3);
            listWelding_Flashback_Arrestor_2.Add(Welding_Flashback_Arrestor_2_4);

            return listWelding_Flashback_Arrestor_2;
        }

        //Welding_Machine_1
        public const string Welding_Machine_1_1 = "Welding machine operating on 110V power supply. \n\n";
        public const string Welding_Machine_1_2 = "Welding machine operating on 230V power supply.\n\n";
        public const string Welding_Machine_1_3 = "Welding machine operating on 400/440V power supply.\n\n";


        public static List<string> Welding_Machine_1ModelCollection()
        {
            List<string> listWelding_Machine_1 = new List<string>();
            listWelding_Machine_1.Add(Welding_Machine_1_1);
            listWelding_Machine_1.Add(Welding_Machine_1_2);
            listWelding_Machine_1.Add(Welding_Machine_1_3);
            return listWelding_Machine_1;
        }

        public const string Welding_Machine_1_3_1 = "UWI-203TP welding machine. \n\n";
        public const string Welding_Machine_1_3_2 = "UWI-320TP welding machine. \n\n";
        public const string Welding_Machine_1_3_3 = "UWI-500TP welding machine. \n\n";


        public static List<string> Welding_Machine_1_3ModelCollection()
        {
            List<string> listWelding_Machine_1_3 = new List<string>();
            listWelding_Machine_1_3.Add(Welding_Machine_1_3_1);
            listWelding_Machine_1_3.Add(Welding_Machine_1_3_2);
            listWelding_Machine_1_3.Add(Welding_Machine_1_3_3);
            return listWelding_Machine_1_3;
        }

        //Welding_Oxygen_Acetylene_Gas_Hoses
        public const string Welding_Oxygen_Acetylene_Gas_Hoses_1 = "Gas welding hoses for oxygen and acetylene line. \n\n";
        public const string Welding_Oxygen_Acetylene_Gas_Hoses_2 = "Gas hoses for individual Oxygen and Acetylene line. \n\n";
        

        public static List<string> Welding_Oxygen_Acetylene_Gas_HosesModelCollection()
        {
            List<string> listWelding_Oxygen_Acetylene_Gas_Hoses = new List<string>();
            listWelding_Oxygen_Acetylene_Gas_Hoses.Add(Welding_Oxygen_Acetylene_Gas_Hoses_1);
            listWelding_Oxygen_Acetylene_Gas_Hoses.Add(Welding_Oxygen_Acetylene_Gas_Hoses_2);
            return listWelding_Oxygen_Acetylene_Gas_Hoses;
        }

        public const string Welding_Oxygen_Acetylene_Gas_Hoses_1_1 = "Gas hoses with fix length and fittings on both ends. \n\n";
        public const string Welding_Oxygen_Acetylene_Gas_Hoses_1_2 = "Twin gas hose for Oxygen and Acetylene. \n\n";

        public static List<string> Welding_Oxygen_Acetylene_Gas_Hoses_1ModelCollection()
        {
            List<string> listWelding_Oxygen_Acetylene_Gas_Hoses_1 = new List<string>();
            listWelding_Oxygen_Acetylene_Gas_Hoses_1.Add(Welding_Oxygen_Acetylene_Gas_Hoses_1_1);
            listWelding_Oxygen_Acetylene_Gas_Hoses_1.Add(Welding_Oxygen_Acetylene_Gas_Hoses_1_2);
            return listWelding_Oxygen_Acetylene_Gas_Hoses_1;
        }

        //Welding_Rod
        public const string Welding_Rod_1 = "TIG welding rod for welding of unalloyed and low alloy steel. Also recommended for welding of high tensile steel.\n\n";
        public const string Welding_Rod_2 = "TIG welding rod for welding of low apply and hydrogen resistant Chrome Molybdenum steel. Also recommend for welding of high tensile steel. \n\n";
        public const string Welding_Rod_3 = "TIG welding rod for welding of stainless steel 316L. \n\n";
        public const string Welding_Rod_4 = "TIG welding rob for duplex stainless steel. \n\n";
        public const string Welding_Rod_5 = "TIG welding rod for welding of copper nickel alloys containing up to 31% Nickel. Example like cunifer. \n\n";

        public static List<string> Welding_RodModelCollection()
        {
            List<string> listWelding_Rod = new List<string>();
            listWelding_Rod.Add(Welding_Rod_1);
            listWelding_Rod.Add(Welding_Rod_2);
            listWelding_Rod.Add(Welding_Rod_3);
            listWelding_Rod.Add(Welding_Rod_4);
            listWelding_Rod.Add(Welding_Rod_5);

            return listWelding_Rod;
        }

        //Welding_Rod_1
        public const string Welding_Rod_1_1 = "TIG welding rod for welding of aluminium-brass pipes also known as Yorcalbro pipes. \n\n";
        public const string Welding_Rod_1_2 = "TIG welding of aluminium material. \n\n";

        public static List<string> Welding_Rod_1ModelCollection()
        {
            List<string> listWelding_Rod_1  = new List<string>();
            listWelding_Rod_1.Add(Welding_Rod_1_1);
            listWelding_Rod_1.Add(Welding_Rod_1_2);
            return listWelding_Rod_1;
        }

        //Welding_Stick_Electrode
        public const string Welding_Stick_Electrode_1 = "Unitor range of welding electrodes.\n\n";
        public const string Welding_Stick_Electrode_2 = "Welding electrode for Mild Steel.	\n\n";
        public const string Welding_Stick_Electrode_3 = "Welding electrode for Ship quality steel. \n\n";
        public const string Welding_Stick_Electrode_4 = "Welding electrode for Stainless steel. \n\n";
        public const string Welding_Stick_Electrode_5 = "Welding electrode for Mild steel to Ship quality steel. \n\n";

        public static List<string> Welding_Stick_ElectrodeModelCollection()
        {
            List<string> listWelding_Stick_Electrode = new List<string>();
            listWelding_Stick_Electrode.Add(Welding_Stick_Electrode_1);
            listWelding_Stick_Electrode.Add(Welding_Stick_Electrode_2);
            listWelding_Stick_Electrode.Add(Welding_Stick_Electrode_3);
            listWelding_Stick_Electrode.Add(Welding_Stick_Electrode_4);
            listWelding_Stick_Electrode.Add(Welding_Stick_Electrode_5);

            return listWelding_Stick_Electrode;
        }
    }

}
