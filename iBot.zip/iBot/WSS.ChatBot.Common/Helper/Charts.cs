﻿using AdaptiveCards;
using Entities;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;

namespace Helper
{
    public class Charts
    {
        public  string getBinaryOfPieChart(List<CylinderDetails> pieListCylinders)
        {
            List<string> xvals;
            List<double> yvals;
            var chart = new Chart();

            ChartHeader(chart, true);
            ChartSeries(chart, SeriesChartType.Pie, true);
            BinaryPieChartData(pieListCylinders, out xvals, out yvals);
            BindChartAxis(chart, xvals, yvals);
            return DrawChart(chart);
        }

        public  string getBinaryOfBarChart(List<CylinderDetails> lstCylinders)
        {
            object[] xvals;
            List<int> yvals;
            var chart = new Chart();

            ChartHeader(chart, false);
            ChartSeries(chart, SeriesChartType.Column, false);
            BinaryBarChartData(lstCylinders, out xvals, out yvals);
            BindChartAxis(chart, xvals, yvals);
            return DrawChart(chart);
        }

        private void BindChartAxis(Chart chart, object[] xvals, List<int> yvals)
        {
            chart.Series["Series1"].Points.DataBindXY(xvals, yvals);
        }

        public AdaptiveCard getBarChartTable(List<CylinderDetails> resp)

        {
            var groupedCylinderList = resp.GroupBy(u => u.CYLINDER_NAME)
               .Select(grp => grp.ToList())
               .ToList();

            var count = groupedCylinderList.Count();

            var xvals = groupedCylinderList.Select(e => e.First()).Select(e => e.CYLINDER_NAME).ToArray();//groupedCylinderList[0].First().CYLINDER_NAME;
            var yvals = groupedCylinderList.Select(e => e.Count).ToList();//.Select(x => x.Last()).ToList();//new[] { 1, 3, 7, 12 };

            var card = new AdaptiveCard();
            var headerColumnSet = new AdaptiveColumnSet() { Separator = true };
            var column1 = new AdaptiveColumn();
            var column2 = new AdaptiveColumn();

            for (int i = 0; i < count + 1; i++)
            {


                if (i == 0)
                {
                    column1.Items.Add(new AdaptiveTextBlock()
                    {
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center,
                        Text = "CYLINDER NAME",
                        Size = AdaptiveTextSize.Default,
                        Weight = AdaptiveTextWeight.Bolder,
                        Separator = true
                    });
                    column2.Items.Add(new AdaptiveTextBlock()
                    {
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center,
                        Text = "CYLINDER COUNT",
                        Size = AdaptiveTextSize.Default,
                        Weight = AdaptiveTextWeight.Bolder,
                        Separator = true
                    });

                    //column1.Items.Add(new AdaptiveTextBlock(xvals[i].ToString()) { HorizontalAlignment = AdaptiveHorizontalAlignment.Center, Separator = true });
                    //column2.Items.Add(new AdaptiveTextBlock(groupedCylinderList.Count.ToString()) { HorizontalAlignment = AdaptiveHorizontalAlignment.Center, Separator = true });
                }
                else
                {
                    column1.Items.Add(new AdaptiveTextBlock(xvals[i - 1].ToString()) { HorizontalAlignment = AdaptiveHorizontalAlignment.Center, Separator = true });
                    column2.Items.Add(new AdaptiveTextBlock(yvals[i - 1].ToString()) { HorizontalAlignment = AdaptiveHorizontalAlignment.Center, Separator = true });
                }
            }

            headerColumnSet.Columns.Add(column1);
            headerColumnSet.Columns.Add(column2);
            card.Body.Add(headerColumnSet);
            return card;
        }

        private void BinaryBarChartData(List<CylinderDetails> lstCylinders, out object[] xvals, out List<int> yvals)
        {
            var groupedCylinderList = lstCylinders.GroupBy(u => u.Cylinder_type)
              .Select(g => new
              {
                  g.Key,
                  Count = g.Count()
              }).OrderByDescending(e => e.Count).Take(5)
              .ToList();

            //var xvals = groupedCylinderList.Select(e => e.First()).Select(e => e.Cylinder_type).ToArray();//groupedCylinderList[0].First().CYLINDER_NAME;
            xvals = groupedCylinderList.Select(e => e.Key).ToArray();
            yvals = groupedCylinderList.Select(e => e.Count).ToList();
            //.Select(x => x.Last()).ToList();//new[] { 1, 3, 7, 12 };
        }
        private void BinaryPieChartData(List<CylinderDetails> pieListCylinders, out List<string> xvals, out List<double> yvals)
        {
            var groupedCylinderList = pieListCylinders.GroupBy(u => u.Vessel_Name)
                         .Select(grp => grp.ToList()).Take(5)
                         .ToList();

            var pieList = pieListCylinders.GroupBy(x => x.Vessel_Name).Select(g => new { g.Key, Count = Math.Round(((double)g.Count() / pieListCylinders.Count()) * 100, 2) }).OrderByDescending(e => e.Count).ToList();


            xvals = pieList.Select(e => e.Key).ToList();
            yvals = pieList.Select(e => e.Count).ToList();
            // groupedCylinderList.Select(e => e.Count).ToList();//.Select(x => x.Last()).ToList();//new[] { 1, 3, 7, 12 };
        }
        private void BindChartAxis(Chart chart, List<string> xvals, List<double> yvals)
        {
            chart.Series["Series1"].Points.DataBindXY(xvals, yvals);
        }

        private string DrawChart(Chart chart)
        {
            chart.Invalidate();
            MemoryStream str = new MemoryStream();
            chart.SaveImage(str, ChartImageFormat.Png);
            var inputAsString = Convert.ToBase64String(str.ToArray());
            return inputAsString;
        }

        private void ChartSeries(Chart chart, SeriesChartType seriesChartType,  bool isChartLagend)
        {
            var series = new Series();
            series.Name = "Series1";
            series.ChartType = seriesChartType; 
            series.XValueType = ChartValueType.String;
            series.IsValueShownAsLabel = true;
            series.Font = new Font("Arial", 7, FontStyle.Regular);
            chart.Series.Add(series);
            if (isChartLagend)
            {
                chart.Series[0].Legend = "Vessel Name";
                chart.Series[0].LegendText = "#VALX";
            }
        }

        private void ChartHeader(Chart chart, bool isChartLagend)
        {
            chart.Size = new Size(250, 250);
            var chartArea = new ChartArea();
            // chartArea.AxisX.LabelStyle.Format = "dd/MMM\nhh:mm";
            chartArea.AxisX.MajorGrid.LineColor = Color.LightGray;
            chartArea.AxisY.MajorGrid.LineColor = Color.LightGray;
            chartArea.AxisX.LabelAutoFitStyle = LabelAutoFitStyles.DecreaseFont;
            chartArea.AxisX.LabelStyle.Font = new Font("Arial", 6, FontStyle.Regular);
            chartArea.AxisY.LabelAutoFitStyle = LabelAutoFitStyles.DecreaseFont;
            chartArea.AxisY.LabelStyle.Font = new Font("Arial", 6, FontStyle.Regular);
            chart.ChartAreas.Add(chartArea);

            if (isChartLagend)
            {
                chart.Legends.Add(new Legend("Vessel Name"));
                chart.Legends[0].TableStyle = LegendTableStyle.Auto;
                chart.Legends[0].Docking = Docking.Bottom;
                chart.Legends[0].Alignment = System.Drawing.StringAlignment.Center;
            }
        }
    }
}