﻿namespace ChatBot.Common
{
    public interface IWebConfigurationManagerForBot
    {
        string AzureSubscriptionId { get; set; }
        string LuisSearchParam { get; set; }
        string LuisSubscriptionId { get; set; }
        string LuisUrlPath { get; set; }
    }
}