﻿
using JSONUtils;
using Microsoft.Bot.Builder.Luis.Models;
using System.Collections.Generic;
using System.Configuration;
using WSS.ChatBot.Common;
/// <summary>
/// Class to call MandR.cs methods
/// </summary>
namespace ChatBot.Common
{
    public static class Utilities
    {
        public static string Replace(this string data)
        {
            return data.ToUpper().Replace("-", "").Replace(" ", "");
        }

        public static string GetIntent(this string oldIntent)
        {
            string newIntent = oldIntent;
            if (
                (oldIntent == ConstIntents.R404A_Refrigerants_Continue_R404A_and_R507) ||
                (oldIntent == ConstIntents.R507_Refrigerants_Continue_R404A_and_R507) ||
                (oldIntent == ConstIntents.R404A_R507_Refrigerants_Continue_R404A_and_R507) ||
                (oldIntent == ConstIntents.R507_R404A_Refrigerants_Continue_R404A_and_R507)
                )
            {
                newIntent = ConstIntents.R404A_R507_Continue;
            }
            else if (
                (oldIntent == ConstIntents.R404A_Refrigerants_Move_Away_from_R404A_and_R507) ||
                (oldIntent == ConstIntents.R507_Refrigerants_Move_Away_from_R404A_and_R507) ||
                (oldIntent == ConstIntents.R404A_R507_Refrigerants_Move_Away_from_R404A_and_R507) ||
                (oldIntent == ConstIntents.R507_R404A_Refrigerants_Move_Away_from_R404A_and_R507)
                )
            {
                newIntent = ConstIntents.R404A_R507_MoveAway;
            }
            else if (
               (oldIntent == ConstIntents.R448A_Availability) ||
               (oldIntent == ConstIntents.R449A_Availability)
               )
            {
                newIntent = ConstIntents.R448A_R449A_Availability;
            }

            else if (
               (oldIntent == ConstIntents.R134A_Refrigerant_GWP_and_Filling_Weight) ||
               (oldIntent == ConstIntents.R22_Refrigerant_GWP_and_Filling_Weight) ||
               (oldIntent == ConstIntents.R404A_Refrigerant_GWP_and_Filling_Weight) ||
               (oldIntent == ConstIntents.R407C_Refrigerant_GWP_and_Filling_Weight) ||
               (oldIntent == ConstIntents.R407F_Refrigerant_GWP_and_Filling_Weight) ||
               (oldIntent == ConstIntents.R410F_Refrigerant_GWP_and_Filling_Weight) ||
               (oldIntent == ConstIntents.R417A_Refrigerant_GWP_and_Filling_Weight) ||
               (oldIntent == ConstIntents.R422D_Refrigerant_GWP_and_Filling_Weight) ||
               (oldIntent == ConstIntents.R427A_Refrigerant_GWP_and_Filling_Weight) ||
               (oldIntent == ConstIntents.R507_Refrigerant_GWP_and_Filling_Weight)
               )
            {
                newIntent = ConstIntents.Refrigerant_GWP_and_Filling_Weight;
            }

            else if ((oldIntent == ConstIntents.Ropes_Acera_22MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_24MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_26MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_28MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_30MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_32MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_34MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_36MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_38MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_40MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_42MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_44MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_46MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_48MM) ||
              (oldIntent == ConstIntents.Ropes_Acera_52MM))
            {
                newIntent = ConstIntents.Ropes_Acera;
            }

            else if (
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410263) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410267) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410271) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410275) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410283) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410287) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410291) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410295) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410299) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410303) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410307) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410311) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410419) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410423) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410427) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410431) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410435) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410439) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410443) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410447) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410451) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410455) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410778) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410778) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410790) ||
              (oldIntent == ConstIntents.Ropes_Acera_Products_EDP_410828))
            {
                newIntent = ConstIntents.Ropes_Acera_Products_EDP;
            }

            else if (
             (oldIntent == ConstIntents.Ropes_Acera_400kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_450kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_470kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_520kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_540kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_600kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_610kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_680kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_690kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_770kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_780kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_870kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_860kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_960kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_940kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1040kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1040kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1160kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1130kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1260kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1209kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1350kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1310kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1460kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1530kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1700kn_UNSPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1422kn_SPLICED) ||
             (oldIntent == ConstIntents.Ropes_Acera_1580kn_UNSPLICED)
             )
            {
                newIntent = ConstIntents.Ropes_Acera;
            }
            else if ((oldIntent == ConstIntents.CandM1) || (oldIntent == ConstIntents.CandM2))
            {
                newIntent = ConstIntents.CandM;
            }

            else if (
             (oldIntent == ConstIntents.Refrigeration_UV_Tracer_Kit_220V_220V) ||
             (oldIntent == ConstIntents.Refrigeration_UV_Tracer_Kit_220V_587170)
             )
            {
                newIntent = ConstIntents.Refrigeration_UV_Tracer_Kit_220V;
            }

            return newIntent;
        }


        public static string GetMailUser(string intent)
        {
            var product = ConvertIntentIntoProduct(intent);

            string emailAddress;
            switch (product)
            {
                case Products.Fuel:
                    emailAddress = ConfigurationManager.AppSettings[Email.Fuel];
                    break;
                case Products.Oil:
                    emailAddress = ConfigurationManager.AppSettings[Email.Oil];
                    break;
                case Products.Rope:
                    emailAddress = ConfigurationManager.AppSettings[Email.Rope];
                    break;
                case Products.Refrigerants:
                    emailAddress = ConfigurationManager.AppSettings[Email.Refrigerants];
                    break;
                case Products.Diesel:
                    emailAddress = ConfigurationManager.AppSettings[Email.Diesel];
                    break;
                case Products.GandA:
                    emailAddress = ConfigurationManager.AppSettings[Email.GandA];
                    break;
                case Products.Welding:
                    emailAddress = ConfigurationManager.AppSettings[Email.Welding];
                    break;
                case Products.Air:
                    emailAddress = ConfigurationManager.AppSettings[Email.Air];
                    break;

                default:
                    return ConfigurationManager.AppSettings[Email.Default];
            }

            return emailAddress;
        }
        

        private static string ConvertIntentIntoProduct(string intent)
        {
            string product;

            switch (intent.Trim())
            {
                //fuel cases
                case ConstIntents.HeavySludge:
                case ConstIntents.HeavyImproperCombustion:
                case ConstIntents.HeavySoot:
                case ConstIntents.HeavySludgeVarious:
                case ConstIntents.HeavyWater:
                case ConstIntents.HeavyCorrosion:
                    product = Products.Fuel;
                    break;

                //vessel cases:
                case ConstIntents.Vessel_Oxytreat_25_Ltr:
                case ConstIntents.Vessel_Slip_Coat_Plus_25_Ltr:
                    product = Products.Fuel;
                    break;

                //rope cases
                case ConstIntents.RopesCertification:
                case ConstIntents.RopeAccessories:
                case ConstIntents.RopesConventionalMix:
                case ConstIntents.RopesConventionalPolyPropylene:
                case ConstIntents.RopesConventionalNylon:
                case ConstIntents.RopesStretcherMix:
                case ConstIntents.RopesStretcherNylon:
                case ConstIntents.RopesStretcherPolyPropylene:
                case ConstIntents.Ropes_Sikka:
                case ConstIntents.Ropes_StretcherRecommendation:
                case ConstIntents.Ropes_SteelWire:
                case ConstIntents.Ropes_SBA:
                case ConstIntents.Ropes_Stretcher:
                case ConstIntents.Ropes_MixType:
                case ConstIntents.Ropes_Main:
                case ConstIntents.Ropes_Conventional:
                case ConstIntents.Ropes_DalrympleBay:
                case ConstIntents.Ropes_Lines:
                case ConstIntents.Ropes_HeavingLine:
                case ConstIntents.Ropes_PilotLadder:
                case ConstIntents.Ropes_FlagLine:
                case ConstIntents.Ropes_RatGuard:
                case ConstIntents.Ropes_ManilaRope:
                case ConstIntents.Ropes_TigerRope:
                case ConstIntents.Ropes_MessengerLine:
                case ConstIntents.Ropes_MinaAlAhmadi:
                case ConstIntents.Ropes_OCIMF4:
                case ConstIntents.Ropes_Spliced:
                case ConstIntents.Ropes_SmartRope:
                case ConstIntents.Ropes_StockPoints:
                case ConstIntents.INT_RS_PSD:
                case ConstIntents.Ropes_CowHitch:
                case ConstIntents.Ropes_Cutter:
                //case ConstIntents.Ropes_RubberMooringSnubber:
                case ConstIntents.Ropes_StretcherRingtailSingleTail:
                case ConstIntents.Ropes_Atlas:
                case ConstIntents.Ropes_TimmWinchline:
                case ConstIntents.Ropes_TimmMaster8:
                case ConstIntents.Ropes_TypeApproval:
                case ConstIntents.Ropes_AceraScott:
                case ConstIntents.Ropes_Acera:
                case ConstIntents.Ropes_Acera_Products_EDP:

                    product = Products.Rope;
                    break;

                //oil cases
                case ConstIntents.OiltestFerrouswear:
                case ConstIntents.OiltestCompatability:
                case ConstIntents.OiltestTbn:
                case ConstIntents.OiltestInsolubles:
                case ConstIntents.OiltestSaltwater:
                case ConstIntents.OiltestCabinet:
                case ConstIntents.OiltestWater:
                case ConstIntents.OiltestViscosity:
                case ConstIntents.OilBiofuelsulphide:
                    product = Products.Oil;
                    break;

                //diesel case
                case ConstIntents.DieselLubricity:
                case ConstIntents.DieselWaxing:
                case ConstIntents.DieselDiscoloration:
                case ConstIntents.DieselBacteria:
                    product = Products.Diesel;
                    break;

                //refrigerant cases               

                case ConstIntents.R507_Availability:
                case ConstIntents.R22_Availability:
                case ConstIntents.R404A_Availability:
                case ConstIntents.R448A_Availability:
                case ConstIntents.R448A_R449A_Availability:
                case ConstIntents.R449A_Availability:
                case ConstIntents.R407F_Availability:

                case ConstIntents.R404A_R507_Refrigerants_Continue_R404A_and_R507:
                case ConstIntents.R404A_Refrigerants_Continue_R404A_and_R507:
                case ConstIntents.R507_R404A_Refrigerants_Continue_R404A_and_R507:
                case ConstIntents.R507_Refrigerants_Continue_R404A_and_R507:

                case ConstIntents.R404A_R507_Refrigerants_Move_Away_from_R404A_and_R507:
                case ConstIntents.R404A_Refrigerants_Move_Away_from_R404A_and_R507:
                case ConstIntents.R507_R404A_Refrigerants_Move_Away_from_R404A_and_R507:
                case ConstIntents.R507_Refrigerants_Move_Away_from_R404A_and_R507:

                case ConstIntents.R407F_GuideLines:
                case ConstIntents.R407F_R404A_GuideLines:

                case ConstIntents.R404A_Price:
                case ConstIntents.R407F_Price:

                case ConstIntents.R22_Replace:
                case ConstIntents.R404A_R407F_Replace:
                case ConstIntents.R404A_Replace:
                case ConstIntents.R407F_R404A_Replace:
                case ConstIntents.R407F_R507_Replace:
                case ConstIntents.R507_R407F_Replace:

                case ConstIntents.R22_Retrofit:
                case ConstIntents.R404A_R407F_Retrofit:
                case ConstIntents.R407F_R404A_Retrofit:
                case ConstIntents.R407F_R507_Retrofit:
                case ConstIntents.R507_R407F_Retrofit:

                case ConstIntents.R404A_R407F_Topup:
                case ConstIntents.R407F_R404A_Topup:
                case ConstIntents.R407F_R507_Topup:
                case ConstIntents.R507_R407F_Topup:

                // Refrigerant intents from main app:
                case ConstIntents.What_is_Montreal_Protocol:
                case ConstIntents.Refrigerants_Price_On_Request:
                case ConstIntents.Refrigerants_Price_Change:
                case ConstIntents.Refrigerants_HFC_Quota:
                case ConstIntents.Refrigerants_Anti_Dumping:
                case ConstIntents.Refrigerants_F_gas:
                case ConstIntents.Refrigerants_in_WSS_standard_cylinders:

                case ConstIntents.Refrigerant_Recovery:
                case ConstIntents.Refrigerant_Leak_Detection:
                case ConstIntents.Refrigerant_Recovery_Cylinder:
                    // case Intents.Refrigerant_UV_Tracer_Kit_12V:

                    product = Products.Refrigerants;
                    break;

                // G and A cases
                case ConstIntents.EasyClean_Window_And_Mirror:
                case ConstIntents.EasyClean_SoftSurface_And_Spot:
                case ConstIntents.EasyClean_Floor_And_Hard_Surface:
                case ConstIntents.EasyClean_Basin_And_ToiletBowl:
                case ConstIntents.Gamazyme_BTC:
                case ConstIntents.Gamazyme_TDS:
                case ConstIntents.Gamazyme_Digestor:
                case ConstIntents.Gamazyme_BOE:
                case ConstIntents.Easyclean_Cleaning_And_DisInfection_Sanite128F:
                case ConstIntents.Galley_Easyclean_Oven_And_Grill:
                case ConstIntents.Galley_Easyclean_Dishwashing_LiquidManual:
                case ConstIntents.Galley_Easyclean_Hand_Sanitizer:
                case ConstIntents.Galley_Gamazyme_Boe:
                case ConstIntents.Galley_Gamazyme_Digestor:
                case ConstIntents.Drains_Gamazyme700_FN:
                case ConstIntents.Easyclean_Laundry_Conditioner:
                case ConstIntents.Easyclean_Laundry_Powder_ForLaundry:
                case ConstIntents.Easyclean_Laundry_Powder_SkinRash:
                case ConstIntents.SkinCare_EasyClean_Liquid_Hand_Soap_D:
                case ConstIntents.SkinCare_EasyClean_Hand_Sanitizer:
                case ConstIntents.SkinCare_EasyClean_Hand_Barrier_Cream_Wet:
                case ConstIntents.SkinCare_EasyClean_Hand_Barrier_Cream_Dry:
                case ConstIntents.SkinCare_EasyClean_After_Work_Lotion:
                case ConstIntents.SkinCare_EasyClean_Natural_Hand_Cleaner:
                case ConstIntents.Cleaning_Shelf_life_Gamayzme_TDS:
                case ConstIntents.Cleaning_Shelf_life_Gamazyme_700FN:
                case ConstIntents.Cleaning_Shelf_life_Gamazyme_BTC:
                case ConstIntents.Cleaning_Shelf_life_Gamazyme_DPC:

                case ConstIntents.C_M_ACC_Plus:
                case ConstIntents.C_M_COMMISSIONING_CLEANER:
                case ConstIntents.C_M_COLDWASH_HD:
                case ConstIntents.C_M_CLEANBREAK:
                case ConstIntents.C_M_BILGEWATER_FLOCCULANT:
                case ConstIntents.C_M_CARBONCLEAN_LT:
                case ConstIntents.C_M_AQUATUFF:
                case ConstIntents.C_M_AQUABREAK_PX:
                case ConstIntents.C_M_Deck_Clean_NP:
                case ConstIntents.C_M_Defoamer_Concentrate:

                    product = Products.GandA;
                    break;

                //Welding
                case ConstIntents.Welding_Cutting_Torches:
                case ConstIntents.Welding_Cutting_Torches_1:
                case ConstIntents.Welding_Accessories:
                case ConstIntents.Welding_Electrode_Competitor:
                case ConstIntents.Welding_Electrode_Competitor_1:
                case ConstIntents.Welding_Electrode_Competitor_2:
                case ConstIntents.Welding_Electrode_Competitor_3:
                case ConstIntents.Welding_Electrode_Competitor_4:
                case ConstIntents.Welding_Electrode_Competitor_5:
                case ConstIntents.Welding_Electrode_Competitor_6:
                case ConstIntents.Welding_Flashback_Arrestor:
                case ConstIntents.Welding_Plasma_Machine:
                case ConstIntents.Welding_Plasma_Machine_1:
                case ConstIntents.Welding_Regulator_Oxygen_Acetylene:
                case ConstIntents.Welding_Oxygen_Acetylene_Gas_Hoses:
                case ConstIntents.Welding_Rod:
                case ConstIntents.Welding_Rod_1:
                case ConstIntents.Welding_Machine_1:
                case ConstIntents.Welding_Open_Circuit_Voltage:
                case ConstIntents.Welding_Stick_Electrode:


                    product = Products.Welding;
                    break;

                //Air
                case ConstIntents.Air_Distributor:
                case ConstIntents.Air_Hose_Clamp:
                case ConstIntents.Air_tools_quick_coupling:

                    product = Products.Air;
                    break;

                default:
                case ConstIntents.Blank:

                    return Products.Fuel;

            }

            return product.ToLower();
        }

    }
    public enum MessageEnum : int
    {
        //R404A
        R404A_Availability,
        R404A_Price,
        R404A_Replace,
        R404A_Supply,
        //R407F
        R407F_Availability,
        R407F_GuideLines,
        R407F_Replace_R404A,
        R407F_Replace_R507,
        R407F_Retrofit_R404A,
        R407F_Retrofit_R507,
        R407F_Topup_R404A,
        R407F_Topup_R507
    };
}
