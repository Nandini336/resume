﻿using AdaptiveCards;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Threading.Tasks;

namespace Helper
{
    public class Errors
    {
         public AdaptiveCard CreateErrorCard(string errorMessage)
        {
            var card = new AdaptiveCard();
            var textBlock = new AdaptiveTextBlock()
            {
                Text = errorMessage,
              //  Text = "You do not have any orders.",
                Size = AdaptiveTextSize.Large,
                Weight = AdaptiveTextWeight.Bolder,
            };

            card.Body.Add(textBlock);

            return card;
        }

        public Task ErrorMessage(IDialogContext context, string errorMessage)
        {
            AdaptiveCard card = CreateErrorCard(errorMessage);
            var attachment = new Attachment()
            {
                Content = card,
                ContentType = AdaptiveCard.ContentType
            };
            var message = context.MakeMessage();
            message.Attachments.Add(attachment);
            context.PostAsync(message);
            return Task.CompletedTask;
        }

    }
}