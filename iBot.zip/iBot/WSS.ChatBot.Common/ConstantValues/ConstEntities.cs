﻿using ChatBot.Common;

namespace WSS.ChatBot.Common
{
    public class ConstEntities
    {      

        public const string smell = "smell";
        public const string bacteria = "bacteria";
        public const string corrosion = "corrosion";
        public const string engineparts = "engine parts";
        
        public const string color = "color";
        public const string stability = "stability";
        public const string sediment = "sediment";
        public const string combustion = "combustion";
        public const string deposit = "deposit";
        public const string deposit1 = "deposit1";
        public const string sludge = "sludge";
        public const string storage = "storage";
        public const string lubricity = "lubricity";
        public const string wear = "wear";
        //public const string waxing = "waxing";
        public const string wax = "wax";
        public const string soot = "soot";
        public const string Diesel = "Diesel";
        public const string Heavy = "Heavy";
        public const string nsf = "nsf";
        public const string degreasingagent = "degreasing agent";
        public const string multipurpose = "multipurpose";
        public const string alkaline = "alkaline";
        public const string separate = "separate";
        public const string carbon = "carbon";
        public const string splitting = "splitting";
        public const string solvent = "solvent";
        public const string contamination = "contamination";


        public const string arrestor = "arrestor";
        public const string keys1 = "keys1";
        public const string keys2 = "keys2";
        public const string regulator = "regulator";
        public const string voltage = "voltage";
        public const string weldingelectrode = "welding electrode";
        public const string weldingmachine = "welding machine";
        public const string stick = "stick";
        public const string steel = "steel";
        public const string cut = "cut";
        public const string plasma = "plasma";

        public const string salt = "salt";
        public const string tbn = "tbn";
        public const string viscosity = "viscosity";
        public const string cabinet = "cabinet";

        public const string b33 = "b - 33";

        //Ropes entities

        public const string accessories = "accessories";
        public const string protection = "protection";
        public const string repairkit = "repairkit";
        public const string shackle = "shackle";
        public const string timmchafeguard = " timmchafeguard";
        public const string cowhitch = "cowhitch";
        public const string timmbosslink = "timmbosslink";
        public const string cruise = "cruise";
        public const string mix = "mix";
        public const string nylon = "nylon";
        public const string pp = "pp";
        public const string MinaAlAhmadi = "minaalahmadi";
        public const string atlas = "atlas";
        public const string certificate = "certificate";
        public const string cutter = "cutter";
        public const string dbct = "dbct";
        public const string flagline = "flagline";
        public const string heave = "heave";
        public const string ladder = "ladder";
        public const string manila = "manila";
        public const string messenger = "messenger";
        public const string mixtype = "mixtype";
        public const string ocimf = "ocimf";
        public const string rat = "rat";
        public const string ropelines = "ropelines";
        public const string safe = "safe";
        public const string sba = "sba";
        public const string sensor = "sensor";
        public const string splice = "splice";
        public const string sikka = "sikka";
        public const string snubber = "snubber";
        public const string stockpoint = "stockpoint";
        public const string tiger = "tiger";
        public const string timm8 = "timm8";
        public const string winchline = "winchline";
        public const string strategy = "strategy";
        public const string scott = "scott";
        public const string panama = "panama";
        public const string tcll = "tcll";


    }
}