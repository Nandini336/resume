﻿namespace WSS.ChatBot.Common
{
    /// <summary>
    /// Constants for email ids in the web.config file
    /// </summary>
    public class Email
    {
        public const string Fuel = "fuelEmail";
        public const string Oil = "oilEmail";
        public const string Rope = "ropeEmail";
        public const string Refrigerants = "refrigerantsEmail";
        public const string Diesel = "dieselEmail";
        public const string GandA = "GandAEmail";
        public const string Default = "ToEmailAddress";
        public const string Welding = "weldingEmail";
        public const string Air = "airEmail";
        public const string Workshop = "workshopEmail";
        
    }
}