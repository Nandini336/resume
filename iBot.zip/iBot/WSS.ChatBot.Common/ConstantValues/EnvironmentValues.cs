﻿namespace WSS.ChatBot.Common
{
    public class EnvironmentValues
    {
        public const string TestModelId = "5b32a666-1208-4210-93b9-ebcdcb940035";

        public const string ProductionModelId = "68806d5a-dd61-42d6-a0f3-0f51807019f0";

        public const string TestSubscriptionId = "0f14503ddf8448689cbe568edf1f89b3";

        public const string ProductionSubscriptionId = "d98fd0f03f2548229585d92994f4ebec";

        public const string Domain = "southeastasia.api.cognitive.microsoft.com";
    }
}