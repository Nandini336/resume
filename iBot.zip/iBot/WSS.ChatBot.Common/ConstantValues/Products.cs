﻿namespace WSS.ChatBot.Common
{
    /// <summary>
    /// Constants for products in the Mailcontent class
    /// </summary>
    public class Products
    {
        public const string Fuel = "fuel";
        public const string Oil = "oil";
        public const string Rope = "rope";
        public const string Refrigerants = "refrigerants";
        public const string Diesel = "diesel";
        public const string GandA = "ganda";
        public const string Welding = "welding";
        public const string Air = "air";
        public const string Workshop = "workshop";
    }
}