﻿/// <summary>
/// Constants class
/// </summary>

namespace WSS.ChatBot.Common
{
    /// <summary>
    /// Constants for all intents
    /// </summary>
    public class ConstIntents
    {
        public const string EmailYes = "Yes";
        public const string EmailNo = "No";
         

        public const string PostData = "PostData";
        public const string Blank = "Blank";


        public const string WrongOption = "WrongOption";

        public const string Greetings = "Greetings";

        public const string UnknownIntent = "Unknown_Intent";

        public const string ByeIntent = "Bye_Intent";

        public const string None = "None";

        public const string Thanks = "Thanks";

        public const string Yes = "Yes";

        public const string No = "No";

        public const string Empty = "";

        //FUEL
        public const string Heavy = "Heavy";
        public const string HeavySludge = "Heavy_Sludge";

        public const string HeavySludgeVarious = "Heavy_Sludge_Various";

        public const string HeavySoot = "Heavy_Soot";

        public const string HeavyImproperCombustion = "Heavy_ImproperCombustion";

        public const string HeavyWater = "Heavy_Water";

        public const string HeavyCorrosion = "Heavy_Corrosion";

        //OILTEST

        public const string OilTest = "OilTest";
        public const string OiltestLubricity = "Oiltest_lubricity";

        public const string OiltestFerrouswear = "Oiltest_Ferrouswear";

        public const string OiltestCompatability = "Oiltest_compatability";

        public const string OiltestTbn = "Oiltest_TBN";

        public const string OiltestInsolubles = "Oiltest_Insolubles";

        public const string OiltestSaltwater = "Oiltest_Saltwater";

        public const string OiltestCabinet = "Oiltest_cabinet";

        public const string OiltestWater = "Oiltest_Water";

        public const string OiltestViscosity = "Oiltest_Viscosity";

        public const string OilBiofuelsulphide = "Oil_Biofuelsulphide";

        //DIESEL

        public const string Diesel = "Diesel";

        public const string DieselLubricity = "Diesel_Lubricity";

        public const string DieselDiscoloration = "Diesel_Discoloration";

        public const string DieselBacteria = "Diesel_Bacteria";

        public const string DieselWaxing = "Diesel_Waxing";

        //ROPES NEW

        public const string Ropes_Acera_Amundsen = "Ropes_Acera_Amundsen";

        public const string Ropes_Acera_Dagama = "Ropes_Acera_Dagama";

        public const string Ropes_Acera_Products_EDP = "Ropes_Acera_Products_EDP";

        public const string Ropes_TypeApproval = "Ropes_TypeApproval";

        public const string Ropes_Acera = "Ropes_Acera";

        public const string Ropes_TCLL = "Ropes_TCLL";

        public const string Ropes_PanamaCanal = "Ropes_PanamaCanal";

        public const string Ropes_Acera_Products_EDP_410263 = "410263_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410267 = "410267_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410778 = "410778_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410271 = "410271_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410275 = "410275_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410283 = "410283_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410287 = "410287_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410291 = "410291_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410295 = "410295_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410299 = "410299_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410303 = "410303_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410307 = "410307_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410311 = "410311_Ropes_Acera_Products_EDP";

        public const string Ropes_Acera_Products_EDP_410419 = "410419_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410423 = "410423_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410828 = "410828_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410427 = "410427_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410431 = "410431_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410435 = "410435_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410790 = "410790_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410439 = "410439_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410443 = "410443_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410447 = "410447_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410451 = "410451_Ropes_Acera_Products_EDP";
        public const string Ropes_Acera_Products_EDP_410455 = "410455_Ropes_Acera_Products_EDP";

        public const string Ropes_Acera_22MM = "22MM_Ropes_Acera";
        public const string Ropes_Acera_24MM = "24MM_Ropes_Acera";
        public const string Ropes_Acera_26MM = "26MM_Ropes_Acera";
        public const string Ropes_Acera_28MM = "28MM_Ropes_Acera";
        public const string Ropes_Acera_30MM = "30MM_Ropes_Acera";
        public const string Ropes_Acera_32MM = "32MM_Ropes_Acera";
        public const string Ropes_Acera_34MM = "34MM_Ropes_Acera";
        public const string Ropes_Acera_36MM = "36MM_Ropes_Acera";
        public const string Ropes_Acera_38MM = "38MM_Ropes_Acera";
        public const string Ropes_Acera_40MM = "40MM_Ropes_Acera";
        public const string Ropes_Acera_42MM = "42MM_Ropes_Acera";
        public const string Ropes_Acera_44MM = "44MM_Ropes_Acera";
        public const string Ropes_Acera_46MM = "46MM_Ropes_Acera";
        public const string Ropes_Acera_48MM = "48MM_Ropes_Acera";
        public const string Ropes_Acera_50MM = "50MM_Ropes_Acera";
        public const string Ropes_Acera_52MM = "52MM_Ropes_Acera";

        public const string Ropes_Acera_400kn_SPLICED = "400KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_450kn_UNSPLICED = "450KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_470kn_SPLICED = "470KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_520kn_UNSPLICED = "520KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_540kn_SPLICED = "540KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_600kn_UNSPLICED = "600KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_610kn_SPLICED = "610KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_680kn_UNSPLICED = "680KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_690kn_SPLICED = "690KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_770kn_UNSPLICED = "770KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_780kn_SPLICED = "780KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_870kn_UNSPLICED = "870KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_860kn_SPLICED = "860KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_960kn_UNSPLICED = "960KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_940kn_SPLICED = "940KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_1040kn_SPLICED = "1040KN_SPLICED_Ropes_Acera";

        public const string Ropes_Acera_1040kn_UNSPLICED = "1040KN_UNSPLICED_Ropes_Acera";
        public const string Ropes_Acera_1160kn_UNSPLICED = "1160KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_1130kn_SPLICED = "1130KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_1260kn_UNSPLICED = "1260KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_1209kn_SPLICED = "1209KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_1350kn_UNSPLICED = "1350KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_1310kn_SPLICED = "1310KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_1460kn_UNSPLICED = "1460KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_1530kn_SPLICED = "1530KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_1700kn_UNSPLICED = "1700KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Acera_1422kn_SPLICED = "1422KN_SPLICED_Ropes_Acera";
        public const string Ropes_Acera_1580kn_UNSPLICED = "1580KN_UNSPLICED_Ropes_Acera";

        public const string Ropes_Eyes = "Ropes_Eyes";

        //
        //ROPES OLD

        public const string Ropes_Availability = "Ropes_Availability";

        public const string Ropes_Queries = "Ropes_Queries";

        public const string RopesCertification = "Ropes_Certification";

        public const string RopeAccessories = "Rope_Accessories";

        public const string RopesConventional = "Ropes_Conventional";

        public const string RopesConventionalMix = "Ropes_Conventional_Mix";

        public const string RopesConventionalPolyPropylene = "Ropes_Conventional_Polypropylene";

        public const string RopesConventionalNylon = "Ropes_Conventional_Nylon";

        public const string RopesStretcherMix = "Ropes_Stretcher_Mix";

        public const string RopesStretcherNylon = "Ropes_Stretcher_Nylon";

        public const string RopesStretcherPolyPropylene = "Ropes_Stretcher_PolyPropylene";

        public const string Ropes_Sikka = "Ropes_Sikka";

        public const string Ropes_StretcherRecommendation = "Ropes_StretcherRecommendation";

        public const string Ropes_SteelWire = "Ropes_SteelWire";

        public const string Ropes_SBA = "Ropes_SBA";

        public const string Ropes_Stretcher = "Ropes_Stretcher";

        public const string Ropes_MixType = "Ropes_MixType";

        public const string Ropes_Main = "Ropes_Main";

        public const string Ropes_Conventional = "Ropes_Conventional";

        public const string Ropes_DalrympleBay = "Ropes_DalrympleBay";

        public const string Ropes_Lines = "Ropes_Lines";

        public const string Ropes_HeavingLine = "Ropes_HeavingLine";

        public const string Ropes_PilotLadder = "Ropes_PilotLadder";

        public const string Ropes_FlagLine = "Ropes_FlagLine";

        public const string Ropes_RatGuard = "Ropes_RatGuard";

        public const string Ropes_ManilaRope = "Ropes_ManilaRope";

        public const string Ropes_TigerRope = "Ropes_TigerRope";

        public const string Ropes_MessengerLine = "Ropes_MessengerLine";

        public const string Ropes_MinaAlAhmadi = "Ropes_MinaAlAhmadi";

        public const string Ropes_OCIMF4 = "Ropes_OCIMF4";

        public const string Ropes_Spliced = "Ropes_Spliced";

        public const string Ropes_SmartRope = "Ropes_SmartRope";

        public const string Ropes_StockPoints = "Ropes_StockPoints";

        public const string INT_RS_PSD = "INT_RS_PSD";

        public const string Ropes_CowHitch = "Ropes_CowHitch";

        public const string Ropes_Cutter = "Ropes_Cutter";

        public const string Ropes_RubberMooringSnubber​ = "Ropes_RubberMooringSnubber​";

        public const string Ropes_StretcherRingtailSingleTail = "Ropes_StretcherRingtailSingleTail";

        public const string Ropes_Atlas = "Ropes_Atlas";

        public const string Ropes_TimmWinchline = "Ropes_TimmWinchline";

        public const string Ropes_TimmMaster8 = "Ropes_TimmMaster8";

        public const string Ropes_AceraScott = "Ropes_AceraScott";

        public const string Ropes_MeasuringDiameter = "Ropes_MeasuringDiameter";

        public const string Ropes_Conditions = "Ropes_Conditions";

        public const string Ropes_Conventional_Nylon = "Ropes_Conventional_Nylon";

       

       // public const string Ropes_Eyes = "Ropes_Eyes";

        //M AND R

        public const string CandM = "CandM";

        public const string CandM1 = "CandM_1";

        public const string CandM2 = "CandM_2";

        public const string C_M_ACC_Plus = "C&M_ACC_Plus";

        public const string C_M_Defoamer_Concentrate = "C&M_Defoamer Concentrate";

        public const string C_M_Deck_Clean_NP = " C&M_Deck_Clean_NP";

        public const string C_M_COMMISSIONING_CLEANER = "C&M_COMMISSIONING_CLEANER";

        public const string C_M_COLDWASH_HD = "C&M_COLDWASH_HD";

        public const string C_M_CLEANBREAK = "C&M_CLEANBREAK";

        public const string C_M_BILGEWATER_FLOCCULANT = "C&M_BILGEWATER_FLOCCULANT";

        public const string C_M_CARBONCLEAN_LT = "C&M_CARBONCLEAN_LT";

        public const string C_M_AQUATUFF = "C&M_AQUATUFF";

        public const string C_M_AQUABREAK_PX = "C&M_AQUABREAK_PX";

        public const string Refrigerant_R22_Availability = "Refrigerant_R-22_Availability";

        public const string R404A_Supply = "R404A_Supply";

        public const string What_is_Montreal_Protocol = "Refrigerant_What_is_Montreal_Protocol";

        public const string R404A_Availability = "R404A_Availability";

        public const string R404A_Price = "R404A_Price";

        public const string R404A_Replace = "R404A_Replace";

        public const string R407F_Availability = "R407F_Availability";

        public const string R407F_GuideLines = "R407F_GuideLines";

        public const string R407F_Replace_R404A = "R407F_Replace_R404A";

        public const string R407F_Replace_R507 = "R407F_Replace_R507";

        public const string R407F_Retrofit_R404A = "R407F_Retrofit_R404A";

        public const string R407F_Retrofit_R507 = "R407F_Retrofit_R507";

        public const string R407F_Topup_R404A = "R407F_Topup_R404A";

        public const string R407F_Topup_R507 = "R407F_Topup_R507";


        

        //VESSELS

        public const string Vessel_Slip_Coat_Plus_25_Ltr = "Vessel_Slip_Coat_Plus_25_Ltr";

        public const string Vessel_Oxytreat_25_Ltr = "Vessel_Oxytreat_25_Ltr";

        //REFRIGERANTS 7 FAQ

        public const string Refrigerants_Price_On_Request = "Refrigerants_Price_On_Request";

        public const string Refrigerants_Price_Change = "Refrigerants_Price_Change";

        public const string Refrigerants_HFC_Quota = "Refrigerants_HFC_Quota";

        public const string Refrigerants_Anti_Dumping = "Refrigerants_Anti-Dumping";

        public const string Refrigerants_F_gas = "Refrigerants_F-gas";

        public const string Refrigerants_Continue_R404A_and_R507 = "Refrigerants_Continue_R404A_and_R507";

        public const string Refrigerants_Move_Away_from_R404A_and_R507 = "Refrigerants_Move_Away_from_R404A_and_R507";

        public const string Refrigerants_in_WSS_standard_cylinders = "Refrigerants_in_WSS_standard_cylinders";

        public const string Refrigerant_Recovery = "Refrigerant_Recovery";

        public const string Refrigerant_Leak_Detection = "Refrigerant_Leak_Detection";

        public const string Refrigerant_Recovery_Cylinder = "Refrigerant_Recovery_Cylinder";

        public const string Refrigerant_UV_Tracer_Kit_12V = "Refrigerant_UV_Tracer_Kit_12V";

        public const string Refrigerant_R_22_Replacement = "Refrigerant_R-22_Replacement";

        public const string Refrigerant_Guidelines_On_R_407F_Top_Up = "Refrigerant_Guidelines_On_R-407F_Top_Up";

        public const string Refrigerant_Return_of_Full_Cylinder = "Refrigerant_Return_of_Full_Cylinder";

        public const string Refrigeration_UV_Tracer_Kit_220V = "Refrigeration_UV_Tracer_Kit_220V";
        public const string Refrigeration_UV_Tracer_Kit_220V_220V = "220V_Refrigeration_UV_Tracer_Kit_220V";
        public const string Refrigeration_UV_Tracer_Kit_220V_587170 = "220V_Refrigeration_UV_Tracer_Kit_220V_587170";

        public const string Refrigerant_GWP_and_Filling_Weight = "Refrigerant_GWP_and_Filling_Weight";

        //New values of Refrigerant
        public const string R407F_Price = "R407F_Price";
        public const string R507_Price = "R507_Price";
        public const string R134A_Price = "R134A_Price";      

        public const string R507_Availability = "R507_Availability";
        public const string R22_Availability = "R22_Availability";
        public const string R448A_Availability = "R448A_Availability";
        public const string R449A_Availability = "R449A_Availability";
        public const string R448A_R449A_Availability = "R448A_R449A_Availability";
        public const string R134A_Availability = "R134A_Availability";
        public const string R427A_Availability = "R427A_Availability";
        public const string R410A_Availability = "R410A_Availability";
        public const string R417A_Availability = "R417A_Availability";
        public const string R422D_Availability = "R422D_Availability";
        

        public const string R404A_R407F_Replace = "R404A_R407F_Replace";
        public const string R407F_R404A_Replace = "R407F_R404A_Replace";
        public const string R407F_R507_Replace = "R407F_R507_Replace";
        public const string R507_R407F_Replace = "R507_R407F_Replace";
        public const string R22_Replace = "R22_Replace";
        public const string R507_Replace = "R507_Replace";
        public const string R422D_Replace = "R422D_Replace";

        public const string R404A_R507_Continue = "R404A_R507_Continue";
        public const string R404A_Refrigerants_Continue_R404A_and_R507 = "R404A_Refrigerants_Continue_R404A_and_R507";
        public const string R507_Refrigerants_Continue_R404A_and_R507 = "R507_Refrigerants_Continue_R404A_and_R507";
        public const string R404A_R507_Refrigerants_Continue_R404A_and_R507 = "R404A_R507_Refrigerants_Continue_R404A_and_R507";
        public const string R507_R404A_Refrigerants_Continue_R404A_and_R507 = "R507_R404A_Refrigerants_Continue_R404A_and_R507";

        public const string R407F_R404A_Retrofit = "R407F_R404A_Retrofit";
        public const string R404A_R407F_Retrofit = "R404A_R407F_Retrofit";
        public const string R507_R407F_Retrofit = "R507_R407F_Retrofit";
        public const string R407F_R507_Retrofit = "R407F_R507_Retrofit";
        public const string R507A_R407F_Retrofit = "R507A_R407F_Retrofit";
        public const string R407F_R507A_Retrofit = "R407F_R507A_Retrofit";
        public const string R22_Retrofit = "R22_Retrofit";

        public const string R407F_R404A_Topup = "R407F_R404A_Topup";
        public const string R404A_R407F_Topup = "R404A_R407F_Topup";
        public const string R507_R407F_Topup = "R507_R407F_Topup";
        public const string R407F_R507_Topup = "R407F_R507_Topup";
        public const string R22_Topup = "R22_Topup";
        public const string R22_R417A_Topup = "R22_R417A_Topup";
        public const string R417A_R22_Topup = "R417A_R22_Topup";

        public const string R407F_R404A_GuideLines = "R407F_R404A_GuideLines";       
        public const string R507_GuideLines = "R507_GuideLines";

        public const string R404A_R507_MoveAway = "R404A_R507_MoveAway";
        public const string R404A_Refrigerants_Move_Away_from_R404A_and_R507 = "R404A_Refrigerants_Move_Away_from_R404A_and_R507";
        public const string R507_Refrigerants_Move_Away_from_R404A_and_R507 = "R507_Refrigerants_Move_Away_from_R404A_and_R507";
        public const string R404A_R507_Refrigerants_Move_Away_from_R404A_and_R507 = "R404A_R507_Refrigerants_Move_Away_from_R404A_and_R507";
        public const string R507_R404A_Refrigerants_Move_Away_from_R404A_and_R507 = "R507_R404A_Refrigerants_Move_Away_from_R404A_and_R507";

        //public const string Refrigerant_GWP_and_Filling_Weight = "Refrigerant_GWP_and_Filling_Weight";
        public const string R404A_Refrigerant_GWP_and_Filling_Weight = "R404A_Refrigerant_GWP_and_Filling_Weight";
        public const string R22_Refrigerant_GWP_and_Filling_Weight = "R22_Refrigerant_GWP_and_Filling_Weight";
        public const string R134A_Refrigerant_GWP_and_Filling_Weight = "R134A_Refrigerant_GWP_and_Filling_Weight";
        public const string R407C_Refrigerant_GWP_and_Filling_Weight = "R407C_Refrigerant_GWP_and_Filling_Weight";
        public const string R407F_Refrigerant_GWP_and_Filling_Weight = "R407F_Refrigerant_GWP_and_Filling_Weight";
        public const string R410F_Refrigerant_GWP_and_Filling_Weight = "R410F_Refrigerant_GWP_and_Filling_Weight";
        public const string R417A_Refrigerant_GWP_and_Filling_Weight = "R417A_Refrigerant_GWP_and_Filling_Weight";
        public const string R422D_Refrigerant_GWP_and_Filling_Weight = "R422DRefrigerant_GWP_and_Filling_Weight";
        public const string R427A_Refrigerant_GWP_and_Filling_Weight = "R427ARefrigerant_GWP_and_Filling_Weight";
        public const string R507_Refrigerant_GWP_and_Filling_Weight = "R507_Refrigerant_GWP_and_Filling_Weight";

        //public const string Refrigerant_Return_of_Full_Cylinder = "Refrigerant_Return_of_Full_Cylinder";
        public const string Cylinder_Refrigerant_Return_of_Full_Cylinder = "CYLINDER_Refrigerant_Return_of_Full_Cylinder";
        public const string Cylinders_Refrigerant_Return_of_Full_Cylinder = "CYLINDERS_Refrigerant_Return_of_Full_Cylinder";

        public const string R407F_About = "R407F_About";


        //MARINE Accomodation Easy Clean

        public const string EasyClean_Window_And_Mirror = "EasyClean_Window_And_Mirror";

        public const string EasyClean_Window_And_Mirror_Outdoor = "EasyClean_Window_And_Mirror_Outdoor";

        public const string EasyClean_SoftSurface_And_Spot = "EasyClean_SoftSurface_And_Spot";

        public const string EasyClean_Floor_And_Hard_Surface = "EasyClean_Floor_And_Hard_Surface";

        public const string EasyClean_Basin_And_ToiletBowl = "EasyClean_Basin_And_ToiletBowl";

        public const string EasyClean_Basin_And_ToiletBowl_Outdoor = "EasyClean_Basin_And_ToiletBowl_Outdoor";

        //MARINE Accomodation Gamazyme

        public const string Gamazyme_BTC = "Gamazyme_BTC";

        public const string Gamazyme_TDS = "Gamazyme_TDS";

        public const string Gamazyme_Digestor = "Gamazyme_Digestor";

        public const string Gamazyme_BOE = "Gamazyme_BOE";

        //MARINE Galley EasyClean and Gamazyme

        public const string Easyclean_Cleaning_And_DisInfection_Sanite128F = "Easyclean_Cleaning_And_DisInfection_Sanite128F";

        public const string Galley_Easyclean_Oven_And_Grill = "Galley_Easyclean_Oven_And_Grill";

        public const string Galley_Easyclean_Dishwashing_LiquidManual = "Galley_Easyclean_Dishwashing_LiquidManual";

        public const string Galley_Easyclean_Hand_Sanitizer = "Galley_Easyclean_Hand_Sanitizer";

        public const string Galley_Gamazyme_Boe = "Galley_Gamazyme_Boe";

        public const string Galley_Gamazyme_Digestor = "Galley_Gamazyme_Digestor";

        //MaARINE Drains

        public const string Drains_Gamazyme700_FN = "Drains_Gamazyme700_FN";

        //MARINE Laundry

        public const string Easyclean_Laundry_Conditioner = "Easyclean_Laundry_Conditioner";

        public const string Easyclean_Laundry_Powder_ForLaundry = "Easyclean_Laundry_Powder_ForLaundry";

        public const string Easyclean_Laundry_Powder_SkinRash = "Easyclean_Laundry_Powder_SkinRash";

        //MARINE Skin CAre

        public const string SkinCare_EasyClean_Liquid_Hand_Soap_D = "SkinCare_EasyClean_Liquid_Hand_Soap_D";

        public const string SkinCare_EasyClean_Hand_Sanitizer = "SkinCare_EasyClean_Hand_Sanitizer";

        public const string SkinCare_EasyClean_Hand_Barrier_Cream_Wet = "SkinCare_EasyClean_Hand_Barrier_Cream_Wet";

        public const string SkinCare_EasyClean_Hand_Barrier_Cream_Dry = "SkinCare_EasyClean_Hand_Barrier_Cream_Dry";

        public const string SkinCare_EasyClean_After_Work_Lotion = "SkinCare_EasyClean_After_Work_Lotion";

        public const string SkinCare_EasyClean_Natural_Hand_Cleaner = "SkinCare_EasyClean_Natural_Hand_Cleaner";


        //Welding


        public const string Welding_Electrode_Competitor = "Welding_Electrode_Competitor";

        public const string Welding_Electrode_Competitor_1 = "Welding_Electrode_Competitor_1";

        public const string Welding_Electrode_Competitor_2 = "Welding_Electrode_Competitor_2";

        public const string Welding_Electrode_Competitor_3 = "Welding_Eletrode_Competitor_3";

        public const string Welding_Electrode_Competitor_4 = "Welding_Electrode_Competitor_4";

        public const string Welding_Electrode_Competitor_5 = "Welding_Electrode_Competitor_5";

        public const string Welding_Electrode_Competitor_6 = "Welding_Electrode_Competitor_6";

        public const string Welding_Flashback_Arrestor = "Welding_Flashback_Arrestor";

        public const string Welding_Machine_1 = "Welding_Machine_1";

        public const string Welding_Open_Circuit_Voltage = "Welding_Open_Circuit_Voltage";

        public const string Welding_Regulator_Oxygen_Acetylene = "Welding_Regulator_Oxygen_Acetylene";

        public const string Welding_Stick_Electrode = "Welding_Stick_Electrode";

        public const string Welding_Cutting_Torches = "Welding_Cutting_Torches";

        public const string Welding_Plasma_Machine = "Welding_Plasma_Machine";

        public const string Welding_Rod = "Welding_Rod";

        public const string Welding_Rod_1 = "Welding_Rod_1";
        public const string Welding_1 = "Welding_1";
        public const string Welding_Oxygen_Acetylene_Gas_Hoses = "Welding_Oxygen_Acetylene_Gas_Hoses";
        public const string Welding_2 = "Welding_2";

        public const string Welding_Accessories = "Welding_Accessories";

        public const string Welding_Cutting_Torches_1 = "Welding_Cutting_Torches_1";

        public const string Welding_Cylinder_Trolley = "Welding_Cylinder_Trolley";

        public const string Welding_Plasma_Machine_1 = "Welding_Plasma_Machine_1";

        public const string Welding_Wire = "Welding_Wire";

        public const string Workshop_Equipment_Drill = "Workshop_Equipment_Drill";

        public const string Workshop_Equipment_Grinder = "Workshop_Equipment_Grinder";

        //GandA
        public const string Cleaning_Shelf_life_Gamayzme_TDS = "Cleaning_Shelf life_Gamayzme TDS";
        public const string Cleaning_Shelf_life_Gamazyme_700FN = "Cleaning_Shelf life_Gamazyme 700FN";
        public const string Cleaning_Shelf_life_Gamazyme_BTC = "Cleaning_Shelf life_Gamazyme BTC";
        public const string Cleaning_Shelf_life_Gamazyme_DPC = "Cleaning_Shelf life_Gamazyme DPC";

        //Air
        public const string Air_Distributor = "Air_Distributor";
        public const string Air_Hose_Clamp = "Air_Hose_Clamp";
        public const string Air_tools_quick_coupling = "Air_tools_quick_coupling";
        public const string Air_Gun = "Air_Gun";
        public const string Air_Scaling_Hammer = "Air_Scaling_Hammer";
        public const string Air_Die_Grinder = "Air_Die_Grinder";
        public const string Air_Hose = "Air_Hose";
        public const string Air_Deck_Scaler = "Air_Deck_Scaler";
        public const string Air_Angle_Grinder = "Air_Angle_Grinder";
        public const string Air_tools_impact_wrench = "Air_tools_impact_wrench";

        //workshop
        //public const string Workshop_Equipment_Drill = "Workshop_Equipment_Drill";
        //public const string Workshop_Equipment_Grinder = "Workshop_Equipment_Grinder";


    }
}