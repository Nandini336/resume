﻿namespace WSS.ChatBot.Common
{
    /// <summary>
    /// Constants for common strings in entire solution
    /// </summary>
    public class Common
    {
        public const string HeaderMessage = "Was I able to help resolve your query?";
        public const string SpeakHeaderMessage = " .Was I able to help resolve your query?";
        public const string YesOrNoSelection = HeaderMessage + "\n\n Yes / No";
        public const string Bot = "Bot";
        public const string Conversation = "ConversationHistory";
        public const string Intent= "Intent";

        public const string IBot = "IBot";
        public const string QBot = "QBot";

        public const string Source = "Source";
    }
}